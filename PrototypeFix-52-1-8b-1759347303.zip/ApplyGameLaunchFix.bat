@echo off
setlocal

REM --- Set filenames ---
set "PATCH_FILE=prototypef.vcdiff"
set "TARGET_FILE=prototypef.exe"

REM --- Check if the patch file exists ---
if not exist "%PATCH_FILE%" (
    echo Error: Patch file "%PATCH_FILE%" not found, press enter to exit.
    pause.
    goto :eof
)

REM --- If the target file exists, back it up ---
if not exist "%TARGET_FILE%" (
    echo Error: Target file "%TARGET_FILE%" not found, press enter to exit.
    pause.
    goto :eof
)

echo Found "%TARGET_FILE%", backing it up as "%TARGET_FILE%.bak"
ren "%TARGET_FILE%" "%TARGET_FILE%.bak" || (
    echo Error: Failed to rename "%TARGET_FILE%" to backup, press enter to exit.
    pause.
    goto :eof
)

echo Applying patch...

xdelta3-3.1.0-i686.exe -v -d -s "%TARGET_FILE%.bak" "%PATCH_FILE%" "%TARGET_FILE%"

if not exist "%TARGET_FILE%" (
    echo Error: Failed to apply "%PATCH_FILE%" to "%TARGET_FILE%", restoring backup file.
    REM Restore backup if it exists
    if exist "%TARGET_FILE%.bak" ren "%TARGET_FILE%.bak" "%TARGET_FILE%"
    echo Press enter to exit.
    pause.
    goto :eof
)

echo Patch applied successfully.
echo You can now delete the ApplyGameLaunchFix.bat / prototypef.vcdiff / xdelta3-3.1.0-i686.exe files.
echo Press enter to exit.
pause.
endlocal