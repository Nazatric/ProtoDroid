# Using this launcher inside ProtoDroid

This is the **launcher UI** for ProtoDroid. It is a self-contained web build (`dist/index.html`) for an
offline Android WebView. All wallpaper stills, intro-cinematic stills, fonts and the ProtoDroid icon are
embedded in the source bundle and output HTML. It never fetches visual assets at runtime.

## 1. Build artefact

```
npm install
node tools/embed-assets.mjs   # regenerate src/lib/localAssets.ts after replacing local art/fonts
npm run build                 # -> dist/index.html (single file)
```

Fonts, the repo app icon, 14 high-resolution cinematic wallpapers and 6 stills from the Prototype
pre-rendered intro are embedded as data URLs. Copy only `dist/index.html` into
`app/src/main/assets/launcher/index.html`. `src/assets/cinematic/` holds the editable source files;
`src/lib/art.ts` assigns them to screens and rotation pools.

## 2. WebView setup (Kotlin)

```kotlin
WebView(context).apply {
  settings.javaScriptEnabled = true
  settings.domStorageEnabled = true
  settings.allowFileAccess = false     // assets are in the HTML; no folder picker in the web UI
  settings.textZoom = 100          // the UI already scales with the display
  webViewClient = object : WebViewClient() {
    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = true // stay offline
  }
  addJavascriptInterface(LauncherHost(), "ProtoDroidHost")
  loadUrl("file:///android_asset/launcher/index.html")
}
```

The native Activity owns landscape and immersive system-bar behavior (`screenOrientation="sensorLandscape"`).
There is no web fullscreen button or browser fullscreen request. Send Android Back to the page first:

```kotlin
override fun onBackPressed() {
  webView.evaluateJavascript("window.dispatchEvent(new KeyboardEvent('keydown',{key:'b'}))") { }
}
```

## 3. Bridge contract

The page looks for `window.ProtoDroidHost`. It is optional — without it everything remains local.

```js
interface ProtoDroidHost {
  launch(configJson: string): void;       // validated settings + mod IDs + game path
  exit(): void;                           // leave the launcher
  requestFileAccess?(): void;             // ask Android for the app's configured file access
  checkGameData?(): void;                 // check the configured local game directory again
  saveFile?(name: string, text: string): void;
  writeIni?(text: string): void;          // write protodroid.ini next to the game
}
```

Kotlin:

```kotlin
class LauncherHost {
  @JavascriptInterface fun launch(configJson: String) { /* start LauncherSession(configJson) */ }
  @JavascriptInterface fun exit() { /* finishActivity() */ }
  @JavascriptInterface fun requestFileAccess() { /* request the app's existing storage permission */ }
  @JavascriptInterface fun checkGameData() { /* validate the known Prototype directory */ }
  @JavascriptInterface fun saveFile(name: String, text: String) { /* write to Downloads/Prototype */ }
  @JavascriptInterface fun writeIni(text: String) { /* write /Prototype/protodroid.ini */ }
}
```

The native side can push events back into the page:

```kotlin
webView.evaluateJavascript(
  """window.ProtoDroidRecv({type:'fileAccess',granted:true})""",
  null
)
// Then report the native validation result:
webView.evaluateJavascript(
  """window.ProtoDroidRecv({type:'gameData',path:'<app-configured-path>',files:{
       dll:true,uv:true,rcf:true,p3d:true,art:true,audio:true,scripts:true},sizeMB:0})""",
  null
)
// also: {type:'open',screen:'settings'} · {type:'toast',message:'…'} · {type:'settings',values:{…}}
```

## 4. State

| Key | Contents |
| --- | --- |
| `pd.settings.v1` | every Graphics / Video / Controls / Interface / Audio / Engine / Diagnostics value |
| `pd.data.v1` | detected game path and file flags |
| `pd.layout.v1` | touch-control positions and scales |
| `pd.mods.v1` | local mod metadata (never the mod payload) |
| `pd.drivers.v1` | installed driver packages and the selected custom driver |
| `pd.logs.v1` | last 400 launcher/engine log lines |

`src/lib/settings.ts` defines the row schema and `toIni()` produces the exact `protodroid.ini`
that the engine reads. `launch(configJson)` receives the same settings so a Compose
`LauncherSettings` data class can be mapped one-to-one.

## 5. Touch-first rules

- Tap = activate. There are no controller prompts anywhere.
- Swipe/scroll inside lists; every row is at least 42 dp tall.
- A / Enter also activates and B / Escape / Android back goes back (keyboard helper only).
- Portrait shows a single rotate notice; the native Activity should lock landscape.
- Animations can be disabled in Settings → Interface.
