#!/bin/bash
# Builds the third-party native libraries of the Android port for one ABI: SDL2, FAudio, minimal FFmpeg Bink
# decoding, DXVK (d3d9 only, SDL2 WSI), and static Dobby for optional native mod detours. Same script locally and on
# GitHub Actions; nothing here depends on game files.
#
# Usage: android/build-deps.sh <abi: arm64-v8a | x86_64> <source dir> <install prefix>
# Needs ANDROID_NDK_HOME (or ANDROID_NDK_LATEST_HOME), cmake, ninja, meson, glslang, git, mako, PyYAML and packaging.
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/.." && pwd)
ABI=${1:?abi}
SRC=$(realpath -m "${2:?source dir}")
PREFIX=$(realpath -m "${3:?install prefix}")
NDK=${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:?set ANDROID_NDK_HOME}}
API=26
JOBS=${JOBS:-$(nproc)}

SDL2_TAG=release-2.30.9
FAUDIO_TAG=25.10
FFMPEG_TAG=n7.1.1
DXVK_TAG=v2.5.3
DOBBY_COMMIT=5dfc8546954ce3b3198132ab13fddb89ee92cdd7

case $ABI in
    arm64-v8a) TRIPLE=aarch64-linux-android; CPU_FAMILY=aarch64; CPU=armv8-a ;;
    x86_64) TRIPLE=x86_64-linux-android; CPU_FAMILY=x86_64; CPU=x86_64 ;;
    *) echo "unknown ABI $ABI" >&2; exit 2 ;;
esac

fetch() {  # fetch <dir> <url> <tag>
    [ -d "$SRC/$1" ] || git clone -q --depth 1 --branch "$3" --recurse-submodules --shallow-submodules "$2" "$SRC/$1"
}
mkdir -p "$SRC" "$PREFIX/lib" "$PREFIX/include"
fetch SDL2 https://github.com/libsdl-org/SDL.git $SDL2_TAG
fetch FAudio https://github.com/FNA-XNA/FAudio.git $FAUDIO_TAG
fetch FFmpeg https://github.com/FFmpeg/FFmpeg.git $FFMPEG_TAG
fetch dxvk https://github.com/doitsujin/dxvk.git $DXVK_TAG
if [ ! -d "$SRC/Dobby/.git" ]; then
    mkdir -p "$SRC/Dobby"
    git -C "$SRC/Dobby" init -q
    git -C "$SRC/Dobby" remote add origin https://github.com/jmpews/Dobby.git
fi
git -C "$SRC/Dobby" cat-file -e "$DOBBY_COMMIT^{commit}" 2>/dev/null || \
    git -C "$SRC/Dobby" fetch -q --depth 1 origin "$DOBBY_COMMIT"
git -C "$SRC/Dobby" checkout -q --detach --force "$DOBBY_COMMIT"
test "$(git -C "$SRC/Dobby" rev-parse HEAD)" = "$DOBBY_COMMIT"

# Android patches (android/patches/<project>-*.patch), applied once.
# git -C changes the working directory, so patch paths must be absolute.
# Never silently continue with unpatched upstream source.
PATCH_DIR=$(realpath "$(dirname "${BASH_SOURCE[0]}")/patches")
for proj in SDL2 FAudio dxvk Dobby; do
    for p in "$PATCH_DIR/${proj,,}"-*.patch; do
        [ -e "$p" ] || continue
        if git -C "$SRC/$proj" apply --check "$p" 2>/dev/null; then
            echo "applying $(basename "$p") to $proj"
            git -C "$SRC/$proj" apply "$p"
        elif git -C "$SRC/$proj" apply --reverse --check "$p" 2>/dev/null; then
            echo "already applied: $(basename "$p")"
        else
            echo "FATAL: $(basename "$p") neither applies nor is already applied" >&2
            exit 1
        fi
    done
done
# Fail closed if the pinned Android compatibility patch is absent from a reused source tree.
grep -Fq ':lo12:cdecl(common_closure_bridge_handler)' "$SRC/Dobby/source/TrampolineBridge/ClosureTrampolineBridge/arm64/closure_bridge_arm64.asm"
grep -Fq 'void *load_address;' "$SRC/Dobby/source/PlatformUtil/ProcessRuntime.h"
grep -Fq 'a.start() < b.start()' "$SRC/Dobby/source/Backend/UserMode/PlatformUtil/Linux/ProcessRuntime.cc"
grep -Fq 'mprotect(page, static_cast<size_t>(page_size)' "$SRC/Dobby/common/os_arch_features.h"

# The Qualcomm 90,808-byte allocation reports are addressed by this exact upstream backport. Do not allow a local or CI
# dependency rebuild to continue with the order-dependent DXVK 2.5.3 memory mask accidentally left unpatched.
grep -F 'm_memTypesByPropertyFlags[i] = sysmemMask ? sysmemMask : vidmemMask;' \
    "$SRC/dxvk/src/dxvk/dxvk_memory.cpp" >/dev/null || {
    echo "DXVK unified-memory type-selection fix is missing" >&2
    exit 1
}

CMAKE_ANDROID=(-G Ninja -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" -DANDROID_ABI="$ABI"
               -DANDROID_PLATFORM=android-$API -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$PREFIX"
               -DCMAKE_PREFIX_PATH="$PREFIX" -DCMAKE_FIND_ROOT_PATH="$PREFIX")

# Dobby function detours for optional native mods. Build from the pinned source and package only the static archive;
# libmain.so supplies log/dl and no libdobby.so is added to the APK. Save all FP registers across a detour.
rm -rf "$SRC/build/Dobby-$ABI"
cmake -S "$SRC/Dobby" -B "$SRC/build/Dobby-$ABI" "${CMAKE_ANDROID[@]}" \
    -DCMAKE_POSITION_INDEPENDENT_CODE=ON "-DCMAKE_ASM_FLAGS=-x assembler-with-cpp" \
    -DDOBBY_DEBUG=OFF -DDOBBY_BUILD_EXAMPLE=OFF -DDOBBY_BUILD_TEST=OFF \
    -DFullFloatingPointRegisterPack=ON -DPlugin.SymbolResolver=OFF -DPlugin.ImportTableReplace=OFF \
    -DPlugin.Android.BionicLinkerUtil=OFF
cmake --build "$SRC/build/Dobby-$ABI" --target dobby_static -j "$JOBS"
test -s "$SRC/build/Dobby-$ABI/libdobby.a"
install -m 644 "$SRC/build/Dobby-$ABI/libdobby.a" "$PREFIX/lib/libdobby.a"
install -m 644 "$SRC/Dobby/include/dobby.h" "$PREFIX/include/dobby.h"

# SDL2 (also installs SDL2.pc, which DXVK's meson build looks up).
cmake -S "$SRC/SDL2" -B "$SRC/build/SDL2-$ABI" "${CMAKE_ANDROID[@]}" -DSDL_STATIC=OFF -DSDL_TEST=OFF
cmake --build "$SRC/build/SDL2-$ABI" -j "$JOBS"
cmake --install "$SRC/build/SDL2-$ABI"
# Bind the installed native library to the exact C/Java source version. The APK packager verifies this manifest
# before stripping and then compares the signed library bytes with the staged result.
SDL2_VERSION=$(python3 "$ROOT/tools/sdl_version.py" pin "$ROOT/android/build-deps.sh")
python3 "$ROOT/tools/sdl_version.py" write-manifest \
    "$SRC/SDL2" "$PREFIX/lib/libSDL2.so" "$PREFIX/lib/protodroid-sdl2-version.txt" "$SDL2_VERSION"
test -s "$PREFIX/lib/protodroid-sdl2-version.txt"

# FAudio on SDL2.
cmake -S "$SRC/FAudio" -B "$SRC/build/FAudio-$ABI" "${CMAKE_ANDROID[@]}" -DBUILD_SDL3=OFF -DBUILD_SHARED_LIBS=ON \
      -DSDL2_DIR="$PREFIX/lib/cmake/SDL2"
cmake --build "$SRC/build/FAudio-$ABI" -j "$JOBS"
cmake --install "$SRC/build/FAudio-$ABI"

# FFmpeg is deliberately a tiny static build: Bink video, both Bink audio codec variants, the Bink demuxer and
# swresample for the shared SDL mixer.
TC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin
# No network, programs, filters, external codec or auto-detected dependency is
# allowed into the APK. Keeping the archives in the dependency artifact is essential: build-apk runs on a fresh job.
FFMPEG_BUILD=$SRC/build/FFmpeg-$ABI
mkdir -p "$FFMPEG_BUILD"
FFMPEG_ARCH=$CPU_FAMILY
if [ "$ABI" = arm64-v8a ]; then FFMPEG_ARCH=aarch64; fi
(
    cd "$FFMPEG_BUILD"
    "$SRC/FFmpeg/configure" \
        --prefix="$PREFIX" --cc="$TC/$TRIPLE$API-clang" --cxx="$TC/$TRIPLE$API-clang++" \
        --ar="$TC/llvm-ar" --ranlib="$TC/llvm-ranlib" --strip="$TC/llvm-strip" \
        --arch="$FFMPEG_ARCH" --target-os=android --enable-cross-compile --enable-pic \
        --enable-static --disable-shared --disable-programs --disable-doc --disable-debug --disable-network \
        --disable-autodetect --enable-pthreads --disable-w32threads --disable-os2threads --disable-x86asm \
        --disable-avdevice --disable-avfilter --disable-swscale --disable-postproc --disable-everything \
        --enable-avformat --enable-avcodec --enable-avutil --enable-swresample \
        --enable-demuxer=bink --enable-decoder=bink,binkaudio_rdft,binkaudio_dct
    make -j "$JOBS"
    make install
)
for archive in libavformat.a libavcodec.a libavutil.a libswresample.a; do
    test -s "$PREFIX/lib/$archive" || { echo "missing FFmpeg archive $PREFIX/lib/$archive" >&2; exit 1; }
done

# DXVK native, d3d9 only.
CROSS=$SRC/build/android-$ABI.cross
cat > "$CROSS" <<EOF
[binaries]
c = '$TC/$TRIPLE$API-clang'
cpp = '$TC/$TRIPLE$API-clang++'
ar = '$TC/llvm-ar'
strip = '$TC/llvm-strip'
pkg-config = 'pkg-config'

[properties]
pkg_config_libdir = '$PREFIX/lib/pkgconfig'
needs_exe_wrapper = true

[host_machine]
system = 'android'
cpu_family = '$CPU_FAMILY'
cpu = '$CPU'
endian = 'little'

[built-in options]
# Meson must not silently turn this into a desktop Unix build. DXVK uses
# __ANDROID__ to select libSDL2.so, libvulkan.so and Android surface WSI.
c_args = ['-D__ANDROID__=1']
cpp_args = ['-D__ANDROID__=1']
EOF
rm -rf "$SRC/build/dxvk-$ABI"
meson setup "$SRC/build/dxvk-$ABI" "$SRC/dxvk" --cross-file "$CROSS" --buildtype release --prefix "$PREFIX" \
      -Denable_d3d9=true -Denable_d3d8=false -Denable_d3d10=false -Denable_d3d11=false -Denable_dxgi=false \
      -Ddxvk_native_wsi=sdl2
ninja -C "$SRC/build/dxvk-$ABI" -j "$JOBS"
ninja -C "$SRC/build/dxvk-$ABI" install

# Fail the build rather than shipping a desktop-WSI DXVK by accident. This
# checks the installed library, not just the compiler or a successful link.
DXVK_LIB="$PREFIX/lib/libdxvk_d3d9.so"
if [ ! -f "$DXVK_LIB" ]; then
    echo "missing installed DXVK library: $DXVK_LIB" >&2
    exit 1
fi
DXVK_STRINGS=$($TC/llvm-strings "$DXVK_LIB")
printf '%s\n' "$DXVK_STRINGS" | grep -E 'libSDL|vkCreateAndroidSurface|SDL2 WSI' || true
printf '%s\n' "$DXVK_STRINGS" | grep -Fx 'libSDL2.so' >/dev/null || {
    echo "DXVK was not compiled with the Android SDL2 soname" >&2
    exit 1
}
if printf '%s\n' "$DXVK_STRINGS" | grep -Fx 'libSDL2-2.0.so.0' >/dev/null; then
    echo "DXVK contains the desktop SDL2 soname" >&2
    exit 1
fi
printf '%s\n' "$DXVK_STRINGS" | grep -F 'vkCreateAndroidSurfaceKHR' >/dev/null || {
    echo "DXVK was not compiled with Android surface support" >&2
    exit 1
}
# Prove that the final Mali diagnostics patch was applied to this exact
# dependency build. A cache hit has a patch-dependent key; a local rebuild
# must not be able to silently package an older DXVK either.
for marker in \
    '/storage/emulated/0/Prototype/logs/pipeline_trace.log' \
    'last_vs.spv' \
    'last_fs.spv' \
    'PROTODROID_PIPELINE_TRACE' \
    'pre-created dummy sampler, buffer, and all 14 image views' \
    'dummy image GPU initialization complete' \
    'Disabling maintenance5, EDS3' \
    'Unmapped descriptor binding' \
    'DXVK: Using Vulkan 1.2 KHR/EXT compatibility path' \
    'DXVK: Capping ARM compiler threads at 2' \
    'DXVK pipeline timing:' \
    'PROTODROID_PIPELINE_TIMING' \
    'DXVK_LOG_TIMESTAMPS' \
    'prototypeenginef.dll'; do
    printf '%s\n' "$DXVK_STRINGS" | grep -F "$marker" >/dev/null || {
        echo "DXVK is missing required compatibility/cache marker: $marker" >&2
        exit 1
    }
done

# ARM64 Vulkan 1.1 Auto compatibility route. This is an Android-WSI build from an exact Mesa commit; it is not a
# prebuilt download and it is never substituted for a working direct 1.2/1.3 path.
if [ "$ABI" = arm64-v8a ]; then
    "$(dirname "${BASH_SOURCE[0]}")/build-vulkan-wrapper.sh" "$ABI" "$SRC" "$PREFIX"
fi

echo "installed to $PREFIX:"
find "$PREFIX" -name "*.so" | sort
