package com.protodroid;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.system.ErrnoException;
import android.system.Os;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.libsdl.app.SDLActivity;
import org.libsdl.app.SDLSurface;

/** SDL's activity running the native port (libmain.so: the recompiled engine and its platform layer). */
public class ProtoActivity extends SDLActivity {
    @Override
    protected String[] getLibraries() {
        return new String[] {"SDL2", "FAudio", "dxvk_d3d9", modernCpu() ? "main" : "main_v80"};
    }

    /**
     * libmain.so is built for ARMv8.2 with RCpc (LDAPR keeps the emulated x86 memory ordering cheap) and LSE atomics;
     * older cores (Cortex-A53/A73, e.g. Snapdragon 6xx) get libmain_v80.so, built for ARMv8.0. Every core must have
     * both features: big.LITTLE phones list each core's features separately.
     */
    private static boolean modernCpu() {
        int cores = 0;
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/cpuinfo"))) {
            for (String line; (line = r.readLine()) != null;) {
                if (!line.startsWith("Features")) continue;
                List<String> features = Arrays.asList(line.substring(line.indexOf(':') + 1).trim().split("\\s+"));
                if (!features.contains("atomics") || !features.contains("lrcpc")) return false;
                ++cores;
            }
        } catch (IOException e) {
            return false;
        }
        return cores > 0;
    }

    @Override
    protected SDLSurface createSDLSurface(Context context) {
        return new ProtoSurface(context);
    }

    /**
     * The engine runs once per process: a new start of the game gets a fresh process. SDL's onDestroy waits on the UI
     * thread for the game thread to return, which the engine's shutdown can make long enough for an ANR, so a
     * finishing activity ends the process before that.
     */
    @Override
    protected void onDestroy() {
        if (isFinishing()) android.os.Process.killProcess(android.os.Process.myPid());
        super.onDestroy();
    }

    private void prepareVulkanDriver() {
        DriverRepository.Entry selected = DriverManager.selected(this);
        DriverPackage.Installed installed = selected == null ? null : selected.installed;
        File driver = installed == null ? null : installed.libraryFile();
        if (driver == null && getSharedPreferences("controls", MODE_PRIVATE).getInt("vulkan_driver", 0) == 3) {
            // The in-game restart action comes straight back here, without SetupActivity's migration/recovery path.
            new GameSettings(this).setCustomDriverSelected(false);
            Toast.makeText(this, "No valid custom driver is selected; Auto was restored.", Toast.LENGTH_LONG).show();
        }
        try {
            if (driver == null) {
                Os.unsetenv("PROTODROID_CUSTOM_DRIVER");
                Os.unsetenv("PROTODROID_CUSTOM_DRIVER_BACKEND");
            } else {
                Os.setenv("PROTODROID_CUSTOM_DRIVER", driver.getAbsolutePath(), true);
                Os.setenv("PROTODROID_CUSTOM_DRIVER_BACKEND", installed.backend, true);
            }
        } catch (ErrnoException ignored) {
            // Native selection keeps its safe automatic/system fallback.
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int orientation = getSharedPreferences("controls", MODE_PRIVATE).getInt("display_orientation", 0);
        if (orientation == 1) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } else if (orientation == 2) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE);
        }
        prepareVulkanDriver();
        ModManager.prepareForLaunch(this);
        // The native side loads the bundled Vulkan driver (Turnip, on Adreno) from the extracted libraries.
        try {
            Os.setenv("PROTODROID_NATIVE_LIB_DIR", getApplicationInfo().nativeLibraryDir, true);
        } catch (ErrnoException ignored) {
            // the system Vulkan driver is used
        }
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);  // no dimming while playing
        if (isDiagnosticTour() && "precompile".equals(Os.getenv("PROTODROID_TOUR_PURPOSE"))) {
            // One-click shader precompile: the tour injects its own input, so the on-screen controls are
            // replaced by the styled loading screen. The relaunch on completion is owned by SetupActivity
            // in the launcher process; this tour process ends itself the moment the run finishes.
            addContentView(new ShaderPrecompileOverlay(this), new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            // On-screen controls above SDL's surface; they feed SDL keyboard and mouse input.
            addContentView(new TouchControls(this), new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            // In-game mod settings: the left-edge handle opens the live panel (only when mods
            // with options are enabled). Passes touches through everywhere outside its controls.
            addContentView(new ModPanel(this), new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    private static boolean isDiagnosticTour() {
        return "1".equals(Os.getenv("PROTODROID_DIAGNOSTIC_TOUR"));
    }
}
