#include "present_stats.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>

namespace {

void Check(bool condition, const char* message) {
    if (!condition) {
        std::fprintf(stderr, "present-stats test failed: %s\n", message);
        std::exit(1);
    }
}

bool Near(double a, double b, double tolerance = 0.02) { return std::fabs(a - b) <= tolerance; }

void TestBaselineAndOneReportPerPresent() {
    native::PresentStatsTracker tracker;
    int reports = 0;
    auto present = [&](int64_t now) {
        const int64_t duration = tracker.AddPresent(now);
        if (duration > 0) ++reports;  // production GuardedPresent calls PerfHintFrame here exactly once
        return duration;
    };

    Check(present(0) == 0 && reports == 0, "zero-time baseline was not initialized");
    Check(present(16666667) == 16666667 && reports == 1, "first complete interval was not reported once");
    // Empty message-pump iterations do not call AddPresent and therefore cannot reach ADPF.
    Check(reports == 1, "empty pump iterations changed ADPF report count");
    Check(present(33333334) == 16666667 && reports == 2, "second Present did not produce exactly one report");
}

void TestSixtyFpsWindow() {
    native::PresentStatsTracker tracker;
    int64_t now = 1000000000ll;
    tracker.AddPresent(now);
    int reports = 0;
    for (int i = 0; i < 60; ++i) {
        now += 16666667;
        if (tracker.AddPresent(now) > 0) ++reports;
    }
    const auto s = tracker.Snapshot();
    Check(reports == 60 && s.frames == 60, "Present count does not match completed intervals");
    Check(Near(s.fps, 60.0, 0.01), "presented FPS is not count divided by elapsed time");
    Check(Near(s.average_ms, 16.666667), "average Present interval is inaccurate");
    Check(Near(s.p99_ms, 16.666667), "constant-frame p99 is inaccurate");
    Check(Near(s.max_ms, 16.666667), "constant-frame max is inaccurate");
}

void TestAveragePercentileAndOutlier() {
    native::PresentStatsTracker tracker;
    int64_t now = 0;
    tracker.AddPresent(now);
    std::vector<int64_t> durations(99, 10000000);  // 99 frames at 10 ms
    durations.push_back(100000000);                // one 100 ms combat spike
    for (int64_t duration : durations) {
        now += duration;
        tracker.AddPresent(now);
    }
    const auto s = tracker.Snapshot();
    Check(s.frames == 100, "non-uniform window lost a Present");
    Check(Near(s.fps, 100.0 / 1.09, 0.01), "non-uniform FPS used reciprocal average incorrectly");
    Check(Near(s.average_ms, 10.9), "non-uniform average is inaccurate");
    Check(Near(s.p99_ms, 10.0), "nearest-rank p99 was confused with the maximum");
    Check(Near(s.max_ms, 100.0), "maximum frame interval was lost");
}

void TestNoLoopCounterLeak() {
    native::PresentStatsTracker tracker;
    Check(tracker.Snapshot().frames == 0 && tracker.Snapshot().fps == 0,
          "new tracker invented frames before the first Present");
    tracker.AddPresent(5000000000ll);
    for (int i = 0; i < 10000; ++i) {
        // Simulated guest pump work: intentionally no tracker call.
    }
    Check(tracker.Snapshot().frames == 0 && tracker.Snapshot().fps == 0,
          "message-pump iterations leaked into presented-frame statistics");
}

void TestCumulativePresentCount() {
    const uint64_t before = native::PresentedFrameCount();
    native::RecordPresent();
    native::RecordPresent();
    Check(native::PresentedFrameCount() == before + 2, "cumulative present count did not track successful Presents");
}

void TestDisabledDetailedCollection() {
    native::PresentStatsTracker tracker;
    tracker.AddPresent(1000000000ll, 7, false);
    for (int i = 1; i <= 10000; ++i) tracker.AddPresent(1000000000ll + i * 16666667ll, 7, false);
    Check(tracker.TakeDetailed().count == 0, "disabled detailed diagnostics retained per-frame samples");
    Check(tracker.DetailedTotals().intervals == 0 && tracker.DetailedTotals().total_ns == 0,
          "disabled detailed diagnostics retained cumulative timing work");
    Check(tracker.Snapshot().frames > 0, "disabling detailed diagnostics broke the one-second ADPF/overlay window");
}

void TestDetailedCumulativeTotals() {
    native::PresentStatsTracker tracker;
    tracker.AddPresent(1000000000ll, 9, true);
    tracker.AddPresent(1010000000ll, 9, true);
    tracker.AddPresent(1030000000ll, 9, true);
    tracker.AddPresent(1040000000ll, 9, false);
    const auto totals = tracker.DetailedTotals();
    Check(totals.intervals == 2, "detailed totals included a disabled interval or lost an enabled one");
    Check(totals.total_ns == 30000000ll, "detailed total duration is inaccurate");
    Check(totals.max_ns == 20000000ll, "detailed maximum interval is inaccurate");
    tracker.ResetDetailedTotals();
    const auto reset = tracker.DetailedTotals();
    Check(reset.intervals == 0 && reset.total_ns == 0 && reset.max_ns == 0,
          "phase-boundary reset retained old Present totals");
}

}  // namespace

int main() {
    TestBaselineAndOneReportPerPresent();
    TestSixtyFpsWindow();
    TestAveragePercentileAndOutlier();
    TestNoLoopCounterLeak();
    TestCumulativePresentCount();
    TestDisabledDetailedCollection();
    TestDetailedCumulativeTotals();
    std::puts("present-stats tests passed (baseline, ADPF count, FPS, percentiles, detailed totals)");
    return 0;
}
