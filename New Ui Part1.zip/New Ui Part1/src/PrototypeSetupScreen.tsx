import { memo, useEffect, useRef, useState, type PointerEvent, type ReactNode } from "react";
import { usePageVisible } from "./motion";
import type { PrototypeSetupUiState } from "./bridge";
import icon from "./assets/img/protodroid-icon.png";
import bg1 from "./assets/img/bg1.jpg";
import bg2 from "./assets/img/bg2.jpg";
import bg3 from "./assets/img/bg3.jpg";
import bg4 from "./assets/img/bg4.jpg";

const SLIDES = [bg1, bg2, bg3, bg4];
const REQUIRED = ["prototypeenginef.dll", ".rcf", ".p3d", "art", "audio", "scripts"];
const SLIDE_HOLD = 6500;
const SLIDE_TRANSITION = 1100;

type Frame = { image: number; sequence: number };

const Slideshow = memo(function Slideshow({ active }: { active: boolean }) {
  const [frames, setFrames] = useState<Frame[]>([{ image: 0, sequence: 0 }]);
  const current = frames[frames.length - 1];

  useEffect(() => {
    const image = new Image();
    image.src = SLIDES[(current.image + 1) % SLIDES.length];
    image.decode?.().catch(() => undefined);
  }, [current.image]);

  useEffect(() => {
    if (!active) return;
    const timer = window.setTimeout(() => {
      setFrames((previous) => {
        const last = previous[previous.length - 1];
        return [last, { image: (last.image + 1) % SLIDES.length, sequence: last.sequence + 1 }];
      });
    }, SLIDE_HOLD);
    return () => window.clearTimeout(timer);
  }, [active, current.sequence]);

  useEffect(() => {
    if (frames.length < 2) return;
    const timer = window.setTimeout(() => setFrames((previous) => previous.slice(-1)), SLIDE_TRANSITION);
    return () => window.clearTimeout(timer);
  }, [frames]);

  return (
    <div className="slides" aria-hidden="true">
      {frames.map((frame) => (
        <div key={frame.sequence} className={`slide-frame ${frame.sequence > 0 ? "slide-reveal" : "slide-initial"}`}>
          <img className="slide-image" src={SLIDES[frame.image]} alt="" decoding="async" draggable={false} />
        </div>
      ))}
      {current.sequence > 0 && <div key={`flash-${current.sequence}`} className="slide-flash" />}
    </div>
  );
});

function Check() {
  return <svg className="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="m4.5 12.5 5 5L19.5 7" /></svg>;
}

function GameButton({ children, onPress, variant, disabled, busy, delay, testId }: {
  children: ReactNode;
  onPress: () => void;
  variant: "primary" | "normal" | "done";
  disabled?: boolean;
  busy?: boolean;
  delay: number;
  testId: string;
}) {
  const [ripple, setRipple] = useState<{ x: number; y: number; id: number } | null>(null);
  const sequence = useRef(0);
  const down = (event: PointerEvent<HTMLButtonElement>) => {
    if (!event.isPrimary || event.button !== 0) return;
    const bounds = event.currentTarget.getBoundingClientRect();
    setRipple({ x: event.clientX - bounds.left, y: event.clientY - bounds.top, id: ++sequence.current });
    try { navigator.vibrate?.(12); } catch { /* Haptics are optional. */ }
  };

  return (
    <button
      type="button"
      className={`gbtn gbtn-${variant} ${busy ? "is-busy" : ""}`}
      style={{ animationDelay: `${delay}s` }}
      disabled={disabled}
      aria-busy={busy || undefined}
      data-testid={testId}
      onPointerDown={down}
      onClick={onPress}
    >
      <span className="gbtn-fill" aria-hidden="true" />
      <span className="gbtn-br l" aria-hidden="true">[</span>
      <span className="gbtn-label">{children}</span>
      <span className="gbtn-br r" aria-hidden="true">]</span>
      {busy && <span className="gbtn-bar" aria-hidden="true" />}
      {ripple && <span key={ripple.id} className="splat" aria-hidden="true"
        style={{ left: ripple.x, top: ripple.y }} onAnimationEnd={() => setRipple(null)} />}
    </button>
  );
}

function Tile({ label, value, ok }: { label: string; value: string; ok: boolean }) {
  return (
    <div className={`tile ${ok ? "ok" : "no"}`}>
      <span className="tile-mark" aria-hidden="true">{ok ? <Check /> : <i />}</span>
      <span className="tile-text"><small>{label}</small><b>{value}</b></span>
    </div>
  );
}

export function PrototypeSetupScreen({ state, onAllowFileAccessClick, onCheckAgainClick, onExitClick }: {
  state: PrototypeSetupUiState;
  onAllowFileAccessClick: () => void;
  onCheckAgainClick: () => void;
  onExitClick: () => void;
}) {
  const active = usePageVisible();
  const { hasFileAccessPermission: allowed, isGameDataFound: found, isChecking } = state;
  const paths = [
    { tag: "RECOMMENDED", path: state.primaryPath, note: allowed ? "File access granted. /game also supported" : "Any file manager. Needs file access" },
    { tag: "APP PRIVATE", path: state.secondaryPath, note: "Android 11+: copy from a PC over USB" },
  ];

  return (
    <main className={`stage ${active ? "" : "is-paused"}`}>
      <Slideshow active={active} />
      <div className="shade" aria-hidden="true" />
      <div className="grain" aria-hidden="true" />
      <div className="vignette" aria-hidden="true" />

      <header className="top">
        <div className="brand">
          <img className="brand-icon" src={icon} alt="Prototype" width="512" height="512" draggable={false} />
          <div className="wordmark" aria-label="Prototype">
            <i aria-hidden="true">[</i>
            <span className="glitch" data-text="PROTOTYPE" aria-hidden="true">PROTOTYPE</span>
            <i aria-hidden="true">]</i>
          </div>
        </div>
        <button type="button" className="exit" data-testid="setup.exit" onClick={onExitClick}>
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" /></svg>
          EXIT
        </button>
      </header>
      <div className="hud-line" aria-hidden="true" />

      <section className="content" aria-label="Game file setup">
        <div className="left">
          <div className="tiles">
            <Tile label="STORAGE ACCESS" value={allowed ? "GRANTED" : "REQUIRED"} ok={allowed} />
            <Tile label="GAME DATA" value={found ? "DETECTED" : "NOT FOUND"} ok={found} />
          </div>
          <h1 className="headline">
            <span className="glitch" data-text={found ? "GAME DATA" : "GAME FILES"}>{found ? "GAME DATA" : "GAME FILES"}</span>
            <span className={`headline-2 ${found ? "ok" : ""}`}>{found ? "FOUND" : "NOT FOUND"}</span>
          </h1>
          <div className="status-line" role="status" aria-live="polite" aria-atomic="true" data-testid="setup.status">
            <b aria-hidden="true">&gt;</b><span>{state.statusMessage}</span><i aria-hidden="true" />
          </div>
          <div className="buttons">
            <GameButton variant={allowed ? "done" : "primary"} onPress={onAllowFileAccessClick}
              disabled={allowed} delay={0.5} testId="setup.allowAccess">
              {allowed && <Check />}{allowed ? "ACCESS ALLOWED" : "ALLOW FILE ACCESS"}
            </GameButton>
            <GameButton variant={allowed && !found ? "primary" : "normal"} onPress={onCheckAgainClick}
              disabled={isChecking} busy={isChecking} delay={0.62} testId="setup.checkAgain">
              {isChecking ? "CHECKING" : "CHECK AGAIN"}
            </GameButton>
          </div>
        </div>

        <div className="right">
          <div className="panel">
            <div className="panel-title">PLACE YOUR PC GAME FILES IN</div>
            {paths.map((path, index) => (
              <div className="panel-row" key={index}>
                <span className="panel-num" aria-hidden="true">0{index + 1}</span>
                <span className="panel-info"><small>{path.tag}</small><b dir="ltr">{path.path}</b><em>{path.note}</em></span>
              </div>
            ))}
          </div>
          <div className="chips" aria-label="Required game files and folders">
            {REQUIRED.map((file, index) => (
              <span key={file} className="chip" style={{ animationDelay: `${1 + index * 0.05}s` }}>{file}</span>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}