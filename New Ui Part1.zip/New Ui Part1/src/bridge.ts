import { useSyncExternalStore } from "react";

export type UiAction = "allowFileAccess" | "checkAgain" | "exit";
export type CheckState = "idle" | "checking" | "missing" | "found";

/** Mirrors the native contract. Permission and scan results always come from the host. */
export interface PrototypeSetupUiState {
  hasFileAccessPermission: boolean;
  isGameDataFound: boolean;
  statusMessage: string;
  primaryPath: string;
  secondaryPath: string;
  isChecking: boolean;
}

type LegacyPatch = { fileAccessAllowed?: boolean; check?: CheckState };
export interface ProtoDroidUIApi {
  setState: (patch: Partial<PrototypeSetupUiState> & LegacyPatch) => void;
  getState: () => Readonly<PrototypeSetupUiState>;
  onAction: ((action: UiAction) => void) | null;
}

declare global {
  interface Window { ProtoDroidUI: ProtoDroidUIApi }
}

let state: Readonly<PrototypeSetupUiState> = Object.freeze({
  hasFileAccessPermission: false,
  isGameDataFound: false,
  statusMessage: "Waiting for file access",
  primaryPath: "/storage/emulated/0/Prototype",
  secondaryPath: "/storage/emulated/0/Android/data/com.protodroid/files/game",
  isChecking: false,
});
const listeners = new Set<() => void>();

function setState(patch: Partial<PrototypeSetupUiState> & LegacyPatch) {
  const next = { ...state };
  if (typeof patch.fileAccessAllowed === "boolean") next.hasFileAccessPermission = patch.fileAccessAllowed;
  if (patch.check) {
    next.isChecking = patch.check === "checking";
    next.isGameDataFound = patch.check === "found";
    next.statusMessage = { idle: "Ready to check", checking: "Searching for prototypeenginef.dll", missing: "Game files not found", found: "Game files found" }[patch.check];
  }
  for (const key of ["hasFileAccessPermission", "isGameDataFound", "isChecking"] as const) {
    if (typeof patch[key] === "boolean") next[key] = patch[key];
  }
  for (const key of ["primaryPath", "secondaryPath", "statusMessage"] as const) {
    if (typeof patch[key] === "string") next[key] = patch[key];
  }
  if (Object.keys(next).every((key) => next[key as keyof typeof next] === state[key as keyof typeof state])) return;
  state = Object.freeze(next);
  listeners.forEach((listener) => listener());
}

const demo = new URLSearchParams(window.location.search).has("demo");
let permissionDemo: number | undefined;
let scanDemo: number | undefined;

export function dispatchAction(action: UiAction) {
  if (action === "allowFileAccess" && state.hasFileAccessPermission) return;
  if (action === "checkAgain" && state.isChecking) return;
  // Use the callback OR the DOM event, never dispatch the same action twice.
  if (window.ProtoDroidUI.onAction) window.ProtoDroidUI.onAction(action);
  else window.dispatchEvent(new CustomEvent("protodroid:action", { detail: { action } }));

  if (!demo || window.ProtoDroidUI.onAction) return;
  if (action === "allowFileAccess" && permissionDemo === undefined) {
    permissionDemo = window.setTimeout(() => {
      setState({ hasFileAccessPermission: true, statusMessage: "File access granted. Copy your game files" });
      permissionDemo = undefined;
    }, 1100);
  }
  if (action === "checkAgain") {
    setState({ isChecking: true, statusMessage: "Searching for prototypeenginef.dll" });
    window.clearTimeout(scanDemo);
    scanDemo = window.setTimeout(() => setState({ isChecking: false, statusMessage: state.hasFileAccessPermission ? "Game files not found" : "Allow file access first" }), 1800);
  }
}

window.ProtoDroidUI = { setState, getState: () => state, onAction: window.ProtoDroidUI?.onAction ?? null };
window.dispatchEvent(new Event("protodroid:ready"));

const subscribe = (callback: () => void) => {
  listeners.add(callback);
  return () => { listeners.delete(callback); };
};
export function useUiState() {
  return useSyncExternalStore(subscribe, () => state);
}

export async function enterImmersive() {
  try {
    if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
      await document.documentElement.requestFullscreen({ navigationUI: "hide" });
    }
    const orientation = screen.orientation as ScreenOrientation & { lock?: (mode: string) => Promise<void> };
    await orientation.lock?.("landscape");
  } catch { /* The Android Activity owns immersive mode; browsers can decline it. */ }
}