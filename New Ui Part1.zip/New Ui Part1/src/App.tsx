import { useEffect } from "react";
import { dispatchAction, enterImmersive, useUiState } from "./bridge";
import { PrototypeSetupScreen } from "./PrototypeSetupScreen";

export default function App() {
  const state = useUiState();
  useEffect(() => {
    const enter = () => { if (window.top === window && matchMedia("(pointer: coarse)").matches) void enterImmersive(); };
    document.addEventListener("pointerdown", enter, { once: true });
    return () => document.removeEventListener("pointerdown", enter);
  }, []);

  return <PrototypeSetupScreen state={state}
    onAllowFileAccessClick={() => dispatchAction("allowFileAccess")}
    onCheckAgainClick={() => dispatchAction("checkAgain")}
    onExitClick={() => dispatchAction("exit")} />;
}