import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import { mkdir } from "node:fs/promises";
import { chromium } from "../.verification/browser/node_modules/playwright/index.mjs";

const screenshots = fileURLToPath(new URL("../.verification/screenshots/", import.meta.url));
await mkdir(screenshots, { recursive: true });
const browser = await chromium.launch({ args: ["--no-sandbox"] });
const context = await browser.newContext({ offline: true });
const errors = [];
const remote = [];
context.on("page", (page) => {
  page.on("pageerror", (error) => errors.push(error.message));
  page.on("request", (request) => { if (/^https?:/.test(request.url())) remote.push(request.url()); });
});

try {
  const url = new URL("../dist/index.html", import.meta.url).href;
  for (const [width, height] of [[915, 412], [740, 360], [2400, 1080], [2712, 1220]]) {
    const page = await context.newPage();
    await page.setViewportSize({ width, height });
    await page.goto(url);
    await page.waitForTimeout(2400);
    await page.evaluate(() => {
      window.__actions = [];
      window.ProtoDroidUI.onAction = (action) => window.__actions.push(action);
    });
    const access = page.getByTestId("setup.allowAccess");
    const check = page.getByTestId("setup.checkAgain");

    await access.click();
    assert.equal(await page.evaluate(() => window.ProtoDroidUI.getState().hasFileAccessPermission), false);
    assert.deepEqual(await page.evaluate(() => window.__actions), ["allowFileAccess"]);
    await page.evaluate(() => window.ProtoDroidUI.setState({ hasFileAccessPermission: true, statusMessage: "File access granted" }));
    await page.waitForTimeout(350);
    assert.equal(await access.isDisabled(), true);

    await check.focus();
    await page.keyboard.press("Enter");
    assert.deepEqual(await page.evaluate(() => window.__actions), ["allowFileAccess", "checkAgain"]);
    await page.evaluate(() => window.ProtoDroidUI.setState({ isChecking: true, statusMessage: "Searching for prototypeenginef.dll" }));
    assert.equal(await check.isDisabled(), true);
    assert.equal(await check.getAttribute("aria-busy"), "true");

    await page.evaluate(() => window.ProtoDroidUI.setState({ isChecking: false, isGameDataFound: true, statusMessage: "Game files found" }));
    await page.waitForTimeout(300);
    assert.equal(await page.locator("h1").innerText(), "GAME DATA\nFOUND");
    // A permission revocation must not erase valid private game data.
    await page.evaluate(() => window.ProtoDroidUI.setState({ hasFileAccessPermission: false }));
    assert.equal(await access.isDisabled(), false);
    assert.equal(await page.evaluate(() => window.ProtoDroidUI.getState().isGameDataFound), true);

    const metrics = await page.evaluate(() => {
      const bounds = (selector) => document.querySelector(selector).getBoundingClientRect();
      const icon = getComputedStyle(document.querySelector(".brand-icon"));
      return {
        width: document.documentElement.scrollWidth,
        height: document.documentElement.scrollHeight,
        buttonHeight: bounds(".gbtn").height,
        headerBottom: bounds(".top").bottom,
        contentTop: bounds(".content").top,
        background: icon.backgroundColor,
        border: icon.borderWidth,
        iconSource: document.querySelector(".brand-icon").src.startsWith("data:image/png"),
        imageCount: document.querySelectorAll(".slide-image").length,
      };
    });
    assert(metrics.width <= width && metrics.height <= height, `Page overflow: ${width}x${height}`);
    assert(metrics.buttonHeight >= 44, "Touch target too small");
    assert(metrics.headerBottom <= metrics.contentTop, "Header overlaps content");
    assert.equal(metrics.background, "rgba(0, 0, 0, 0)");
    assert.equal(metrics.border, "0px");
    assert.equal(metrics.iconSource, true);
    assert(metrics.imageCount <= 2);

    await page.getByTestId("setup.exit").click();
    assert.equal(await page.evaluate(() => window.__actions.at(-1)), "exit");
    await page.evaluate(() => window.ProtoDroidUI.setState({ isGameDataFound: false, statusMessage: "Waiting for file access" }));
    await page.waitForTimeout(300);
    await page.screenshot({ path: `${screenshots}/${width}x${height}.png` });
    console.log(`PASS ${width}x${height}: layout, icon, callbacks, permission, busy/found/revoked state`);

    if (width === 915) {
      const source = await page.locator(".slide-image").last().getAttribute("src");
      await page.waitForTimeout(7200);
      assert.notEqual(await page.locator(".slide-image").last().getAttribute("src"), source);
      assert(await page.locator(".slide-image").count() <= 2);
      await page.evaluate(() => window.ProtoDroidUI.setState({
        primaryPath: "/storage/emulated/0/Prototype/" + "custom-folder/".repeat(12),
        statusMessage: "A long host-provided status message ".repeat(8),
      }));
      await page.waitForTimeout(350);
      assert.equal(await access.isEnabled(), true);
      const buttonBottom = await access.evaluate((element) => element.getBoundingClientRect().bottom);
      assert(buttonBottom <= height, "Long status hides actions");
      console.log("PASS offline slideshow rotation, bounded image layers, long host state");
    }
    await page.close();
  }
  assert.deepEqual(errors, [], "Browser runtime errors");
  assert.deepEqual(remote, [], "Offline build must not make external HTTP requests");
  console.log("PASS all assets render offline; zero HTTP requests or browser errors");
} finally {
  await browser.close();
}