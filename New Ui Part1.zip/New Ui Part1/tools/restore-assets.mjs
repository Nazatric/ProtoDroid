import { createHash } from "node:crypto";
import { mkdir, readFile, rm, writeFile, copyFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve, dirname } from "node:path";
import { execFileSync } from "node:child_process";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const resources = "protodroid-compose/setupUi/src/commonMain/composeResources";
const web = "src/assets/img";
const notices = "protodroid-compose/licenses";
const sources = [];

async function download(url, destination) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${response.status}: ${url}`);
  const bytes = Buffer.from(await response.arrayBuffer());
  const path = resolve(root, destination);
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, bytes);
  return bytes;
}

function record(path, url, bytes) {
  sources.push({ path, source: url, sha256: createHash("sha256").update(bytes).digest("hex"), bytes: bytes.length });
}

// Maintenance tool only. Shipped builds never download these assets.
const iconUrl = "https://raw.githubusercontent.com/Nazatric/ProtoDroid/main/android/icon-512.png";
const iconPath = `${resources}/drawable/protodroid_icon.png`;
const icon = await download(iconUrl, iconPath);
if (!icon.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) {
  throw new Error("The repository icon is not a PNG");
}
record(iconPath, iconUrl, icon);
await mkdir(resolve(root, web), { recursive: true });
await copyFile(resolve(root, iconPath), resolve(root, `${web}/protodroid-icon.png`));
const launcher = resolve(root, "protodroid-compose/composeApp/src/androidMain/res/mipmap-xxxhdpi/ic_launcher.png");
await mkdir(dirname(launcher), { recursive: true });
await writeFile(launcher, icon);

for (const [index, id] of [8857, 8855, 8856, 8861].entries()) {
  const url = `https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/10150/000000${id}.1920x1080.jpg`;
  const path = `${resources}/drawable/bg_${index + 1}.jpg`;
  const original = await download(url, path);
  if (original[0] !== 255 || original[1] !== 216) throw new Error(`Invalid JPEG: ${url}`);
  execFileSync("convert", [resolve(root, path), "-resize", "1600x900", "-strip", "-quality", "76", resolve(root, path)]);
  const optimized = await readFile(resolve(root, path));
  record(path, url, optimized);
  await copyFile(resolve(root, path), resolve(root, `${web}/bg${index + 1}.jpg`));
}

for (const weight of ["Medium", "SemiBold", "Bold"]) {
  const url = `https://raw.githubusercontent.com/google/fonts/main/ofl/barlowcondensed/BarlowCondensed-${weight}.ttf`;
  const path = `${resources}/font/barlow_condensed_${weight.toLowerCase()}.ttf`;
  const bytes = await download(url, path);
  if (bytes.readUInt32BE(0) !== 0x00010000) throw new Error(`Invalid TTF: ${url}`);
  record(path, url, bytes);
}

await download("https://raw.githubusercontent.com/google/fonts/main/ofl/barlowcondensed/OFL.txt", `${notices}/BarlowCondensed-OFL.txt`);
await download("https://raw.githubusercontent.com/google/fonts/main/ofl/oswald/OFL.txt", `${notices}/Oswald-OFL.txt`);
await writeFile(resolve(root, "protodroid-compose/ASSETS.json"), JSON.stringify(sources, null, 2) + "\n");
await rm(resolve(root, "public/images"), { recursive: true, force: true });
console.log(`Restored ${sources.length} verified local assets. Original icon alpha is preserved.`);