"""Create an integration archive without build caches, demo binaries, or private SDK paths."""
import hashlib
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

root = Path(__file__).resolve().parents[1]
project = root / "protodroid-compose"
assets = json.loads((project / "ASSETS.json").read_text())
for asset in assets:
    path = root / asset["path"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != asset["sha256"]:
        raise SystemExit(f"Missing or changed bundled asset: {path}")

destination = root / "public" / "downloads" / "protodroid-setup-source.zip"
destination.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(destination, "w", compression=ZIP_DEFLATED) as archive:
    for path in sorted(project.rglob("*")):
        if not path.is_file() or any(part in {"build", ".gradle", ".kotlin"} for part in path.parts):
            continue
        if path.name == "local.properties":
            continue
        archive.write(path, path.relative_to(root))

print(f"Bundled {len(assets)} checksum-verified assets in {destination.relative_to(root)}")