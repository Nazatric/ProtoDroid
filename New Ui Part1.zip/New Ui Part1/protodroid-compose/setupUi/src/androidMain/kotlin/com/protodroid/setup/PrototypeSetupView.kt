package com.protodroid.setup

import android.content.Context
import android.util.AttributeSet
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.AbstractComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy

/** Optional Java/View adapter. Host it in a ComponentActivity; update uiState on the main thread. */
class PrototypeSetupView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : AbstractComposeView(context, attrs) {
    var uiState: PrototypeSetupUiState by mutableStateOf(PrototypeSetupUiState())
    var onAllowFileAccessClick: Runnable? = null
    var onCheckAgainClick: Runnable? = null
    var onExitClick: Runnable? = null

    init {
        setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
    }

    @Composable
    override fun Content() {
        PrototypeSetupScreen(
            state = uiState,
            onAllowFileAccessClick = { onAllowFileAccessClick?.run() },
            onCheckAgainClick = { onCheckAgainClick?.run() },
            onExitClick = { onExitClick?.run() },
        )
    }
}