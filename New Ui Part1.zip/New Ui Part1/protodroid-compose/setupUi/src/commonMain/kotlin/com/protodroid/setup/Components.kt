package com.protodroid.setup

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsHoveredAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Foundation-only text so the module needs no Material dependency. */
@Composable
internal fun Text(text: String, style: TextStyle, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) {
    BasicText(text = text, modifier = modifier, style = style, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

/* ---------------------------------------------------------------------------------------- */
/*  Entrance animation                                                                      */
/* ---------------------------------------------------------------------------------------- */

/** Fades + slides its content up after [delayMs]. Used to stagger the whole screen in. */
@Composable
internal fun Reveal(delayMs: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        shown = true
    }
    val p by animateFloatAsState(if (shown) 1f else 0f, tween(750, easing = OutQuart), label = "reveal")
    Box(
        modifier.graphicsLayer {
            alpha = p
            translationY = (1f - p) * 26.dp.toPx()
        },
    ) { content() }
}

/* ---------------------------------------------------------------------------------------- */
/*  Glitch text                                                                             */
/* ---------------------------------------------------------------------------------------- */

/** Text that tears sideways in a short red burst every few seconds. */
@Composable
internal fun GlitchText(text: String, style: TextStyle, modifier: Modifier = Modifier) {
    var shift by remember { mutableStateOf(0f) }
    var active by remember { mutableStateOf(false) }
    val running = LocalSetupActive.current
    LaunchedEffect(running) {
        active = false
        shift = 0f
        if (running) while (true) {
            delay(6500)
            repeat(4) { i ->
                active = true
                shift = if (i % 2 == 0) -5f else 4f
                delay(60)
            }
            active = false
            shift = 0f
        }
    }
    Box(modifier) {
        if (active) {
            Text(
                text = text,
                style = style.copy(color = ProtoColors.RedHot),
                modifier = Modifier.graphicsLayer { translationX = shift * 1.4f },
            )
        }
        Text(
            text = text,
            style = style,
            modifier = Modifier.graphicsLayer { translationX = if (active) -shift * 0.4f else 0f },
        )
    }
}

/* ---------------------------------------------------------------------------------------- */
/*  Prototype style action button                                                           */
/* ---------------------------------------------------------------------------------------- */

internal enum class ButtonVariant { Primary, Normal, Ghost, Done }

private val ButtonShape = CutCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomEnd = 9.dp, bottomStart = 0.dp)

/**
 * Angular dark button. On hover/press (and always for Primary) a jagged red fill sweeps in,
 * the brackets close in, a red splat bursts from the touch point and the device gives a tick.
 */
@Composable
internal fun GameButton(
    label: String,
    onPress: () -> Unit,
    font: FontFamily,
    modifier: Modifier = Modifier,
    variant: ButtonVariant = ButtonVariant.Normal,
    enabled: Boolean = true,
    busy: Boolean = false,
    height: Dp = 48.dp,
) {
    val interaction = remember { MutableInteractionSource() }
    val hovered by interaction.collectIsHoveredAsState()
    val pressed by interaction.collectIsPressedAsState()
    val focused by interaction.collectIsFocusedAsState()
    var splatAt by remember { mutableStateOf(Offset.Zero) }
    val splat = remember { Animatable(0f) }
    val haptic = LocalHapticFeedback.current
    val currentEnabled by rememberUpdatedState(enabled)
    val active = LocalSetupActive.current
    val fillPath = remember { Path() }
    val redBrush = remember { Brush.horizontalGradient(listOf(ProtoColors.RedDark, ProtoColors.Red, ProtoColors.RedHot)) }

    LaunchedEffect(interaction, haptic) {
        var rippleJob: Job? = null
        interaction.interactions.collect { event ->
            if (event is PressInteraction.Press && currentEnabled) {
                splatAt = event.pressPosition
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                rippleJob?.cancel()
                rippleJob = launch {
                    splat.snapTo(0f)
                    splat.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
                }
            }
        }
    }

    val live = busy || (enabled && (pressed || hovered || focused || variant == ButtonVariant.Primary))
    val fill = animateFloatAsState(if (live) 1f else 0f, tween(430, easing = OutQuart), label = "fill")
    val pressScale = animateFloatAsState(
        if (pressed) 0.965f else 1f,
        spring(stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    val bracketInset by animateDpAsState(if (live) 16.dp else 9.dp, tween(350, easing = OutQuart), label = "br")
    val bracketColor by animateColorAsState(
        when {
            variant == ButtonVariant.Done -> ProtoColors.Ok
            live -> ProtoColors.Bone
            else -> ProtoColors.RedHot.copy(alpha = 0.5f)
        },
        label = "brc",
    )

    val sweep = setupMotion(0f, 1f, 950, running = busy && active, reverse = false)
    val glow = setupMotion(0f, 1f, 1400, running = variant == ButtonVariant.Primary && enabled && active)

    val borderColor = when {
        variant == ButtonVariant.Done -> ProtoColors.Ok.copy(alpha = 0.55f)
        !enabled -> Color.White.copy(alpha = 0.12f)
        variant == ButtonVariant.Primary -> ProtoColors.RedHot.copy(alpha = 0.75f)
        else -> Color.White.copy(alpha = 0.24f)
    }
    val textColor = when {
        variant == ButtonVariant.Done -> ProtoColors.Ok
        !enabled -> ProtoColors.Dim
        else -> ProtoColors.Bone
    }

    BoxWithConstraints(
        modifier = modifier
            .heightIn(min = 48.dp)
            .height(height)
            .graphicsLayer {
                scaleX = pressScale.value
                scaleY = pressScale.value
                alpha = if (!enabled && !busy && variant != ButtonVariant.Done) 0.55f else 1f
                shape = ButtonShape
                clip = true
            }
            .background(Color(0xA3080808))
            .border(1.dp, borderColor, ButtonShape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled,
                role = Role.Button, onClickLabel = label, onClick = onPress),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            val f = fill.value
            if (f > 0.002f) {
                val edge = w * f
                val jag = h * 0.3f * f
                fillPath.rewind()
                val path = fillPath.apply {
                    moveTo(0f, 0f)
                    lineTo(edge, 0f)
                    lineTo(edge + jag, h / 3f)
                    lineTo(edge, 2f * h / 3f)
                    lineTo(edge, h)
                    lineTo(0f, h)
                    close()
                }
                drawPath(
                    path,
                    redBrush,
                )
                if (variant == ButtonVariant.Primary) {
                    drawPath(path, Color.White.copy(alpha = 0.07f * glow.value))
                }
            }
            val s = splat.value
            if (s > 0f && s < 1f) {
                val r = s * w * 0.8f + 1f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFF4A3D).copy(alpha = 1f - s),
                            Color(0xFFFF2B2B).copy(alpha = (1f - s) * 0.65f),
                            Color.Transparent,
                        ),
                        center = splatAt,
                        radius = r,
                    ),
                    radius = r,
                    center = splatAt,
                )
            }
            if (busy) {
                val barW = w * 0.35f
                val x = -barW + sweep.value * (w + barW)
                drawRect(Color.White, Offset(x, h - 3.dp.toPx()), Size(barW, 3.dp.toPx()))
            }
        }

        Text(
            text = "[",
            style = protoStyle(font, 22f, FontWeight.Normal, color = bracketColor),
            modifier = Modifier.align(Alignment.CenterStart).padding(start = bracketInset),
        )
        Text(
            text = label,
            style = protoStyle(font, if (maxWidth < 160.dp) 11.5f else 13f, FontWeight.SemiBold, 1.4f, textColor),
            modifier = Modifier.padding(horizontal = 26.dp),
            maxLines = 1,
        )
        Text(
            text = "]",
            style = protoStyle(font, 22f, FontWeight.Normal, color = bracketColor),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = bracketInset),
        )
    }
}

/* ---------------------------------------------------------------------------------------- */
/*  Status tile (Storage access / Game data)                                                */
/* ---------------------------------------------------------------------------------------- */

@Composable
internal fun StatusTile(
    label: String,
    value: String,
    ok: Boolean,
    font: FontFamily,
    modifier: Modifier = Modifier,
) {
    val color by animateColorAsState(if (ok) ProtoColors.Ok else ProtoColors.RedHot, tween(500), label = "tile")
    val tileShape = remember { CutCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomEnd = 8.dp, bottomStart = 0.dp) }

    Row(
        modifier = modifier
            .heightIn(min = 48.dp)
            .semantics(mergeDescendants = true) { stateDescription = "$label: $value" }
            .graphicsLayer { shape = tileShape; clip = true }
            .background(color.copy(alpha = 0.14f))
            .padding(end = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.width(3.dp).height(48.dp).background(color))
        StatusIndicator(ok = ok, color = color)
        Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(label, style = protoStyle(font, 9.5f, FontWeight.Medium, 2.0f, ProtoColors.Dim))
            Text(value, style = protoStyle(font, 15.5f, FontWeight.SemiBold, 1.6f, color))
        }
    }
}

@Composable
private fun StatusIndicator(ok: Boolean, color: Color) {
    val check by animateFloatAsState(if (ok) 1f else 0f, tween(550, easing = OutQuart), label = "check")
    val pulse = setupMotion(0.25f, 1f, 850, running = !ok && LocalSetupActive.current)
    val measure = remember { PathMeasure() }
    val segment = remember { Path() }
    val tick = remember { Path() }

    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val h = size.height
        drawCircle(color.copy(alpha = 0.55f), radius = w / 2f - 1.5.dp.toPx(), style = Stroke(1.5.dp.toPx()))
        val dotAlpha = (1f - check) * pulse.value
        if (dotAlpha > 0.01f) {
            drawCircle(color.copy(alpha = dotAlpha), radius = w * 0.17f)
            drawCircle(color.copy(alpha = dotAlpha * 0.25f), radius = w * 0.3f)
        }
        if (check > 0.01f) {
            tick.rewind()
            tick.moveTo(w * 0.27f, h * 0.53f)
            tick.lineTo(w * 0.44f, h * 0.70f)
            tick.lineTo(w * 0.76f, h * 0.32f)
            measure.setPath(tick, false)
            segment.rewind()
            measure.getSegment(0f, measure.length * check, segment, true)
            drawPath(
                segment,
                color,
                style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
    }
}

/* ---------------------------------------------------------------------------------------- */
/*  Directory panel (translucent, so the artwork stays visible behind it)                   */
/* ---------------------------------------------------------------------------------------- */

private val PanelShape = CutCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomEnd = 12.dp, bottomStart = 0.dp)

internal data class PathEntry(val tag: String, val path: String, val note: String)

@Composable
internal fun PathPanel(title: String, entries: List<PathEntry>, font: FontFamily, modifier: Modifier = Modifier) {
    val edge = setupMotion(0.35f, 1f, 1800, running = LocalSetupActive.current)

    Box(
        modifier
            .fillMaxWidth()
            .graphicsLayer { shape = PanelShape; clip = true }
            .background(Color(0xB8050505))
            .border(1.dp, Color.White.copy(alpha = 0.16f), PanelShape),
    ) {
        Box(Modifier.matchParentSize()) {
            Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .graphicsLayer { alpha = edge.value }
                    .background(ProtoColors.RedHot),
            )
        }
        Column(
            Modifier.padding(start = 16.dp, end = 14.dp, top = 10.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(title, protoStyle(font, 10.5f, FontWeight.Medium, 2.4f, Color(0xFFD5CFC6)))
            entries.forEachIndexed { i, e ->
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                    Text(
                        text = "0${i + 1}",
                        style = protoStyle(font, 26f, FontWeight.Bold, color = Color.White.copy(alpha = 0.35f)),
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(e.tag, protoStyle(font, 9f, FontWeight.Medium, 2.4f, ProtoColors.RedHot))
                        Text(e.path, protoStyle(font, 13f, FontWeight.SemiBold, 0.2f, Color(0xFFF1ECE3), lineHeight = 14f))
                        Text(e.note, protoStyle(font, 10.5f, FontWeight.Medium, 0.6f, ProtoColors.Dim))
                    }
                }
            }
        }
    }
}

/* ---------------------------------------------------------------------------------------- */
/*  Small pieces                                                                            */
/* ---------------------------------------------------------------------------------------- */

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun RequirementChips(items: List<String>, font: FontFamily) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        items.forEachIndexed { i, item ->
            Reveal(delayMs = 1000 + i * 50) {
                Text(
                    text = item,
                    style = protoStyle(font, 10.5f, FontWeight.Medium, 0.8f, Color(0xFFCFC9C0)),
                    modifier = Modifier
                        .background(Color(0x66000000))
                        .border(1.dp, Color.White.copy(alpha = 0.2f))
                        .padding(horizontal = 7.dp, vertical = 2.dp),
                )
            }
        }
    }
}

/** Thin HUD rule that draws itself in from the left, with a short red lead. */
@Composable
internal fun HudRule(delayMs: Int, modifier: Modifier = Modifier) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        p.animateTo(1f, tween(1200, easing = OutQuart))
    }
    Canvas(modifier.fillMaxWidth().height(2.dp)) {
        val w = size.width * p.value
        drawRect(Color.White.copy(alpha = 0.18f), Offset.Zero, Size(w, 1.dp.toPx()))
        drawRect(ProtoColors.RedHot, Offset.Zero, Size(minOf(w, 44.dp.toPx()), 2.dp.toPx()))
    }
}
