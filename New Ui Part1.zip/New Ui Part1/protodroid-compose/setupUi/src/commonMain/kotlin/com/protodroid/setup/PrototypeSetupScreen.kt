package com.protodroid.setup

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import com.protodroid.setup.resources.Res
import com.protodroid.setup.resources.protodroid_icon
import org.jetbrains.compose.resources.painterResource

private val RequiredItems = listOf("prototypeenginef.dll", ".rcf", ".p3d", "art", "audio", "scripts")

/** The layout is designed for a 360dp tall landscape screen and scaled uniformly to fit any real height. */
private const val DesignHeightDp = 360f

/**
 * ProtoDroid first-launch setup screen (landscape).
 *
 * Stateless: render [state], report taps through the callbacks.
 */
@Composable
fun PrototypeSetupScreen(
    state: PrototypeSetupUiState,
    onAllowFileAccessClick: () -> Unit,
    onCheckAgainClick: () -> Unit,
    onExitClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val font = rememberProtoFont()
    val active = rememberSetupActive()

    CompositionLocalProvider(LocalSetupActive provides active) {
        Box(modifier.fillMaxSize().clipToBounds().testTag("setup.screen")) {
            PrototypeBackdrop()
            // Consume physical insets before changing the design density.
            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val base = LocalDensity.current
                    val scale = minOf(maxHeight.value / DesignHeightDp, maxWidth.value / 760f).coerceIn(0.65f, 2.2f)
                    CompositionLocalProvider(LocalDensity provides Density(base.density * scale, base.fontScale)) {
                        Column(Modifier.fillMaxSize().padding(horizontal = 26.dp, vertical = 12.dp)) {
                            Header(font, onExitClick)
                            HudRule(delayMs = 700, modifier = Modifier.padding(top = 4.dp))
                            Row(
                                Modifier.weight(1f).fillMaxWidth().padding(top = 10.dp),
                                horizontalArrangement = Arrangement.spacedBy(28.dp),
                            ) {
                                StatusColumn(state, font, onAllowFileAccessClick, onCheckAgainClick,
                                    Modifier.weight(1f).fillMaxHeight())
                                PathsColumn(state, font, Modifier.weight(1f).fillMaxHeight())
                            }
                        }
                    }
                }
            }
            BootCurtain()
        }
    }
}

@Composable
private fun Header(font: FontFamily, onExitClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Reveal(delayMs = 550) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(
                    painter = painterResource(Res.drawable.protodroid_icon),
                    contentDescription = "Prototype",
                    modifier = Modifier.size(46.dp),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("[", protoStyle(font, 26f, FontWeight.Medium, color = ProtoColors.RedHot))
                    GlitchText("PROTOTYPE", protoStyle(font, 25f, FontWeight.Bold, 0.8f))
                    Text("]", protoStyle(font, 26f, FontWeight.Medium, color = ProtoColors.RedHot))
                }
            }
        }
        Reveal(delayMs = 650) {
            GameButton(
                label = "EXIT",
                onPress = onExitClick,
                font = font,
                variant = ButtonVariant.Ghost,
                modifier = Modifier.width(96.dp).testTag("setup.exit"),
            )
        }
    }
}

@Composable
private fun StatusColumn(
    state: PrototypeSetupUiState,
    font: FontFamily,
    onAllowFileAccessClick: () -> Unit,
    onCheckAgainClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val found = state.isGameDataFound
    val lineTwoColor by animateColorAsState(if (found) ProtoColors.Ok else ProtoColors.RedHot, tween(500), label = "h2")

    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(11.dp, Alignment.CenterVertically)) {
        Reveal(delayMs = 500) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusTile(
                    label = "STORAGE ACCESS",
                    value = if (state.hasFileAccessPermission) "GRANTED" else "REQUIRED",
                    ok = state.hasFileAccessPermission,
                    font = font,
                    modifier = Modifier.weight(1f),
                )
                StatusTile(
                    label = "GAME DATA",
                    value = if (found) "DETECTED" else "NOT FOUND",
                    ok = found,
                    font = font,
                    modifier = Modifier.weight(1f),
                )
            }
        }

        Reveal(delayMs = 650) {
            Column {
                GlitchText(
                    text = if (found) "GAME DATA" else "GAME FILES",
                    style = protoStyle(font, 38f, FontWeight.Bold, 0.2f, lineHeight = 38f),
                )
                Text(
                    text = if (found) "FOUND" else "NOT FOUND",
                    style = protoStyle(font, 38f, FontWeight.Bold, 0.2f, lineTwoColor, lineHeight = 38f),
                )
            }
        }

        Reveal(delayMs = 780) { StatusLine(state.statusMessage, font) }

        Reveal(delayMs = 880) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GameButton(
                    label = if (state.hasFileAccessPermission) "ACCESS ALLOWED" else "ALLOW FILE ACCESS",
                    onPress = onAllowFileAccessClick,
                    font = font,
                    variant = if (state.hasFileAccessPermission) ButtonVariant.Done else ButtonVariant.Primary,
                    enabled = !state.hasFileAccessPermission,
                    modifier = Modifier.weight(1f).testTag("setup.allowAccess"),
                )
                GameButton(
                    label = if (state.isChecking) "CHECKING" else "CHECK AGAIN",
                    onPress = onCheckAgainClick,
                    font = font,
                    variant = if (state.hasFileAccessPermission && !found) ButtonVariant.Primary else ButtonVariant.Normal,
                    enabled = !state.isChecking,
                    busy = state.isChecking,
                    modifier = Modifier.weight(1f).testTag("setup.checkAgain"),
                )
            }
        }
    }
}

/** Terminal style status message with a blinking caret. */
@Composable
private fun StatusLine(message: String, font: FontFamily) {
    val caret = setupMotion(0.25f, 1f, 700, running = LocalSetupActive.current)
    Row(Modifier.heightIn(min = 30.dp).semantics { liveRegion = LiveRegionMode.Polite }.testTag("setup.status"),
        verticalAlignment = Alignment.CenterVertically) {
        Text(">", protoStyle(font, 12f, FontWeight.SemiBold, color = ProtoColors.RedHot), Modifier.padding(end = 6.dp))
        Crossfade(targetState = message, animationSpec = tween(220), label = "status", modifier = Modifier.weight(1f, fill = false)) { m ->
            Text(m, protoStyle(font, 12f, FontWeight.Medium, 1f, ProtoColors.Bone), maxLines = 2)
        }
        Box(
            Modifier
                .padding(start = 4.dp)
                .size(width = 6.dp, height = 11.dp)
                .graphicsLayer { alpha = caret.value }
                .background(ProtoColors.RedHot),
        )
    }
}

/** Sits low on the right so the top of the artwork stays completely clear. */
@Composable
private fun PathsColumn(state: PrototypeSetupUiState, font: FontFamily, modifier: Modifier = Modifier) {
    Column(modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.Bottom)) {
        Reveal(delayMs = 950, modifier = Modifier.fillMaxWidth()) {
            PathPanel(
                title = "PLACE YOUR PC GAME FILES IN",
                entries = listOf(
                    PathEntry(
                        tag = "RECOMMENDED",
                        path = state.primaryPath,
                        note = if (state.hasFileAccessPermission) "File access granted. /game also supported" else "Any file manager. Needs file access",
                    ),
                    PathEntry(
                        tag = "APP PRIVATE",
                        path = state.secondaryPath,
                        note = "Android 11+: copy from a PC over USB",
                    ),
                ),
                font = font,
            )
        }
        RequirementChips(RequiredItems, font)
    }
}
