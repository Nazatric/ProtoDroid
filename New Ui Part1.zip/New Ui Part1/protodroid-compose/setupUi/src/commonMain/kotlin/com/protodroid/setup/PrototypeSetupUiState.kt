package com.protodroid.setup

import androidx.compose.runtime.Immutable

/**
 * Everything the setup screen renders. The screen never decides anything on its own:
 * the backend pushes a new state in, the screen draws it.
 *
 * [isChecking] is an optional extra (defaults to false) that drives the busy animation
 * on the "Check again" button while a scan is running.
 */
@Immutable
data class PrototypeSetupUiState(
    val hasFileAccessPermission: Boolean = false,
    val isGameDataFound: Boolean = false,
    val statusMessage: String = "INITIALIZING...",
    val primaryPath: String = "/storage/emulated/0/Prototype",
    val secondaryPath: String = "/storage/emulated/0/Android/data/com.protodroid/files/game",
    val isChecking: Boolean = false,
)
