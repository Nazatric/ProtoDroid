package com.protodroid.setup

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.ContentScale
import com.protodroid.setup.resources.Res
import com.protodroid.setup.resources.bg_1
import com.protodroid.setup.resources.bg_2
import com.protodroid.setup.resources.bg_3
import com.protodroid.setup.resources.bg_4
import kotlinx.coroutines.delay
import org.jetbrains.compose.resources.painterResource

/** Original Prototype (2009) screenshots, bundled in composeResources/drawable. */
private val Slides = listOf(Res.drawable.bg_1, Res.drawable.bg_2, Res.drawable.bg_3, Res.drawable.bg_4)

private const val SlideHoldMs = 6500L

/** Everything behind the UI: the Prototype artwork slideshow plus the dimming needed for legibility. */
@Composable
internal fun PrototypeBackdrop(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().clipToBounds().background(ProtoColors.Black)) {
        ArtworkSlideshow()
        Scrims()
    }
}

@Composable
private fun ArtworkSlideshow() {
    var sequence by remember { mutableIntStateOf(0) }
    val active = LocalSetupActive.current
    LaunchedEffect(active) {
        if (active) while (true) {
            delay(SlideHoldMs)
            sequence += 1
        }
    }

    Crossfade(targetState = sequence, animationSpec = tween(1100), label = "slides") { frame ->
        val zoom = remember { Animatable(1.04f) }
        LaunchedEffect(active) {
            if (active) zoom.animateTo(1.12f, tween(8000, easing = LinearEasing))
        }
        Image(
            painter = painterResource(Slides[frame % Slides.size]),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = zoom.value
                scaleY = zoom.value
            },
        )
    }

    // Red streak that sweeps across whenever the picture changes.
    val flash = remember { Animatable(1f) }
    LaunchedEffect(sequence, active) {
        if (sequence > 0 && active) {
            flash.snapTo(0f)
            flash.animateTo(1f, tween(950, easing = FastOutSlowInEasing))
        } else flash.snapTo(1f)
    }
    Canvas(Modifier.fillMaxSize()) {
        val f = flash.value
        if (f > 0f && f < 1f) {
            val band = size.width * 0.4f
            val x = (f * 1.5f - 0.25f) * size.width
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color.Transparent, Color(0x80FF463C), Color.Transparent),
                    startX = x - band / 2f,
                    endX = x + band / 2f,
                ),
                blendMode = BlendMode.Screen,
            )
        }
    }
}

/** Dark on the left where the text sits, nearly clear on the right so the artwork reads. */
@Composable
private fun Scrims() {
    Box(
        Modifier.fillMaxSize().background(
            Brush.horizontalGradient(
                0f to Color(0xE6000000),
                0.38f to Color(0xA6000000),
                0.62f to Color(0x2E000000),
                1f to Color(0x14000000),
            ),
        ),
    )
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                0f to Color(0x99000000),
                0.2f to Color.Transparent,
                0.62f to Color.Transparent,
                1f to Color(0xB3000000),
            ),
        ),
    )
}

/** Black cover torn away by a red edge when the screen first appears. */
@Composable
internal fun BootCurtain() {
    val progress = remember { Animatable(0f) }
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(150)
        progress.animateTo(1f, tween(1100, easing = CubicBezierEasing(0.7f, 0f, 0.2f, 1f)))
        done = true
    }
    if (done) return
    Canvas(Modifier.fillMaxSize()) {
        val x = size.width * progress.value * 1.03f
        drawRect(
            color = ProtoColors.Black,
            topLeft = Offset(x, 0f),
            size = Size((size.width - x).coerceAtLeast(0f) + 2f, size.height),
        )
        drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, Color(0x99FF2B2B)),
                startX = x - 90f,
                endX = x,
            ),
            topLeft = Offset(x - 90f, 0f),
            size = Size(90f, size.height),
        )
        drawRect(ProtoColors.RedHot, Offset(x - 3f, 0f), Size(3f, size.height))
    }
}
