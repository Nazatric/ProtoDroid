package com.protodroid.setup

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState

internal val LocalSetupActive = staticCompositionLocalOf { true }

@Composable
internal fun rememberSetupActive(): Boolean {
    val state by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    return state.isAtLeast(Lifecycle.State.STARTED)
}

/** Infinite animations only exist while their visual effect is actually needed. */
@Composable
internal fun setupMotion(from: Float, to: Float, duration: Int, running: Boolean, reverse: Boolean = true): State<Float> {
    if (!running) return rememberUpdatedState(from)
    val transition = rememberInfiniteTransition(label = "setup.motion")
    return transition.animateFloat(from, to,
        infiniteRepeatable(tween(duration, easing = LinearEasing), if (reverse) RepeatMode.Reverse else RepeatMode.Restart),
        label = "setup.progress")
}