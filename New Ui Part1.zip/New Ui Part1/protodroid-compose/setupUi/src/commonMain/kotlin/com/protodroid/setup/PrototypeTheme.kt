package com.protodroid.setup

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.protodroid.setup.resources.Res
import com.protodroid.setup.resources.barlow_condensed_bold
import com.protodroid.setup.resources.barlow_condensed_medium
import com.protodroid.setup.resources.barlow_condensed_semibold
import org.jetbrains.compose.resources.Font

internal object ProtoColors {
    val Red = Color(0xFFC9141A)
    val RedDark = Color(0xFF7D0B10)
    val RedHot = Color(0xFFFF2B2B)
    val Bone = Color(0xFFECE8E1)
    val Dim = Color(0xFFA9A49B)
    val Ok = Color(0xFF8FE07A)
    val Black = Color(0xFF000000)
}

internal val OutQuart = CubicBezierEasing(0.25f, 1f, 0.5f, 1f)

/** Barlow Condensed (OFL), bundled in composeResources/font. */
@Composable
internal fun rememberProtoFont(): FontFamily {
    val medium = Font(Res.font.barlow_condensed_medium, FontWeight.Medium)
    val semi = Font(Res.font.barlow_condensed_semibold, FontWeight.SemiBold)
    val bold = Font(Res.font.barlow_condensed_bold, FontWeight.Bold)
    return remember(medium, semi, bold) { FontFamily(medium, semi, bold) }
}

internal fun protoStyle(
    font: FontFamily,
    size: Float,
    weight: FontWeight = FontWeight.Medium,
    spacing: Float = 0f,
    color: Color = ProtoColors.Bone,
    lineHeight: Float? = null,
): TextStyle = TextStyle(
    fontFamily = font,
    fontSize = size.sp,
    fontWeight = weight,
    letterSpacing = spacing.sp,
    color = color,
    lineHeight = (lineHeight ?: 0f).let { if (it > 0f) it.sp else androidx.compose.ui.unit.TextUnit.Unspecified },
)
