package com.protodroid.setup

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class PrototypeSetupUiStateTest {
    @Test
    fun initialStateNeverClaimsPermissionOrData() {
        val state = PrototypeSetupUiState()
        assertFalse(state.hasFileAccessPermission)
        assertFalse(state.isGameDataFound)
        assertFalse(state.isChecking)
    }

    @Test
    fun aScanDoesNotGrantStoragePermission() {
        val original = PrototypeSetupUiState()
        val checking = original.copy(isChecking = true, statusMessage = "Checking")
        assertTrue(checking.isChecking)
        assertFalse(checking.hasFileAccessPermission)
        assertEquals("INITIALIZING...", original.statusMessage)
    }

    @Test
    fun privateDataCanBeFoundWithoutSharedStoragePermission() {
        val state = PrototypeSetupUiState(isGameDataFound = true)
        assertTrue(state.isGameDataFound)
        assertFalse(state.hasFileAccessPermission)
    }
}