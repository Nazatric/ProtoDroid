package com.protodroid.setup

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * PREVIEW HARNESS ONLY. Pretends to be the backend so the screen can be run on its own
 * (Android preview shell and the Kotlin/Wasm browser build). Do not ship this in the real app:
 * call [PrototypeSetupScreen] directly and feed it real state.
 */
@Composable
fun PrototypeSetupPreview() {
    var state by remember {
        mutableStateOf(PrototypeSetupUiState(statusMessage = "Waiting for file access"))
    }
    val scope = rememberCoroutineScope()

    PrototypeSetupScreen(
        state = state,
        onAllowFileAccessClick = {
            scope.launch {
                state = state.copy(statusMessage = "Opening file access settings")
                delay(1200)
                state = state.copy(hasFileAccessPermission = true, statusMessage = "File access granted. Copy your game files")
            }
        },
        onCheckAgainClick = {
            scope.launch {
                state = state.copy(isChecking = true, statusMessage = "Searching for prototypeenginef.dll")
                delay(1800)
                state = state.copy(
                    isChecking = false,
                    isGameDataFound = false,
                    statusMessage = if (state.hasFileAccessPermission) "Game files not found" else "Allow file access first",
                )
            }
        },
        onExitClick = { state = state.copy(statusMessage = "Exit pressed") },
    )
}
