# ProtoDroid Setup UI

The approved landscape setup screen, packaged as a reusable Kotlin + Compose Multiplatform library for Android and Kotlin/Wasm. All artwork, the original transparent icon, and fonts are local.

## Production Module

Import **`setupUi/`**, not `composeApp/`. The API remains `PrototypeSetupScreen(state, onAllowFileAccessClick, onCheckAgainClick, onExitClick, modifier)`.

- `setupUi/src/commonMain/kotlin/com/protodroid/setup/PrototypeSetupScreen.kt`: stateless screen.
- `PrototypeSetupUiState.kt`: immutable host-owned flags, messages, paths, and optional scan-busy flag.
- `Components.kt`, `Backdrop.kt`, `SetupMotion.kt`, `PrototypeTheme.kt`: internal presentation.
- `setupUi/src/androidMain/.../PrototypeSetupView.kt`: optional Java/View adapter.
- `setupUi/src/commonMain/composeResources/`: bundled artwork, original PNG, and fonts.

**[INTEGRATION.md](INTEGRATION.md)** contains the existing-backend mapping, Java/Kotlin host examples, lifecycle handling, build commands, and integration checks.

`composeApp/` is only a demonstration shell. Its fake state, launcher, and application ID must not replace those of the game.

## Assets

`ASSETS.json` records sources, byte sizes, and SHA-256 checksums. Font licenses are in `licenses/`; no credits or technical capability badges appear on the screen. The icon keeps its original alpha, with no added plate, border, or crop.

The repository-root `tools/restore-assets.mjs` is an optional maintenance utility, not a runtime dependency or build hook. Normal builds use files already present in the module.