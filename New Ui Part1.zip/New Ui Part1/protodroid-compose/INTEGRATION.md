# Integration Handoff

## What To Import

`setupUi/` is the production Compose Multiplatform library. It contains the screen, immutable UI state, original PNG icon, four local screenshots, fonts, and the Android View adapter.

`composeApp/` is a separate runnable demonstration. Do not copy its preview state simulation, manifest, application ID, or launcher Activity into the game.

The library never requests permissions, inspects storage, launches the engine, closes an Activity, or makes network calls. Those remain owned by the existing application.

## Add The Library

1. Copy `setupUi/` into the source project and add `include(":setupUi")` to its settings file.
2. Merge the required plugin/dependency aliases from `gradle/libs.versions.toml`, using versions compatible with the host's Kotlin/Compose compiler. This sample uses Kotlin 2.1.21, CMP 1.8.2, AGP 8.7.3, and lifecycle-runtime-compose 2.9.1.
3. Add `implementation(project(":setupUi"))` to the host application's dependencies. Keep the resource configuration and `composeResources` directory together.

For a CMP host, add the dependency to `commonMain`. For an Android-only host, add it to the Android app's `dependencies` block and enable Compose there.

Do not change the game's `com.protodroid` application ID or replace its manifest. The library has no launcher and requests no Android permissions.

The linked repository also has a shell/javac packaging pipeline. That pipeline must include the Compose/Kotlin runtime and generated resources, or consume a Gradle-enabled UI host as part of the rebuilt app. Copying source files into an already-compiled APK cannot install this screen. The existing engine/SDL code needs no UI-related changes.

## Compose Host

Keep the screen mounted and update its state after scans; do not replace it on every result.

```kotlin
PrototypeSetupScreen(
    state = setupState,
    onAllowFileAccessClick = ::requestAccess,
    onCheckAgainClick = ::check,
    onExitClick = ::finish,
)
```

`isChecking` is an optional field defaulting to `false`. Set it before scanning and clear it on all completion/error paths. Run filesystem work off the main thread and publish UI state back on the main thread.

## Java Or View Host

`PrototypeSetupView` exposes `Runnable` callbacks and `setUiState`. Host it in a `ComponentActivity` (or provide equivalent lifecycle/saved-state owners), not a plain `android.app.Activity`. Add the Activity Compose dependency to that host if necessary.

```java
// Create once; retain this view across permission and status refreshes.
setupView = new PrototypeSetupView(this);
setupView.setOnAllowFileAccessClick(this::requestAccess);
setupView.setOnCheckAgainClick(this::check);
setupView.setOnExitClick(this::finish);
setContentView(setupView);

// Render a backend result on the main thread.
setupView.setUiState(new PrototypeSetupUiState(
    hasSharedAccess(), gameDataWasFound, statusMessage,
    sharedGamePath, privateGamePath, scanIsRunning
));
```

The adapter disposes with the host lifecycle. Callbacks are read at click time, so rebinding them never leaves stale handlers behind.

## Map The Existing Backend

| UI input/action | Existing integration point |
| --- | --- |
| `hasFileAccessPermission` | `hasSharedAccess()` / actual permission result |
| `isGameDataFound` | Actual directory and `prototypeenginef.dll` detection |
| `statusMessage` | Current backend status or error |
| `primaryPath` | Actual shared game folder |
| `secondaryPath` | Actual app-specific `files/game` folder |
| Allow access | `requestAccess()` |
| Check again | `check()` |
| Exit | `finish()` |

Re-query permission when returning from Settings, including denial, cancellation, and revocation. Opening the intent does not grant permission. App-private data can be valid even when shared-storage access is false. Preserve the existing search order and engine-launch behavior.

## Host Configuration

Keep the setup Activity in `sensorLandscape` and apply immersive system-bar handling in the host. The screen never changes orientation or opens system UI. Physical insets are consumed before design scaling, so the cutout cannot cover the icon or Exit button.

Persistent effects pause when the screen lifecycle is stopped. State updates do not replay the curtain or reset the slideshow. Content regions can scroll only when needed for unusually long paths or large accessibility fonts.

## Verification Checklist

- Denied, cancelled, and revoked access never show Granted.
- App-private data can be found without shared access.
- Check Again emits one activation and is disabled while `isChecking` is true.
- A successful scan updates Game Data without granting storage access.
- Exit calls the host callback only.
- Cutouts, long paths, and returning from Settings do not remount the screen.
- Airplane-mode launch uses all four packaged images and the local font/icon.

Stable test tags: `setup.screen`, `setup.allowAccess`, `setup.checkAgain`, `setup.exit`, `setup.status`.

## Build

Use Gradle 8.11.1 and JDK 17, or the compatible wrapper in the host:

```sh
gradle :setupUi:assembleDebug
gradle :setupUi:compileKotlinWasmJs
gradle :setupUi:compileTestKotlinWasmJs
gradle :composeApp:assembleDebug
gradle :composeApp:wasmJsBrowserDevelopmentRun
```

The AAR is a normal library, not a fat AAR: host Gradle must resolve Compose/Kotlin/lifecycle dependencies. Source-project integration is preferred.