import groovy.json.JsonSlurper
import java.util.Base64

plugins {
    id("org.jetbrains.kotlin.multiplatform")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.compose")
    id("com.android.application")
}

group = "com.protodroid"
version = "1.0.0"

// Decode the checked-in text asset catalogue before Compose Resources generates accessors.
val embeddedAssets = rootProject.file("composeApp/launcher-assets.json")
val resourcesRoot = layout.projectDirectory.dir("src/commonMain/composeResources").asFile
if (embeddedAssets.exists()) {
    @Suppress("UNCHECKED_CAST")
    val entries = JsonSlurper().parseText(embeddedAssets.readText()) as Map<String, String>
    entries.forEach { (key, dataUrl) ->
        val mime = Regex("^data:([^;]+);base64,").find(dataUrl)?.groupValues?.get(1)
            ?: error("Invalid embedded asset: $key")
        val encoded = dataUrl.substringAfter("base64,")
        val (folder, name) = when {
            key == "icon" -> "drawable" to "launcher_icon.png"
            key.startsWith("wall-") || key.startsWith("intro-") || key.startsWith("bink-") ->
                "drawable" to "${key.replace('-', '_')}.webp"
            key.startsWith("compose-font-") ->
                "font" to "${key.removePrefix("compose-font-")}.ttf"
            else -> error("Unknown launcher asset: $key ($mime)")
        }
        val output = resourcesRoot.resolve("$folder/$name")
        output.parentFile.mkdirs()
        val bytes = Base64.getDecoder().decode(encoded)
        if (!output.exists() || !output.readBytes().contentEquals(bytes)) output.writeBytes(bytes)
    }
}

kotlin {
    androidTarget()

    wasmJs {
        browser()
        binaries.executable()
    }

    sourceSets {
        commonMain.dependencies {
            implementation(compose.runtime)
            implementation(compose.foundation)
            implementation(compose.material3)
            implementation(compose.ui)
            implementation(compose.components.resources)
            implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")
        }
        androidMain.dependencies {
            implementation("androidx.activity:activity-compose:1.10.1")
        }
    }
}

compose.resources {
    publicResClass = true
    packageOfResClass = "com.protodroid.launcher.generated.resources"
}

android {
    namespace = "com.protodroid.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.protodroid.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    sourceSets["main"].manifest.srcFile("src/androidMain/AndroidManifest.xml")
}