package com.protodroid.launcher

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.protodroid.launcher.generated.resources.Res
import com.protodroid.launcher.generated.resources.bink_01
import com.protodroid.launcher.generated.resources.bink_02
import com.protodroid.launcher.generated.resources.bink_03
import com.protodroid.launcher.generated.resources.bink_04
import com.protodroid.launcher.generated.resources.bink_05
import com.protodroid.launcher.generated.resources.bink_06
import com.protodroid.launcher.generated.resources.bink_07
import com.protodroid.launcher.generated.resources.bink_08
import com.protodroid.launcher.generated.resources.bink_09
import com.protodroid.launcher.generated.resources.bink_10
import com.protodroid.launcher.generated.resources.intro_03
import com.protodroid.launcher.generated.resources.intro_06
import com.protodroid.launcher.generated.resources.intro_09
import com.protodroid.launcher.generated.resources.intro_11
import com.protodroid.launcher.generated.resources.intro_12
import com.protodroid.launcher.generated.resources.intro_13
import com.protodroid.launcher.generated.resources.launcher_icon
import com.protodroid.launcher.generated.resources.wall_ashen_profile
import com.protodroid.launcher.generated.resources.wall_biomass_title
import com.protodroid.launcher.generated.resources.wall_blacklight_portrait
import com.protodroid.launcher.generated.resources.wall_claw_white
import com.protodroid.launcher.generated.resources.wall_manhattan_smoke
import com.protodroid.launcher.generated.resources.wall_mercer_city
import com.protodroid.launcher.generated.resources.wall_mercer_cityline
import com.protodroid.launcher.generated.resources.wall_mercer_fog
import com.protodroid.launcher.generated.resources.wall_mercer_silhouette
import com.protodroid.launcher.generated.resources.wall_mercer_urban
import com.protodroid.launcher.generated.resources.wall_quarantine_city
import com.protodroid.launcher.generated.resources.wall_sunset_helicopters
import com.protodroid.launcher.generated.resources.wall_viral_title
import com.protodroid.launcher.generated.resources.wall_white_biomass
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource
import kotlin.math.roundToInt

private val homeScenes = listOf(
    Res.drawable.wall_mercer_city,
    Res.drawable.wall_blacklight_portrait,
    Res.drawable.wall_biomass_title,
    Res.drawable.wall_sunset_helicopters,
    Res.drawable.wall_ashen_profile,
    Res.drawable.wall_viral_title,
    Res.drawable.wall_claw_white,
    Res.drawable.wall_mercer_silhouette,
    Res.drawable.wall_mercer_fog,
    Res.drawable.wall_mercer_cityline,
    Res.drawable.wall_white_biomass,
    Res.drawable.wall_quarantine_city,
    Res.drawable.wall_manhattan_smoke,
)

private val binkScenes = listOf(
    Res.drawable.bink_01,
    Res.drawable.bink_02,
    Res.drawable.bink_03,
    Res.drawable.bink_04,
    Res.drawable.bink_05,
    Res.drawable.bink_06,
    Res.drawable.bink_07,
    Res.drawable.bink_08,
    Res.drawable.bink_09,
    Res.drawable.bink_10,
)

private val introScenes = listOf(
    Res.drawable.intro_03,
    Res.drawable.intro_06,
    Res.drawable.intro_09,
    Res.drawable.intro_11,
    Res.drawable.intro_12,
    Res.drawable.intro_13,
)

@Composable
fun LauncherApp(host: LauncherHost) {
    val gameData by host.gameData.collectAsState()
    val mods by host.mods.collectAsState()
    val logLines by host.logLines.collectAsState()
    var settings by remember(host) { mutableStateOf(host.loadSettings()) }
    var page by remember(host) {
        mutableStateOf(if (gameData.hasFileAccess) LauncherPage.Home else LauncherPage.Setup)
    }

    LaunchedEffect(settings) { host.saveSettings(settings) }

    ProtoTheme {
        BoxWithConstraints(Modifier.fillMaxSize().background(Ink)) {
            val compact = maxWidth < 680.dp || maxHeight < 370.dp
            AnimatedContent(
                targetState = page,
                transitionSpec = {
                    (fadeIn(tween(300)) + scaleIn(initialScale = 0.995f, animationSpec = tween(300))) togetherWith
                        fadeOut(tween(180)) using SizeTransform(clip = false)
                },
                label = "launcher page",
            ) { animatedPage ->
            when (animatedPage) {
                LauncherPage.Home -> HomeScreen(
                    compact = compact,
                    settings = settings,
                    gameData = gameData,
                    onPage = { page = it },
                    onPlay = {
                        if (gameData.gameDataReady) host.launchGame(settings) else page = LauncherPage.Setup
                    },
                    onExit = host::exitLauncher,
                )
                LauncherPage.Setup -> SetupScreen(
                    host = host,
                    data = gameData,
                    onBack = { page = LauncherPage.Home },
                    onContinue = { page = LauncherPage.Home },
                )
                LauncherPage.Settings -> SettingsScreen(
                    settings = settings,
                    onSettings = { settings = it },
                    onBack = { page = LauncherPage.Home },
                    onPage = { page = it },
                    host = host,
                )
                LauncherPage.Drivers -> DriversScreen(
                    settings = settings,
                    onSettings = { settings = it },
                    onBack = { page = LauncherPage.Home },
                )
                LauncherPage.Mods -> ModsScreen(
                    mods = mods,
                    host = host,
                    onBack = { page = LauncherPage.Home },
                )
                LauncherPage.Layout -> LayoutScreen(
                    settings = settings,
                    onSettings = { settings = it },
                    onBack = { page = LauncherPage.Home },
                )
                LauncherPage.Logs -> LogsScreen(
                    lines = logLines,
                    host = host,
                    onBack = { page = LauncherPage.Home },
                )
                LauncherPage.About -> AboutScreen(onBack = { page = LauncherPage.Home })
            }
            }
        }
    }
}

@Composable
private fun CinematicBackdrop(
    scenes: List<DrawableResource>,
    modifier: Modifier = Modifier,
    darken: Float = 0.38f,
) {
    var layers by remember(scenes) { mutableStateOf(listOf(0)) }
    LaunchedEffect(scenes) {
        if (scenes.size > 1) {
            while (true) {
                delay(10_000)
                layers = listOf(layers.last(), (layers.last() + 1) % scenes.size)
            }
        }
    }

    Box(modifier.fillMaxSize()) {
        // Outgoing scene stays mounted at full opacity with its finished zoom;
        // the incoming scene fades over it. Pool aspects are uniform, so the
        // cover-crop scale is identical on both layers and the cut cannot jump.
        layers.forEach { index ->
            key(index) { SceneImage(scenes[index], entering = scenes.size > 1) }
        }
        if (scenes.size > 1) {
            // Decode the next scene invisibly before its turn.
            Image(
                painter = painterResource(scenes[(layers.last() + 1) % scenes.size]),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().graphicsLayer { alpha = 0f },
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(Ink.copy(alpha = 0.72f), Color.Transparent, Ink.copy(alpha = 0.15f)))
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Ink.copy(alpha = 0.48f), Color.Transparent, Ink.copy(alpha = 0.86f)))
            )
        )
        Box(Modifier.fillMaxSize().background(Ink.copy(alpha = darken.coerceIn(0f, 0.6f))))
    }
}

@Composable
private fun SceneImage(res: DrawableResource, entering: Boolean) {
    val fade = remember { Animatable(if (entering) 0f else 1f) }
    val zoom = remember { Animatable(1.06f) }
    LaunchedEffect(Unit) {
        if (entering) launch { fade.animateTo(1f, tween(1_600, easing = FastOutSlowInEasing)) }
        zoom.animateTo(1.13f, tween(11_600, easing = LinearEasing))
    }
    Image(
        painter = painterResource(res),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize().graphicsLayer {
            alpha = fade.value
            scaleX = zoom.value
            scaleY = zoom.value
            translationX = -(zoom.value - 1.06f) * size.width * 0.14f
            translationY = -(zoom.value - 1.06f) * size.height * 0.08f
        },
    )
}

@Composable
private fun HomeScreen(
    compact: Boolean,
    settings: LauncherSettings,
    gameData: GameDataStatus,
    onPage: (LauncherPage) -> Unit,
    onPlay: () -> Unit,
    onExit: () -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val showStatusPanel = maxWidth >= 650.dp
        val viewportHeight = maxHeight
        CinematicBackdrop(homeScenes, darken = 0.22f)
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 42.dp).padding(horizontal = 16.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Image(painterResource(Res.drawable.launcher_icon), null, Modifier.size(28.dp).clip(RoundedCornerShape(6.dp)))
                Text("ProtoDroid", fontFamily = OswaldFamily(), fontSize = 13.sp, letterSpacing = 2.sp, color = Bone)
                Spacer(Modifier.weight(1f))
                if (!gameData.hasFileAccess) StatusTag("ACCESS NEEDED", BloodBright)
                else if (gameData.gameDataReady) StatusTag("READY", Bone)
                else StatusTag("NO GAME DATA", BloodBright)
            }

            Row(
                Modifier.fillMaxWidth().weight(1f).padding(horizontal = if (compact) 18.dp else 30.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                Box(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                Column(
                    Modifier.fillMaxWidth().heightIn(min = viewportHeight).padding(vertical = 6.dp),
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        "[PROTOTYPE]",
                        fontFamily = DirtFamily(),
                        fontSize = if (compact) 31.sp else 42.sp,
                        lineHeight = if (compact) 38.sp else 50.sp,
                        color = Bone,
                        maxLines = 1,
                        softWrap = false,
                    )
                    Text(
                        "NATIVE ANDROID PORT",
                        Modifier.padding(start = 5.dp, bottom = if (compact) 10.dp else 16.dp),
                        fontFamily = OswaldFamily(),
                        fontSize = if (compact) 9.sp else 11.sp,
                        letterSpacing = 3.sp,
                        color = Ash,
                        maxLines = 1,
                    )

                    val menuHeight = if (compact) 31.dp else 39.dp
                    MainMenuItem("Play", emphasized = true, height = menuHeight, onClick = onPlay)
                    MainMenuItem("Settings", height = menuHeight) { onPage(LauncherPage.Settings) }
                    MainMenuItem("Drivers", height = menuHeight) { onPage(LauncherPage.Drivers) }
                    MainMenuItem("Mods", height = menuHeight) { onPage(LauncherPage.Mods) }
                    MainMenuItem("Layout", height = menuHeight) { onPage(LauncherPage.Layout) }
                    MainMenuItem("Logs", height = menuHeight) { onPage(LauncherPage.Logs) }
                    MainMenuItem("About", height = menuHeight) { onPage(LauncherPage.About) }
                }
                }

                if (showStatusPanel) {
                    GameStatusPanel(
                        gameData = gameData,
                        settings = settings,
                        onAccess = { onPage(LauncherPage.Setup) },
                        onSettings = { onPage(LauncherPage.Settings) },
                        modifier = Modifier.widthIn(min = 200.dp, max = 260.dp).fillMaxWidth(0.34f),
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().heightIn(min = 28.dp).background(Color.Black.copy(alpha = 0.48f)).padding(horizontal = 14.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    if (gameData.gameDataReady) "READY TO PLAY" else "ADD YOUR OWN GAME FILES",
                    Modifier.weight(1f),
                    fontFamily = MonoFamily(),
                    fontSize = 10.sp,
                    color = Bone.copy(alpha = 0.78f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                TextButton(onClick = onExit, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text("EXIT", fontFamily = OswaldFamily(), fontSize = 10.sp, letterSpacing = 1.6.sp, color = Ash)
                }
            }
        }
    }
}

@Composable
private fun GameStatusPanel(
    gameData: GameDataStatus,
    settings: LauncherSettings,
    onAccess: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        color = PanelInk.copy(alpha = 0.9f),
        shape = RoundedCornerShape(3.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(if (gameData.gameDataReady) Bone else BloodBright, RoundedCornerShape(50)))
                Text("GAME DATA", Modifier.padding(start = 7.dp), fontFamily = OswaldFamily(), fontSize = 11.sp, letterSpacing = 2.sp, color = Ash)
                Spacer(Modifier.weight(1f))
                Text(if (gameData.gameDataReady) "READY" else "MISSING", fontFamily = OswaldFamily(), fontSize = 11.sp, letterSpacing = 1.sp, color = if (gameData.gameDataReady) Bone else BloodBright)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(settings.driver, fontFamily = MonoFamily(), fontSize = 10.sp, color = Bone.copy(alpha = 0.86f), maxLines = 1)
                Text("·", color = Ash)
                Text(settings.resolution, fontFamily = MonoFamily(), fontSize = 10.sp, color = Bone.copy(alpha = 0.86f))
                Text("·", color = Ash)
                Text("${settings.fpsLimit} FPS", fontFamily = MonoFamily(), fontSize = 10.sp, color = Bone.copy(alpha = 0.86f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ActionButton(if (gameData.hasFileAccess) "CHECK" else "ALLOW ACCESS", Modifier.weight(1f), onAccess)
                OutlineButton("SETTINGS", onSettings)
            }
        }
    }
}

@Composable
private fun MainMenuItem(label: String, emphasized: Boolean = false, height: Dp, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(2.dp)).clickable(onClick = onClick).padding(horizontal = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("›", fontFamily = OswaldFamily(), fontSize = if (emphasized) 24.sp else 19.sp, color = BloodBright, modifier = Modifier.width(22.dp))
        Text(
            label.uppercase(),
            fontFamily = OswaldFamily(),
            fontWeight = if (emphasized) FontWeight.Bold else FontWeight.Medium,
            fontSize = if (emphasized) 24.sp else 18.sp,
            letterSpacing = 2.sp,
            color = Bone.copy(alpha = if (emphasized) 1f else 0.88f),
            maxLines = 1,
            softWrap = false,
        )
    }
}

@Composable
private fun SetupScreen(host: LauncherHost, data: GameDataStatus, onBack: () -> Unit, onContinue: () -> Unit) {
    PageFrame("FILE ACCESS", listOf(Res.drawable.wall_sunset_helicopters, Res.drawable.wall_quarantine_city), onBack) {
        Box(Modifier.fillMaxSize().padding(18.dp), contentAlignment = Alignment.Center) {
            Surface(
                Modifier.fillMaxWidth().widthIn(max = 640.dp),
                color = PanelInk.copy(alpha = 0.92f),
                shape = RoundedCornerShape(3.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatusTag(
                        when {
                            data.gameDataReady -> "GAME DATA READY"
                            data.hasFileAccess -> "ACCESS ALLOWED"
                            else -> "PERMISSION NEEDED"
                        },
                        if (data.gameDataReady) Bone else BloodBright,
                    )
                    Text(
                        if (data.hasFileAccess) "APP FILE ACCESS" else "ALLOW FILE ACCESS",
                        fontFamily = DirtFamily(),
                        fontSize = 27.sp,
                        lineHeight = 32.sp,
                        color = Bone,
                    )
                    Text(
                        "Android checks the game's configured app location. No folder picker, file browser or duplicate copy is used here.",
                        fontFamily = OswaldFamily(),
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        color = Bone.copy(alpha = 0.78f),
                    )
                    if (data.details.isNotBlank()) {
                        Text(data.details, fontFamily = MonoFamily(), fontSize = 11.sp, color = Ash)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!data.hasFileAccess) {
                            ActionButton("ALLOW FILE ACCESS", onClick = host::requestFileAccess)
                        } else {
                            ActionButton("CONTINUE", onClick = onContinue)
                            if (!data.gameDataReady) OutlineButton("CHECK AGAIN", onClick = host::checkGameData)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    settings: LauncherSettings,
    onSettings: (LauncherSettings) -> Unit,
    onBack: () -> Unit,
    onPage: (LauncherPage) -> Unit,
    host: LauncherHost,
) {
    var section by remember { mutableStateOf(SettingsSection.Graphics) }
    PageFrame("SETTINGS", listOf(Res.drawable.wall_ashen_profile, Res.drawable.wall_manhattan_smoke), onBack) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val compact = maxWidth < 660.dp
            if (compact) {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 5.dp)) {
                        SettingsSection.entries.forEach { item -> SectionButton(item, section == item) { section = item } }
                    }
                    SettingsRows(section, settings, onSettings, onPage, host, Modifier.weight(1f).fillMaxWidth())
                }
            } else {
                Row(Modifier.fillMaxSize()) {
                    Column(Modifier.width(164.dp).fillMaxHeight().background(Color.Black.copy(alpha = 0.42f)).verticalScroll(rememberScrollState()).padding(vertical = 6.dp)) {
                        SettingsSection.entries.forEach { item -> SectionButton(item, section == item) { section = item } }
                    }
                    SettingsRows(section, settings, onSettings, onPage, host, Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun SectionButton(section: SettingsSection, selected: Boolean, onClick: () -> Unit) {
    Text(
        section.title.uppercase(),
        Modifier.padding(horizontal = 5.dp, vertical = 3.dp).clip(RoundedCornerShape(2.dp))
            .background(if (selected) Blood.copy(alpha = 0.72f) else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 11.dp, vertical = 9.dp),
        fontFamily = OswaldFamily(),
        fontSize = 12.sp,
        letterSpacing = 1.3.sp,
        color = if (selected) Bone else Ash,
        maxLines = 1,
        softWrap = false,
    )
}

@Composable
private fun SettingsRows(
    section: SettingsSection,
    s: LauncherSettings,
    update: (LauncherSettings) -> Unit,
    onPage: (LauncherPage) -> Unit,
    host: LauncherHost,
    modifier: Modifier = Modifier,
) {
    Column(modifier.verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(start = 3.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(section.title.uppercase(), Modifier.weight(1f), fontFamily = MonoFamily(), fontSize = 11.sp, letterSpacing = 1.2.sp, color = Ash)
            TextButton(onClick = { update(LauncherSettings()) }, contentPadding = PaddingValues(horizontal = 9.dp, vertical = 2.dp)) {
                Text("RESET", fontFamily = OswaldFamily(), fontSize = 10.sp, letterSpacing = 1.2.sp, color = Ash)
            }
        }
        when (section) {
            SettingsSection.Graphics -> {
                ChoicePref("Preset", s.preset, listOf("Low", "Medium", "High", "Custom")) { value ->
                    val base = when (value) {
                        "Low" -> s.copy(resolution = "540p", textures = "Half", anisotropy = "1x", antiAlias = "Off", shadowDetail = "Low", graphicQuality = "Low")
                        "High" -> s.copy(resolution = "1080p", textures = "Full", anisotropy = "16x", antiAlias = "4x MSAA", shadowDetail = "High", graphicQuality = "High")
                        else -> s.copy(resolution = "720p", textures = "Full", anisotropy = "4x", antiAlias = "Game default", shadowDetail = "Game default", graphicQuality = "Game default")
                    }
                    update(base.copy(preset = value))
                }
                ChoicePref("Resolution", s.resolution, listOf("480p", "540p", "720p", "900p", "1080p", "Native")) { update(s.copy(resolution = it, preset = "Custom")) }
                ChoicePref("Textures", s.textures, listOf("Full", "Half", "Quarter")) { update(s.copy(textures = it, preset = "Custom")) }
                ChoicePref("Anisotropy", s.anisotropy, listOf("Off", "2x", "4x", "8x", "16x")) { update(s.copy(anisotropy = it, preset = "Custom")) }
                ChoicePref("FPS limit", s.fpsLimit, listOf("30", "40", "45", "60", "90", "120", "144", "Unlimited")) { update(s.copy(fpsLimit = it)) }
                TogglePref("Battery saver", s.batterySaver) { update(s.copy(batterySaver = it)) }
                TogglePref("Unlock menu FPS", s.unlockMenuFps) { update(s.copy(unlockMenuFps = it)) }
                ChoicePref("GPU driver", s.driver, listOf("Auto", "System", "Turnip", "Custom")) { update(s.copy(driver = it)) }
                ActionPref("Driver packages", "OPEN", onClick = { onPage(LauncherPage.Drivers) })
            }
            SettingsSection.Video -> {
                ChoicePref("Anti-alias level", s.antiAlias, listOf("Game default", "Off", "2x MSAA", "4x MSAA")) { update(s.copy(antiAlias = it, preset = "Custom")) }
                ChoicePref("Shadow detail", s.shadowDetail, listOf("Game default", "Off", "Low", "Medium", "High")) { update(s.copy(shadowDetail = it, preset = "Custom")) }
                ChoicePref("Graphic quality", s.graphicQuality, listOf("Game default", "Low", "Medium", "High")) { update(s.copy(graphicQuality = it, preset = "Custom")) }
            }
            SettingsSection.Controls -> {
                SliderPref("Button size", s.buttonSize, 0.5f..2f, "${(s.buttonSize * 100).roundToInt()}%") { update(s.copy(buttonSize = it)) }
                TogglePref("Vibration", s.vibration) { update(s.copy(vibration = it)) }
                if (s.vibration) SliderPref("Vibration strength", s.vibrationStrength, 0.1f..1f, "${(s.vibrationStrength * 100).roundToInt()}%") { update(s.copy(vibrationStrength = it)) }
                TogglePref("Left-handed layout", s.leftHanded) { update(s.copy(leftHanded = it)) }
                TogglePref("Stick edge sprint", s.stickEdgeSprint) { update(s.copy(stickEdgeSprint = it)) }
                SliderPref("Camera speed", s.cameraSpeed, 0.01f..1f, "${(s.cameraSpeed * 100).roundToInt()}%") { update(s.copy(cameraSpeed = it)) }
                TogglePref("Invert Y", s.invertY) { update(s.copy(invertY = it)) }
                TogglePref("Extra buttons", s.extraButtons) { update(s.copy(extraButtons = it)) }
                ActionPref("Touch layout", "EDIT", onClick = { onPage(LauncherPage.Layout) })
            }
            SettingsSection.Display -> {
                SliderPref("Touch opacity", s.opacity, 0.1f..1f, "${(s.opacity * 100).roundToInt()}%") { update(s.copy(opacity = it)) }
                TogglePref("Show FPS", s.showFps) { update(s.copy(showFps = it)) }
                TogglePref("Launcher sounds", s.launcherSounds) { update(s.copy(launcherSounds = it)) }
                if (s.launcherSounds) SliderPref("Sound volume", s.soundVolume, 0f..1f, "${(s.soundVolume * 100).roundToInt()}%") { update(s.copy(soundVolume = it)) }
                TogglePref("Launcher haptics", s.launcherHaptics) { update(s.copy(launcherHaptics = it)) }
                ChoicePref("Motion", s.motion, listOf("Full", "Reduced", "Off")) { update(s.copy(motion = it)) }
                TogglePref("Skip intro", s.skipIntro) { update(s.copy(skipIntro = it)) }
            }
            SettingsSection.Audio -> {
                ChoicePref("Audio driver", s.audioDriver, listOf("AAudio", "OpenSL ES")) { update(s.copy(audioDriver = it)) }
                TogglePref("Master reuse", s.masterReuse) { update(s.copy(masterReuse = it)) }
            }
            SettingsSection.Engine -> {
                SliderPref("FOV offset", (s.fovOffset + 10f) / 40f, 0f..1f, "${s.fovOffset.roundToInt()}°") { update(s.copy(fovOffset = it * 40f - 10f)) }
                ChoicePref("Shadow-map limit", s.shadowMapLimit, listOf("Default", "512", "1024", "2048", "4096", "8192")) { update(s.copy(shadowMapLimit = it)) }
                ChoicePref("Tick / QTE", s.tickPolicy, listOf("Default", "Fixed 30Hz", "Frame-scaled")) { update(s.copy(tickPolicy = it)) }
                TogglePref("Loose files", s.looseFiles) { update(s.copy(looseFiles = it)) }
                TogglePref("Developer menu", s.developerMenu) { update(s.copy(developerMenu = it)) }
                ChoicePref("VRAM report", s.vramReport, listOf("Device", "1 GB", "2 GB", "4 GB", "8 GB")) { update(s.copy(vramReport = it)) }
                TogglePref("Dump original textures", s.dumpTextures) { update(s.copy(dumpTextures = it)) }
            }
            SettingsSection.Diagnostics -> {
                TogglePref("Detailed diagnostics", s.detailedDiagnostics) { update(s.copy(detailedDiagnostics = it)) }
                if (s.detailedDiagnostics) SliderPref("Report interval", (s.diagnosticInterval - 1f) / 59f, 0f..1f, "${s.diagnosticInterval.roundToInt()}s") { update(s.copy(diagnosticInterval = 1f + it * 59f)) }
                ChoicePref("Pipeline timing", s.pipelineTiming, listOf("Follow", "On", "Off")) { update(s.copy(pipelineTiming = it)) }
                TogglePref("Present stats", s.presentStats) { update(s.copy(presentStats = it)) }
                ChoicePref("Audio stats", s.audioStats, listOf("Off", "Underruns", "Every window")) { update(s.copy(audioStats = it)) }
                TogglePref("Watchdog", s.watchdog) { update(s.copy(watchdog = it)) }
                TogglePref("Import profile", s.importProfile) { update(s.copy(importProfile = it)) }
                ActionPref("Export protodroid.ini", "SAVE", onClick = { host.writeIni(s) })
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun SettingRow(label: String, control: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 49.dp).padding(horizontal = 3.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            label,
            Modifier.weight(1f),
            fontFamily = OswaldFamily(),
            fontSize = 14.sp,
            lineHeight = 17.sp,
            letterSpacing = 0.5.sp,
            color = Bone.copy(alpha = 0.92f),
            softWrap = true,
        )
        Box(Modifier.widthIn(min = 132.dp, max = 216.dp)) { control() }
    }
}

@Composable
private fun ChoicePref(label: String, value: String, options: List<String>, onChange: (String) -> Unit) {
    SettingRow(label) {
        val current = options.indexOf(value).coerceAtLeast(0)
        Row(
            Modifier.fillMaxWidth().heightIn(min = 38.dp).border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(2.dp)).background(Color.Black.copy(alpha = 0.52f)),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("‹", Modifier.clickable { onChange(options[(current - 1 + options.size) % options.size]) }.padding(horizontal = 10.dp, vertical = 5.dp), fontFamily = OswaldFamily(), fontSize = 22.sp, color = BloodBright)
            Text(value, Modifier.weight(1f).padding(horizontal = 1.dp), fontFamily = OswaldFamily(), fontSize = 12.sp, lineHeight = 14.sp, letterSpacing = 0.6.sp, color = Bone, textAlign = TextAlign.Center, softWrap = true, maxLines = 2)
            Text("›", Modifier.clickable { onChange(options[(current + 1) % options.size]) }.padding(horizontal = 10.dp, vertical = 5.dp), fontFamily = OswaldFamily(), fontSize = 22.sp, color = BloodBright)
        }
    }
}

@Composable
private fun TogglePref(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    SettingRow(label) {
        Row(Modifier.fillMaxWidth().height(35.dp).border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(2.dp)).background(Color.Black.copy(alpha = 0.5f))) {
            listOf(false to "OFF", true to "ON").forEach { (on, text) ->
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .background(if (value == on) Blood else Color.Transparent)
                        .clickable { onChange(on) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(text, fontFamily = OswaldFamily(), fontSize = 11.sp, letterSpacing = 1.4.sp, color = if (value == on) Bone else Ash)
                }
            }
        }
    }
}

@Composable
private fun SliderPref(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueLabel: String, onChange: (Float) -> Unit) {
    SettingRow(label) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f).height(34.dp))
            Text(valueLabel, Modifier.widthIn(min = 36.dp), fontFamily = MonoFamily(), fontSize = 10.sp, color = Bone, textAlign = TextAlign.End, maxLines = 1)
        }
    }
}

@Composable
private fun ActionPref(label: String, button: String, onClick: () -> Unit) {
    SettingRow(label) { OutlineButton(button, onClick) }
}

@Composable
private fun DriversScreen(settings: LauncherSettings, onSettings: (LauncherSettings) -> Unit, onBack: () -> Unit) {
    PageFrame("DRIVERS", listOf(Res.drawable.wall_blacklight_portrait, Res.drawable.wall_quarantine_city), onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("CURRENT · ${settings.driver.uppercase()}", fontFamily = MonoFamily(), fontSize = 11.sp, letterSpacing = 1.sp, color = Ash)
            listOf(
                "Auto" to "Choose the compatible driver for this GPU.",
                "System" to "Use the Android device Vulkan driver.",
                "Turnip" to "Adreno devices only.",
                "Custom" to "Use a native package registered by ProtoDroid.",
            ).forEach { (mode, description) ->
                ModeRow(mode, description, settings.driver == mode) { onSettings(settings.copy(driver = mode)) }
            }
            Text("Driver packages and device validation remain owned by the native ProtoDroid host.", Modifier.padding(top = 4.dp), fontFamily = MonoFamily(), fontSize = 10.sp, color = Ash, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun ModeRow(title: String, description: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(3.dp)).border(1.dp, if (selected) BloodBright else Color.White.copy(alpha = 0.12f), RoundedCornerShape(3.dp))
            .background(if (selected) Blood.copy(alpha = 0.18f) else PanelInk.copy(alpha = 0.78f))
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title.uppercase(), fontFamily = OswaldFamily(), fontSize = 16.sp, letterSpacing = 1.2.sp, color = Bone)
            Text(description, fontFamily = OswaldFamily(), fontSize = 12.sp, lineHeight = 15.sp, color = Ash)
        }
        Text(if (selected) "●" else "○", fontFamily = MonoFamily(), fontSize = 16.sp, color = if (selected) BloodBright else Ash)
    }
}

@Composable
private fun ModsScreen(mods: List<LauncherMod>, host: LauncherHost, onBack: () -> Unit) {
    PageFrame("MODS", binkScenes, onBack) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${mods.count { it.enabled }} ACTIVE", Modifier.weight(1f), fontFamily = MonoFamily(), fontSize = 11.sp, color = Ash)
                OutlineButton("RECHECK", host::refreshMods)
            }
            if (mods.isEmpty()) {
                Surface(Modifier.fillMaxWidth(), color = PanelInk.copy(alpha = 0.86f), shape = RoundedCornerShape(3.dp), border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))) {
                    Text("No local mods registered", Modifier.padding(16.dp), fontFamily = OswaldFamily(), fontSize = 14.sp, color = Bone)
                }
            }
            mods.forEach { mod ->
                Row(Modifier.fillMaxWidth().background(PanelInk.copy(alpha = 0.88f)).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(mod.name, fontFamily = OswaldFamily(), fontSize = 14.sp, color = Bone)
                        Text("${mod.kind} · ${mod.detail}", fontFamily = MonoFamily(), fontSize = 10.sp, color = Ash, lineHeight = 13.sp)
                    }
                    TogglePref("Enabled", mod.enabled) { host.setModEnabled(mod.id, it) }
                }
            }
        }
    }
}

@Composable
private fun LayoutScreen(settings: LauncherSettings, onSettings: (LauncherSettings) -> Unit, onBack: () -> Unit) {
    var positions by remember(settings.touchLayout) { mutableStateOf(settings.touchLayout) }
    PageFrame("TOUCH LAYOUT", listOf(Res.drawable.wall_mercer_city, Res.drawable.wall_blacklight_portrait), onBack) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                OutlineButton("RESET") {
                    positions = defaultTouchLayout()
                    onSettings(settings.copy(touchLayout = positions))
                }
                Spacer(Modifier.width(7.dp))
                ActionButton(if (settings.leftHanded) "MIRRORED" else "MIRROR", onClick = { onSettings(settings.copy(leftHanded = !settings.leftHanded)) })
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp).clip(RoundedCornerShape(4.dp)).background(Color.Black.copy(alpha = 0.28f))) {
                val density = LocalDensity.current
                positions.forEach { (label, p) ->
                    val x = maxWidth * p.x - 26.dp
                    val y = maxHeight * p.y - 26.dp
                    Box(
                        Modifier.offset(x = if (settings.leftHanded) maxWidth - x - 52.dp else x, y = y)
                            .size(52.dp).clip(RoundedCornerShape(50)).border(1.dp, BloodBright.copy(alpha = 0.8f), RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = settings.opacity * 0.78f))
                            .pointerInput(label, maxWidth, maxHeight) {
                                detectDragGestures { change, drag ->
                                    change.consume()
                                    val dx = with(density) { drag.x.toDp().value } / maxWidth.value
                                    val dy = with(density) { drag.y.toDp().value } / maxHeight.value
                                    val updated = p.copy(x = (p.x + dx).coerceIn(0.04f, 0.96f), y = (p.y + dy).coerceIn(0.08f, 0.92f))
                                    positions = positions + (label to updated)
                                    onSettings(settings.copy(touchLayout = positions))
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(label, fontFamily = OswaldFamily(), fontSize = 9.sp, letterSpacing = 0.5.sp, color = Bone, maxLines = 1)
                    }
                }
            }
            Text("DRAG TO MOVE · SETTINGS APPLY IN GAME", Modifier.align(Alignment.CenterHorizontally).padding(bottom = 6.dp), fontFamily = MonoFamily(), fontSize = 9.sp, letterSpacing = 0.8.sp, color = Ash)
        }
    }
}

@Composable
private fun LogsScreen(lines: List<String>, host: LauncherHost, onBack: () -> Unit) {
    PageFrame("LOGS", listOf(Res.drawable.wall_manhattan_smoke), onBack) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("NATIVE SESSION", Modifier.weight(1f), fontFamily = MonoFamily(), fontSize = 11.sp, color = Ash)
                OutlineButton("CLEAR") { host.clearLogs() }
            }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 8.dp)) {
                if (lines.isEmpty()) Text("No log lines", fontFamily = MonoFamily(), fontSize = 11.sp, color = Ash)
                lines.forEach { line ->
                    Text(line, Modifier.fillMaxWidth().padding(vertical = 2.dp), fontFamily = MonoFamily(), fontSize = 10.sp, lineHeight = 14.sp, color = Bone.copy(alpha = 0.82f), softWrap = true)
                }
            }
        }
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    PageFrame("ABOUT", listOf(Res.drawable.wall_ashen_profile, Res.drawable.wall_mercer_urban), onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Image(painterResource(Res.drawable.launcher_icon), null, Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)))
                Column {
                    Text("PROTODROID", fontFamily = OswaldFamily(), fontSize = 20.sp, letterSpacing = 1.5.sp, color = Bone)
                    Text("NATIVE ANDROID PORT", fontFamily = MonoFamily(), fontSize = 10.sp, letterSpacing = 1.5.sp, color = Ash)
                }
            }
            Text("The shared Compose launcher handles device settings and hands game launch to the native ProtoDroid engine host.", fontFamily = OswaldFamily(), fontSize = 14.sp, lineHeight = 19.sp, color = Bone.copy(alpha = 0.84f))
            Text("Bring your own game data. No game files or DRM bypass are included.", fontFamily = MonoFamily(), fontSize = 10.sp, lineHeight = 14.sp, color = Ash)
        }
    }
}

@Composable
private fun PageFrame(title: String, scenes: List<DrawableResource>, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        CinematicBackdrop(scenes, darken = 0.34f)
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 46.dp).background(Color.Black.copy(alpha = 0.48f)).padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("‹ BACK", Modifier.clip(RoundedCornerShape(2.dp)).clickable(onClick = onBack).padding(horizontal = 8.dp, vertical = 7.dp), fontFamily = OswaldFamily(), fontSize = 12.sp, letterSpacing = 1.2.sp, color = Ash, maxLines = 1)
                Box(Modifier.width(1.dp).height(22.dp).background(Color.White.copy(alpha = 0.18f)))
                Text(title, Modifier.weight(1f), fontFamily = DirtFamily(), fontSize = 22.sp, color = Bone, maxLines = 1, softWrap = false)
            }
            Column(Modifier.weight(1f).fillMaxWidth(), content = content)
            Row(Modifier.fillMaxWidth().heightIn(min = 25.dp).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("TAP TO SELECT", fontFamily = MonoFamily(), fontSize = 9.sp, letterSpacing = 1.sp, color = Ash)
                Spacer(Modifier.weight(1f))
                Text("BACK", fontFamily = OswaldFamily(), fontSize = 9.sp, letterSpacing = 1.sp, color = Bone.copy(alpha = 0.7f))
            }
        }
    }
}

@Composable
private fun StatusTag(text: String, color: Color) {
    Text(text, Modifier.border(1.dp, color.copy(alpha = 0.48f), RoundedCornerShape(2.dp)).padding(horizontal = 7.dp, vertical = 4.dp), fontFamily = MonoFamily(), fontSize = 9.sp, letterSpacing = 0.8.sp, color = color, maxLines = 1)
}

@Composable
private fun ActionButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 36.dp),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 7.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Blood, contentColor = Bone),
    ) {
        Text(text, fontFamily = OswaldFamily(), fontSize = 11.sp, letterSpacing = 1.1.sp, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun OutlineButton(text: String, onClick: () -> Unit) {
    Text(
        text,
        Modifier.clip(RoundedCornerShape(2.dp)).border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(2.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp),
        fontFamily = OswaldFamily(),
        fontSize = 10.sp,
        letterSpacing = 1.sp,
        color = Bone,
        maxLines = 1,
        softWrap = false,
    )
}