package com.protodroid.launcher

import kotlinx.coroutines.flow.StateFlow

enum class LauncherPage(val title: String) {
    Home("Home"),
    Setup("File access"),
    Settings("Settings"),
    Drivers("Drivers"),
    Mods("Mods"),
    Layout("Layout"),
    Logs("Logs"),
    About("About"),
}

enum class SettingsSection(val title: String) {
    Graphics("Graphics"),
    Video("Game video"),
    Controls("Controls"),
    Display("Display"),
    Audio("Audio"),
    Engine("Engine fixes"),
    Diagnostics("Diagnostics"),
}

data class ControlPosition(val x: Float, val y: Float, val scale: Float = 1f)

data class LauncherMod(
    val id: String,
    val name: String,
    val kind: String,
    val enabled: Boolean,
    val detail: String = "",
)

data class LauncherSettings(
    val preset: String = "Medium",
    val resolution: String = "720p",
    val textures: String = "Full",
    val anisotropy: String = "4x",
    val fpsLimit: String = "60",
    val batterySaver: Boolean = false,
    val unlockMenuFps: Boolean = true,
    val driver: String = "Auto",
    val antiAlias: String = "Game default",
    val shadowDetail: String = "Game default",
    val graphicQuality: String = "Game default",
    val buttonSize: Float = 1f,
    val vibration: Boolean = true,
    val vibrationStrength: Float = 0.6f,
    val leftHanded: Boolean = false,
    val stickEdgeSprint: Boolean = true,
    val cameraSpeed: Float = 0.5f,
    val invertY: Boolean = false,
    val extraButtons: Boolean = false,
    val opacity: Float = 0.7f,
    val showFps: Boolean = false,
    val launcherSounds: Boolean = false,
    val soundVolume: Float = 0.45f,
    val launcherHaptics: Boolean = true,
    val motion: String = "Full",
    val skipIntro: Boolean = false,
    val audioDriver: String = "AAudio",
    val masterReuse: Boolean = true,
    val fovOffset: Float = 0f,
    val shadowMapLimit: String = "Default",
    val tickPolicy: String = "Default",
    val looseFiles: Boolean = false,
    val developerMenu: Boolean = false,
    val vramReport: String = "Device",
    val dumpTextures: Boolean = false,
    val detailedDiagnostics: Boolean = false,
    val diagnosticInterval: Float = 5f,
    val pipelineTiming: String = "Follow",
    val presentStats: Boolean = false,
    val audioStats: String = "Off",
    val watchdog: Boolean = false,
    val importProfile: Boolean = false,
    val touchLayout: Map<String, ControlPosition> = defaultTouchLayout(),
)

data class GameDataStatus(
    val hasFileAccess: Boolean = false,
    val gameDataReady: Boolean = false,
    val locationLabel: String = "App-managed game location",
    val details: String = "",
)

/** Native ProtoDroid owns Android permissions, saves, game launch and persistent preferences. */
interface LauncherHost {
    val gameData: StateFlow<GameDataStatus>
    val mods: StateFlow<List<LauncherMod>>
    val logLines: StateFlow<List<String>>

    fun loadSettings(): LauncherSettings
    fun saveSettings(settings: LauncherSettings)
    fun requestFileAccess()
    fun checkGameData()
    fun launchGame(settings: LauncherSettings)
    fun writeIni(settings: LauncherSettings)
    fun setModEnabled(id: String, enabled: Boolean)
    fun refreshMods()
    fun clearLogs()
    fun exitLauncher()
}

fun defaultTouchLayout() = mapOf(
    "MOVE" to ControlPosition(0.14f, 0.7f, 1.0f),
    "JUMP" to ControlPosition(0.91f, 0.77f, 1.0f),
    "ATTACK" to ControlPosition(0.81f, 0.86f, 1.0f),
    "POWER" to ControlPosition(0.81f, 0.66f, 1.0f),
    "GRAB" to ControlPosition(0.91f, 0.56f, 1.0f),
    "SPRINT" to ControlPosition(0.7f, 0.86f, 0.9f),
    "LOCK" to ControlPosition(0.08f, 0.31f, 0.85f),
)

fun LauncherSettings.toIni(): String = buildString {
    appendLine("; ProtoDroid local launcher settings")
    appendLine("render_height = ${resolution.removeSuffix("p").ifBlank { "native" }}")
    appendLine("texture_skip_mips = ${when (textures) { "Half" -> 1; "Quarter" -> 2; else -> 0 }}")
    appendLine("max_anisotropy = ${anisotropy.removeSuffix("x").ifBlank { "1" }}")
    appendLine("fps_limit = ${fpsLimit.ifBlank { "0" }}")
    appendLine("battery_saver = ${if (batterySaver) 1 else 0}")
    appendLine("unlock_menu_fps = ${if (unlockMenuFps) 1 else 0}")
    appendLine("vulkan_driver = ${driver.lowercase()}")
    appendLine("audio_driver = ${audioDriver.lowercase().replace(" ", "")}")
    appendLine("fov_offset = $fovOffset")
    appendLine("detailed_diagnostics = ${if (detailedDiagnostics) 1 else 0}")
    appendLine("detailed_diagnostics_interval = ${diagnosticInterval.toInt().coerceIn(1, 60)}")
}