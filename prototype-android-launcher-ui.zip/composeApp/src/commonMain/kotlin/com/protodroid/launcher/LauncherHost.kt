package com.protodroid.launcher

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Offline fallback for the Wasm preview and the standalone sample Android activity. */
class PreviewLauncherHost : LauncherHost {
    private val gameDataState = MutableStateFlow(GameDataStatus())
    private val modsState = MutableStateFlow<List<LauncherMod>>(emptyList())
    private val logsState = MutableStateFlow(listOf("Launcher preview · native game host not connected"))
    private var settings = LauncherSettings()

    override val gameData: StateFlow<GameDataStatus> = gameDataState
    override val mods: StateFlow<List<LauncherMod>> = modsState
    override val logLines: StateFlow<List<String>> = logsState

    override fun loadSettings() = settings
    override fun saveSettings(settings: LauncherSettings) {
        this.settings = settings
    }

    override fun requestFileAccess() {
        gameDataState.value = gameDataState.value.copy(
            hasFileAccess = true,
            details = "Preview only · no game files are read here",
        )
        logsState.value = logsState.value + "File access requested by preview host"
    }

    override fun checkGameData() {
        logsState.value = logsState.value + "Game data check belongs to the native host"
    }

    override fun launchGame(settings: LauncherSettings) {
        logsState.value = logsState.value + "Play requested · native engine host not connected"
    }

    override fun writeIni(settings: LauncherSettings) {
        logsState.value = logsState.value + "INI export requested · native host not connected"
    }

    override fun setModEnabled(id: String, enabled: Boolean) {
        modsState.value = modsState.value.map { if (it.id == id) it.copy(enabled = enabled) else it }
    }

    override fun refreshMods() {
        logsState.value = logsState.value + "Mod scan belongs to the native host"
    }

    override fun clearLogs() {
        logsState.value = emptyList()
    }

    override fun exitLauncher() = Unit
}