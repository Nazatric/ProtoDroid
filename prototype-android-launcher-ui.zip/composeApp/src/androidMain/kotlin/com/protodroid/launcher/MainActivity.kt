package com.protodroid.launcher

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

/**
 * Standalone shell for the Compose module. The real ProtoDroid Application should implement
 * ProtoDroidLauncherOwner and return its existing native file/settings/game adapter.
 */
interface ProtoDroidLauncherOwner {
    val protoDroidLauncherHost: LauncherHost
}

class MainActivity : ComponentActivity() {
    private val previewHost = PreviewLauncherHost()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val host = (application as? ProtoDroidLauncherOwner)?.protoDroidLauncherHost ?: previewHost
        setContent { LauncherApp(host) }
    }
}