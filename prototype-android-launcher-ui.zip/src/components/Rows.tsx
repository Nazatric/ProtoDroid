import { useRef, type KeyboardEvent, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { sfx } from "../lib/sfx";
import type { Val } from "../lib/settings";

type RowBase = { label: string; hint: string; restart?: boolean; onHint: (h: string) => void; delay?: number; highlight?: boolean };

function RowShell({ label, hint, restart, onHint, onKey, children, onClick, delay = 0, highlight }: RowBase & { onKey?: (e: KeyboardEvent) => void; children: ReactNode; onClick?: () => void }) {
  return (
    <div
      data-nav
      data-lr
      tabIndex={0}
      onFocus={() => onHint(hint)}
      onMouseEnter={() => onHint(hint)}
      onKeyDown={onKey}
      onClick={onClick}
      style={{ animationDelay: `${delay}ms` }}
      className="nav-row anim-rise flex min-h-[clamp(46px,11vh,58px)] items-center gap-2 border-b border-white/[0.06] py-1 pl-3 pr-2"
    >
      <span className="safe-wrap min-w-0 flex-1 font-ui text-[clamp(12px,3.3vh,15px)] uppercase leading-[1.12] tracking-[0.1em] text-bone/90">
        {label}
        {restart && <span className="ml-1 text-blood-hi">*</span>}
      </span>
      <div className={cn("relative flex shrink-0 items-center justify-end", highlight && "bg-gradient-to-r from-transparent to-blood/15")}>{children}</div>
    </div>
  );
}

const Arrow = ({ dir, onClick }: { dir: "l" | "r"; onClick: () => void }) => (
  <button
    tabIndex={-1}
    aria-label={dir === "l" ? "Previous" : "Next"}
    onClick={(e) => {
      e.stopPropagation();
      onClick();
    }}
    className="grid h-9 w-9 place-items-center text-blood-hi transition-transform active:scale-75"
  >
    <svg width="10" height="12" viewBox="0 0 10 12">
      <path d={dir === "l" ? "M9 0 0 6l9 6z" : "M1 0l9 6-9 6z"} fill="currentColor" />
    </svg>
  </button>
);

export function ChoiceRow({ value, opts, onChange, ...b }: RowBase & { value: Val; opts: [Val, string][]; onChange: (v: Val) => void }) {
  const i = Math.max(0, opts.findIndex(([v]) => v === value));
  const step = (d: number) => {
    const n = (i + d + opts.length) % opts.length;
    sfx.tick();
    onChange(opts[n][0]);
  };
  return (
    <RowShell
      {...b}
      highlight
      onClick={() => step(1)}
      onKey={(e) => {
        if (e.key === "ArrowLeft") (e.preventDefault(), step(-1));
        if (e.key === "ArrowRight" || e.key === "Enter" || e.key === " ") (e.preventDefault(), step(1));
      }}
    >
      <div className="flex w-[clamp(132px,29vw,210px)] items-center justify-between">
        <Arrow dir="l" onClick={() => step(-1)} />
        <div className="flex min-w-0 flex-1 flex-col items-center">
          <span key={String(value)} className="anim-fade safe-wrap max-w-full text-center font-ui text-[clamp(11px,3.1vh,14px)] font-medium uppercase leading-tight tracking-[0.1em] text-white">
            {opts[i]?.[1]}
          </span>
          <span className="mt-0.5 flex gap-[3px]">
            {opts.map(([v]) => (
              <i key={String(v)} className={cn("h-[2px] w-2.5", v === value ? "bg-blood-hi" : "bg-white/15")} />
            ))}
          </span>
        </div>
        <Arrow dir="r" onClick={() => step(1)} />
      </div>
    </RowShell>
  );
}

export function ToggleRow({ value, onChange, ...b }: RowBase & { value: boolean; onChange: (v: boolean) => void }) {
  const set = (v: boolean) => {
    if (v === value) return;
    sfx.toggle(v);
    onChange(v);
  };
  return (
    <RowShell
      {...b}
      onClick={() => set(!value)}
      onKey={(e) => {
        if (e.key === "ArrowLeft") (e.preventDefault(), set(false));
        if (e.key === "ArrowRight") (e.preventDefault(), set(true));
        if (e.key === "Enter" || e.key === " ") (e.preventDefault(), set(!value));
      }}
    >
      <div className="relative flex h-8 w-[clamp(132px,29vw,210px)] items-stretch border border-white/12 bg-black/50 font-ui text-xs font-medium uppercase tracking-[0.16em]">
        <span
          className="absolute inset-y-0 w-1/2 bg-blood transition-transform duration-200 ease-out"
          style={{ transform: `translateX(${value ? "100%" : "0"})`, clipPath: "polygon(6% 0,100% 0,94% 100%,0 100%)" }}
        />
        <span className={cn("relative z-10 grid flex-1 place-items-center transition-colors", !value ? "text-white" : "text-ash")}>Off</span>
        <span className={cn("relative z-10 grid flex-1 place-items-center transition-colors", value ? "text-white" : "text-ash")}>On</span>
      </div>
    </RowShell>
  );
}

export function SliderRow({ value, min, max, step, fmt, onChange, ...b }: RowBase & { value: number; min: number; max: number; step: number; fmt?: (v: number) => string; onChange: (v: number) => void }) {
  const track = useRef<HTMLDivElement>(null);
  const SEG = 20;
  const pct = (value - min) / (max - min);
  const clamp = (v: number) => Math.min(max, Math.max(min, Math.round(v / step) * step));
  const setFromX = (x: number) => {
    const r = track.current!.getBoundingClientRect();
    const v = clamp(min + ((x - r.left) / r.width) * (max - min));
    if (v !== value) {
      sfx.tick();
      onChange(Number(v.toFixed(2)));
    }
  };
  const nudge = (d: number) => {
    const v = clamp(value + d * step);
    if (v !== value) (sfx.tick(), onChange(Number(v.toFixed(2))));
  };
  return (
    <RowShell
      {...b}
      onKey={(e) => {
        if (e.key === "ArrowLeft") (e.preventDefault(), nudge(-1));
        if (e.key === "ArrowRight") (e.preventDefault(), nudge(1));
      }}
    >
      <div className="flex w-[clamp(132px,29vw,210px)] items-center gap-1.5">
        <div
          ref={track}
          className="relative flex h-8 min-w-0 flex-1 cursor-pointer touch-none items-center gap-[2px]"
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => {
            e.stopPropagation();
            e.currentTarget.setPointerCapture?.(e.pointerId);
            setFromX(e.clientX);
          }}
          onPointerMove={(e) => e.buttons && setFromX(e.clientX)}
        >
          {Array.from({ length: SEG }, (_, i) => {
            const on = i < Math.round(pct * SEG);
            return (
              <i
                key={i}
                className={cn("h-3 flex-1 -skew-x-12 transition-colors duration-100", on ? "bg-blood-hi" : "bg-white/12")}
                style={on ? { opacity: 0.55 + (i / SEG) * 0.45 } : undefined}
              />
            );
          })}
        </div>
        <span className="w-10 shrink-0 text-right font-mono text-[11px] text-white">{fmt ? fmt(value) : value}</span>
      </div>
    </RowShell>
  );
}

export function ActionRow({ cta, onRun, danger, ...b }: RowBase & { cta: string; onRun: () => void; danger?: boolean }) {
  const run = () => {
    sfx.select();
    onRun();
  };
  return (
    <RowShell {...b} onClick={run} onKey={(e) => (e.key === "Enter" || e.key === " " || e.key === "ArrowRight") && (e.preventDefault(), run())}>
      <span
        className={cn(
          "flex h-8 w-[clamp(132px,29vw,210px)] items-center justify-center gap-1.5 border px-1 font-ui text-[11px] font-medium uppercase tracking-[0.14em]",
          danger ? "border-blood/60 text-blood-hi" : "border-white/15 text-white"
        )}
      >
        {cta}
        <svg width="8" height="10" viewBox="0 0 10 12">
          <path d="M1 0l9 6-9 6z" fill="currentColor" />
        </svg>
      </span>
    </RowShell>
  );
}

export function SectionHeader({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2 px-4 pb-1 pt-4 font-mono text-[10px] uppercase tracking-[0.3em] text-blood-hi">
      {label}
      <span className="h-px flex-1 bg-gradient-to-r from-blood/50 to-transparent" />
    </div>
  );
}
