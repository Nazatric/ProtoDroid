import { useRef, useState, type PointerEvent as RPE } from "react";
import { cn } from "../utils/cn";
import { CONTROLS, type Pos } from "../lib/data";
import { settingsStore } from "../lib/settings";

type Props = {
  layout: Record<string, Pos>;
  edit?: boolean;
  selected?: string | null;
  onSelect?: (id: string) => void;
  onMove?: (id: string, p: Pos) => void;
  onAction?: (id: string) => void;
  onStick?: (x: number, y: number, edge: boolean) => void;
  mirror?: boolean;
};

const BASE = { stick: 30, btn: 13.5, wheel: 12 }; // vh

/** Always-visible in-game pause chip (top right, outside the draggable overlay). */
export function PauseButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      data-nav
      onClick={onClick}
      aria-label="Pause"
      className="absolute right-[max(8px,env(safe-area-inset-right))] top-[max(8px,env(safe-area-inset-top))] z-20 grid h-9 w-9 place-items-center border border-white/35 bg-black/55 text-white backdrop-blur-[2px] active:bg-blood/70"
    >
      <svg width="11" height="12" viewBox="0 0 11 12" fill="currentColor">
        <rect x="0" y="0" width="3.5" height="12" />
        <rect x="7.5" y="0" width="3.5" height="12" />
      </svg>
    </button>
  );
}

export function TouchControls({ layout, edit, selected, onSelect, onMove, onAction, onStick, mirror }: Props) {
  const s = settingsStore.use();
  const root = useRef<HTMLDivElement>(null);
  const drag = useRef<{ id: string; dx: number; dy: number } | null>(null);
  const [pressed, setPressed] = useState<Record<string, boolean>>({});
  const [knob, setKnob] = useState({ x: 0, y: 0, edge: false });
  const stickRef = useRef<HTMLDivElement>(null);
  const mx = (x: number) => (mirror ? 100 - x : x);

  const list = CONTROLS.filter((c) => !c.extra || s.extraButtons || edit);
  const scale = s.buttonSize / 100;

  const vib = () => s.vibration && navigator.vibrate?.(Math.round(s.vibrationStrength / 4));

  const down = (id: string, e: RPE) => {
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    if (edit) {
      const r = root.current!.getBoundingClientRect();
      const p = layout[id];
      drag.current = { id, dx: e.clientX - (r.left + (mx(p.x) / 100) * r.width), dy: e.clientY - (r.top + (p.y / 100) * r.height) };
      onSelect?.(id);
      return;
    }
    setPressed((x) => ({ ...x, [id]: true }));
    vib();
    if (id === "stick") moveStick(e);
    else onAction?.(id);
  };
  const move = (id: string, e: RPE) => {
    if (edit && drag.current?.id === id) {
      const r = root.current!.getBoundingClientRect();
      let x = Math.min(97, Math.max(3, ((e.clientX - drag.current.dx - r.left) / r.width) * 100));
      if (mirror) x = 100 - x;
      const y = Math.min(96, Math.max(4, ((e.clientY - drag.current.dy - r.top) / r.height) * 100));
      onMove?.(id, { ...layout[id], x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 });
    } else if (!edit && id === "stick" && pressed.stick) moveStick(e);
  };
  const up = (id: string) => {
    drag.current = null;
    setPressed((x) => ({ ...x, [id]: false }));
    if (id === "stick") {
      setKnob({ x: 0, y: 0, edge: false });
      onStick?.(0, 0, false);
    }
  };
  const moveStick = (e: RPE) => {
    const r = stickRef.current!.getBoundingClientRect();
    const cx = r.left + r.width / 2,
      cy = r.top + r.height / 2,
      rad = r.width / 2 - r.width * 0.18;
    let dx = e.clientX - cx,
      dy = e.clientY - cy;
    const d = Math.hypot(dx, dy);
    if (d > rad) {
      dx = (dx / d) * rad;
      dy = (dy / d) * rad;
    }
    const edge = s.stickEdgeSprint && d > rad * 0.98;
    setKnob({ x: dx, y: dy, edge });
    onStick?.(dx / rad, dy / rad, edge);
  };

  return (
    <div ref={root} className="absolute inset-0 touch-none" style={{ opacity: edit ? 1 : s.opacity / 100 }}>
      {list.map((c) => {
        const p = layout[c.id];
        if (!p) return null;
        const size = `max(${c.kind === "stick" ? 90 : 38}px, ${BASE[c.kind] * p.s * scale}vh)`;
        const sel = edit && selected === c.id;
        const on = pressed[c.id];
        return (
          <div
            key={c.id}
            ref={c.id === "stick" ? stickRef : undefined}
            onPointerDown={(e) => down(c.id, e)}
            onPointerMove={(e) => move(c.id, e)}
            onPointerUp={() => up(c.id)}
            onPointerCancel={() => up(c.id)}
            className={cn(
              "absolute grid -translate-x-1/2 -translate-y-1/2 select-none place-items-center transition-[background,box-shadow,transform] duration-75",
              c.kind === "wheel" ? "" : "rounded-full",
              c.kind === "stick" ? "border-2 border-white/35 bg-black/30" : "border-2 border-white/50 bg-black/45",
              on && c.kind !== "stick" && "scale-90 border-blood-hi bg-blood/70",
              sel && "border-blood-hi shadow-[0_0_0_3px_rgba(255,48,48,.35),0_0_24px_rgba(255,48,48,.5)]",
              edit && !sel && "border-dashed",
              c.extra && edit && !s.extraButtons && "opacity-40"
            )}
            style={{
              left: `${mx(p.x)}%`,
              top: `${p.y}%`,
              width: size,
              height: size,
              clipPath: c.kind === "wheel" ? "polygon(25% 3%,75% 3%,100% 50%,75% 97%,25% 97%,0 50%)" : undefined,
              cursor: edit ? "grab" : "pointer",
            }}
          >
            {c.kind === "stick" ? (
              <>
                <div className="absolute inset-[14%] rounded-full border border-white/10" />
                <div
                  className={cn("h-[40%] w-[40%] rounded-full border-2 transition-colors", knob.edge ? "border-blood-hi bg-blood/80" : "border-white/70 bg-white/25")}
                  style={{ transform: `translate(${edit ? 0 : knob.x}px, ${edit ? 0 : knob.y}px)` }}
                />
                {!edit && knob.edge && <span className="absolute -top-5 font-ui text-[10px] uppercase tracking-[0.3em] text-blood-hi">Sprint</span>}
              </>
            ) : (
              <span className={cn("font-ui font-medium uppercase tracking-wider text-white", c.kind === "wheel" ? "text-[10px]" : "text-[clamp(9px,2.6vh,13px)]")}>{c.label}</span>
            )}
          </div>
        );
      })}
    </div>
  );
}
