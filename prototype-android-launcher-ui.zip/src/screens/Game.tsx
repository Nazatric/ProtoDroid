import { useEffect, useRef, useState } from "react";
import { ART } from "../lib/art";
import { PauseButton } from "../components/TouchControls";
import { TouchControls } from "../components/TouchControls";
import { Btn, Modal } from "../components/ui";
import { appendLog, layoutStore } from "../lib/data";
import { settingsStore } from "../lib/settings";
import { useBack } from "../lib/nav";
import { sfx } from "../lib/sfx";

/** Standalone preview of the in-game touch layer. Inside the Android host this screen is replaced by the native surface. */
export default function Game({ onQuit, onSettings }: { onQuit: () => void; onSettings: () => void }) {
  const s = settingsStore.use();
  const layout = layoutStore.use();
  const [paused, setPaused] = useState(false);
  const [fps, setFps] = useState(0);
  const [ms, setMs] = useState(16.7);
  const cam = useRef({ x: 0, y: 0, vx: 0, vy: 0 });
  const bg = useRef<HTMLImageElement>(null);

  useBack(() => setPaused((p) => !p));

  useEffect(() => {
    let raf = 0,
      n = 0,
      t0 = performance.now(),
      prev = t0,
      acc = 0;
    const limit = s.batterySaver ? Math.min(s.fpsLimit || 30, 30) : s.fpsLimit;
    const loop = (t: number) => {
      raf = requestAnimationFrame(loop);
      const dt = t - prev;
      if (limit && dt < 1000 / limit - 1) return;
      prev = t;
      n++;
      acc += dt;
      const c = cam.current;
      c.x += c.vx * dt * 0.02 * (s.cameraSpeed / 50);
      c.y += c.vy * dt * 0.02 * (s.cameraSpeed / 50) * (s.invertY ? -1 : 1);
      c.x = Math.max(-40, Math.min(40, c.x));
      c.y = Math.max(-20, Math.min(20, c.y));
      if (bg.current) bg.current.style.transform = `scale(1.18) translate(${-c.x}px, ${-c.y}px)`;
      if (t - t0 > 500) {
        setFps(Math.round((n * 1000) / (t - t0)));
        setMs(acc / n);
        n = 0;
        acc = 0;
        t0 = t;
      }
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [s.fpsLimit, s.batterySaver, s.cameraSpeed, s.invertY]);

  return (
    <div data-screen className="relative h-full w-full overflow-hidden bg-black">
      <img ref={bg} src={ART.game} alt="" className="absolute inset-0 h-full w-full object-cover" style={{ transform: "scale(1.18)" }} draggable={false} />
      <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-transparent to-black/30" />
      <div className="vignette" />

      {s.showFps && (
        <div className="pointer-events-none absolute left-[max(8px,env(safe-area-inset-left))] top-2 z-10 bg-black/65 px-2 py-1 font-mono text-[10px] leading-tight text-white">
          <div>
            <span className="text-blood-hi">{fps}</span> FPS · {ms.toFixed(1)} ms
          </div>
          <div className="text-ash">
            {s.renderHeight || "native"}p · {s.vulkanDriver} · {s.fpsLimit ? `cap ${s.fpsLimit}` : "uncapped"}
          </div>
        </div>
      )}

      <PauseButton onClick={() => setPaused(true)} />

      <TouchControls
        layout={layout}
        mirror={s.leftHanded}
        onAction={(id) => {
          if (id === "pause") return (sfx.select(), setPaused(true));
          sfx.toggle(true);
        }}
        onStick={(x, y) => {
          cam.current.vx = x;
          cam.current.vy = y;
        }}
      />

      {paused && (
        <Modal
          title="Paused"
          onClose={() => setPaused(false)}
          actions={
            <>
              <Btn variant="plain" onClick={onSettings}>
                Settings
              </Btn>
              <Btn
                variant="danger"
                onClick={() => {
                  appendLog([`[${new Date().toISOString()}] engine stopped`]);
                  onQuit();
                }}
              >
                Quit
              </Btn>
              <Btn variant="primary" onClick={() => setPaused(false)}>
                Resume
              </Btn>
            </>
          }
        >
          Touch controls follow your Layout and Controls settings. FPS limit changes immediately.
        </Modal>
      )}
    </div>
  );
}
