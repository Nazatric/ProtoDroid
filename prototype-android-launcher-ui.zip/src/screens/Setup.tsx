import { useEffect, useState } from "react";
import { Backdrop, Btn, Header, HintBar, Panel, Tag } from "../components/ui";
import { dataStore, isReady, toast } from "../lib/data";
import { hasHost, requestFileAccess, refreshGameData } from "../lib/bridge";
import { sfx } from "../lib/sfx";
import { ART } from "../lib/art";

export default function Setup({ onDone, onBack }: { onDone: () => void; onBack: () => void }) {
  const data = dataStore.use();
  const [pending, setPending] = useState(false);
  const ready = isReady(data);

  useEffect(() => {
    if (pending && data.setupDone) onDone();
  }, [pending, data.setupDone, onDone]);

  const allowAccess = () => {
    sfx.select();
    if (hasHost()) {
      if (requestFileAccess()) {
        setPending(true);
        return;
      }
      toast("Native file-access bridge is not connected", "warn");
      return;
    }

    // Browser preview has no Android permission API; continue without fake game data.
    dataStore.set({ access: true, setupDone: true });
    toast("Preview access enabled");
    onDone();
  };

  const checkAgain = () => {
    if (refreshGameData()) {
      toast("Checking app game folder");
      return;
    }
    toast("File check is handled by the Android host", "warn");
  };

  const continueToLauncher = () => {
    dataStore.set({ setupDone: true });
    onDone();
  };

  return (
    <div data-screen className="relative flex h-full w-full flex-col">
      <Backdrop img={ART.setup} dim={0.22} position="55% 45%" />
      <Header title="SETUP" onBack={onBack} icon />

      <main className="relative z-10 flex min-h-0 flex-1 items-center justify-center px-[max(16px,env(safe-area-inset-left))] py-4 pr-[max(16px,env(safe-area-inset-right))]">
        <Panel className="anim-fade w-full max-w-2xl p-[clamp(16px,4vw,28px)]">
          <div className="flex flex-wrap items-center gap-3">
            <Tag tone="red">Device access</Tag>
            <Tag tone={ready ? "ok" : data.access ? "ash" : "red"}>
              {ready ? "Game data ready" : data.access ? "No game data" : "Permission needed"}
            </Tag>
          </div>

          <h2 className="mt-3 font-ui text-[clamp(20px,5vh,32px)] font-medium uppercase tracking-[0.1em] text-white">
            {data.access ? (ready ? "Ready to launch" : "Waiting for game data") : "Allow file access"}
          </h2>
          <p className="safe-wrap mt-2 max-w-xl text-[clamp(13px,2.4vh,16px)] leading-relaxed text-bone/75">
            The Android app checks its configured Prototype data location. This launcher does not open a folder picker or copy game files.
          </p>

          <div className="mt-5 flex flex-wrap gap-2">
            {!data.access ? (
              <Btn variant="primary" disabled={pending} onClick={allowAccess}>
                {pending ? "Waiting for Android…" : hasHost() ? "Allow file access" : "Continue preview"}
              </Btn>
            ) : (
              <>
                <Btn variant="primary" onClick={continueToLauncher}>
                  Continue
                </Btn>
                {!ready && <Btn onClick={checkAgain}>Check again</Btn>}
              </>
            )}
          </div>
        </Panel>
      </main>

      <HintBar text={ready ? "Game data verified on this device" : "Permission and game-file checks are owned by the Android app"} />
    </div>
  );
}