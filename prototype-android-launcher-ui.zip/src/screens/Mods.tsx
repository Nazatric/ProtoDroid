import { useRef, useState } from "react";
import { Backdrop, Btn, Header, HintBar, Modal, Panel, Tag } from "../components/ui";
import { cn } from "../utils/cn";
import { modsStore, sha256, toast, type Mod } from "../lib/data";
import { sfx } from "../lib/sfx";
import { ART } from "../lib/art";

const COVERS = ART.stills;

function coverFor(sha: string) {
  return COVERS[parseInt(sha.slice(0, 4), 16) % COVERS.length];
}

export default function Mods({ onBack }: { onBack: () => void }) {
  const { list } = modsStore.use();
  const [sel, setSel] = useState<string | null>(list[0]?.id ?? null);
  const [armed, setArmed] = useState<string | null>(null);
  const [confirmNative, setConfirmNative] = useState<Mod | null>(null);
  const [busy, setBusy] = useState(false);
  const file = useRef<HTMLInputElement>(null);
  const mod = list.find((m) => m.id === sel) ?? null;
  const active = list.filter((m) => m.enabled).length;

  const setEnabled = (m: Mod, v: boolean) => {
    if (m.error) return (sfx.error(), toast(m.error, "warn"));
    if (v && m.kind === "Native plugin" && !confirmNative) return setConfirmNative(m);
    modsStore.set((s) => ({ list: s.list.map((x) => (x.id === m.id ? { ...x, enabled: v } : x)) }));
    sfx.toggle(v);
    toast(v ? `${m.name} enabled` : `${m.name} disabled`);
  };

  const remove = (m: Mod) => {
    if (armed !== m.id) {
      setArmed(m.id);
      sfx.error();
      setTimeout(() => setArmed((x) => (x === m.id ? null : x)), 3000);
      return;
    }
    modsStore.set((s) => ({ list: s.list.filter((x) => x.id !== m.id) }));
    setSel(list.find((x) => x.id !== m.id)?.id ?? null);
    setArmed(null);
    toast("Mod removed");
  };

  const importMod = async (f?: File) => {
    if (!f) return;
    const n = f.name.toLowerCase();
    if (/\.(asi|dll|exe)$/.test(n)) {
      sfx.error();
      return toast("Windows plugins are not supported", "warn");
    }
    if (f.size > 2 * 1024 ** 3) return (sfx.error(), toast("Archive too large", "warn"));
    setBusy(true);
    const sha = await sha256(f);
    if (list.some((m) => m.sha === sha)) {
      setBusy(false);
      sfx.error();
      return toast("This mod is already imported", "warn");
    }
    const kind: Mod["kind"] = n.endsWith(".so") ? "Native plugin" : /\.dds$|tex|hd/.test(n) ? "Texture pack" : "Loose files";
    const m: Mod = {
      id: "m-" + sha.slice(0, 10),
      name: f.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "),
      kind,
      file: f.name,
      sizeKB: Math.max(1, Math.round(f.size / 1024)),
      sha,
      enabled: false,
      desc:
        kind === "Native plugin"
          ? "AArch64 plugin. Needs one extra confirmation before it loads."
          : kind === "Texture pack"
            ? "Same-size DDS textures mapped through textures.ini."
            : "Overlay files. Original game data and saves are untouched.",
      added: Date.now(),
    };
    modsStore.set((s) => ({ list: [...s.list, m] }));
    setSel(m.id);
    setBusy(false);
    sfx.impact();
    toast("Imported · starts disabled");
  };

  return (
    <div data-screen className="relative flex h-full w-full flex-col">
      <Backdrop img={ART.mods} dim={0.45} position="center 40%" />
      <Header
        title="MODS"
        onBack={onBack}
        icon
        right={
          <>
            <Tag>{active} active</Tag>
            <Btn small variant="primary" disabled={busy} onClick={() => file.current?.click()}>
              {busy ? "Hashing" : "Import"}
            </Btn>
            <input ref={file} type="file" accept=".zip,.so,.dds,.ini" className="hidden" onChange={(e) => (importMod(e.target.files?.[0]), (e.target.value = ""))} />
          </>
        }
      />

      <main className="relative z-10 flex min-h-0 flex-1 gap-3 px-[max(14px,env(safe-area-inset-left))] py-2.5 pr-[max(14px,env(safe-area-inset-right))]">
        <div className="scroll-y min-w-0 flex-1 space-y-1.5">
          {list.length === 0 && (
            <div className="frame flex h-full flex-col items-center justify-center gap-2 p-6 text-center">
              <span className="font-ui text-lg uppercase tracking-[0.18em]">No mods yet</span>
              <span className="max-w-xs text-xs text-ash">Import a ZIP, a loose file or an ARM64 .so.</span>
            </div>
          )}
          {list.map((m, i) => (
            <div
              key={m.id}
              data-nav
              tabIndex={0}
              onFocus={() => setSel(m.id)}
              onClick={() => setSel(m.id)}
              onKeyDown={(e) => e.key === "Enter" && setEnabled(m, !m.enabled)}
              style={{ animationDelay: `${i * 35}ms` }}
              className={cn(
                "frame anim-rise flex cursor-pointer items-center gap-2.5 p-1.5 transition-colors hover:bg-blood/10 focus-visible:border-blood-hi focus-visible:bg-blood/15",
                sel === m.id && "border-blood/70 bg-blood/10"
              )}
            >
              <div className="relative h-11 w-16 shrink-0 overflow-hidden">
                <img src={coverFor(m.sha)} alt="" className="h-full w-full object-cover" draggable={false} />
                <div className="absolute inset-0 bg-gradient-to-t from-blood/50 to-transparent" />
              </div>
              <div className="min-w-0 flex-1">
              <div className="line-clamp-2 safe-wrap font-ui text-sm uppercase leading-tight tracking-[0.1em] text-white">{m.name}</div>
                <div className="flex items-center gap-1.5">
                  <Tag tone={m.kind === "Native plugin" ? "red" : "ash"}>{m.kind}</Tag>
              <span className="shrink-0 whitespace-nowrap font-mono text-[10px] text-ash">{(m.sizeKB / 1024).toFixed(1)} MB</span>
                </div>
              </div>
              <button
                tabIndex={-1}
                aria-label={m.enabled ? "Disable" : "Enable"}
                onClick={(e) => (e.stopPropagation(), setEnabled(m, !m.enabled))}
                className={cn("relative h-6 w-11 shrink-0 border transition-colors", m.enabled ? "border-blood-hi bg-blood" : "border-white/20 bg-black/60")}
              >
                <span className={cn("absolute top-0.5 h-4 w-4 bg-white transition-all", m.enabled ? "left-[22px]" : "left-0.5 opacity-60")} />
              </button>
            </div>
          ))}
        </div>

        {mod && (
          <Panel key={mod.id} className="anim-fade scroll-y hidden w-[clamp(210px,32vw,310px)] shrink-0 p-2.5 sm:block">
            <div className="relative h-[14vh] min-h-12 w-full overflow-hidden">
              <img src={coverFor(mod.sha)} alt="" className="h-full w-full object-cover" draggable={false} />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/20 to-transparent" />
            </div>
            <div className="safe-wrap mt-1.5 font-ui text-base uppercase leading-tight tracking-[0.1em] text-white">{mod.name}</div>
            <div className="mt-1 flex gap-1.5">
              <Tag tone={mod.enabled ? "ok" : "ash"}>{mod.enabled ? "Active" : "Off"}</Tag>
              <Tag>{mod.kind}</Tag>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-bone/70">{mod.desc}</p>
            <div className="safe-wrap mt-1.5 font-mono text-[10px] text-ash">{mod.file}</div>
            <div className="mt-3 flex gap-2">
              <Btn small variant={mod.enabled ? "ghost" : "primary"} className="flex-1" silent onClick={() => setEnabled(mod, !mod.enabled)}>
                {mod.enabled ? "Disable" : "Enable"}
              </Btn>
              <Btn small variant="danger" silent onClick={() => remove(mod)}>
                {armed === mod.id ? "Sure?" : "Remove"}
              </Btn>
            </div>
          </Panel>
        )}
      </main>

      <HintBar text="Applied on the next launch. Saves stay untouched." />

      {confirmNative && (
        <Modal
          title="Native plugin"
          onClose={() => setConfirmNative(null)}
          actions={
            <>
              <Btn variant="plain" onClick={() => setConfirmNative(null)}>
                Cancel
              </Btn>
              <Btn
                variant="danger"
                onClick={() => {
                  const m = confirmNative;
                  modsStore.set((s) => ({ list: s.list.map((x) => (x.id === m.id ? { ...x, enabled: true } : x)) }));
                  setConfirmNative(null);
                  toast(`${m.name} enabled`);
                }}
              >
                Load
              </Btn>
            </>
          }
        >
          This plugin runs code inside the game. Only load an AArch64 build you trust.
        </Modal>
      )}
    </div>
  );
}
