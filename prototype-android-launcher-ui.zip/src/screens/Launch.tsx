import { useEffect, useState } from "react";
import { Backdrop, Logo, Progress } from "../components/ui";
import { appendLog, dataStore, driverStore, modsStore } from "../lib/data";
import { settingsStore } from "../lib/settings";
import { launchEngine } from "../lib/bridge";
import { gpuInfo } from "../lib/device";
import { sfx } from "../lib/sfx";
import { useBack } from "../lib/nav";
import { ART } from "../lib/art";

export default function Launch({ onDone, onCancel }: { onDone: () => void; onCancel: () => void }) {
  const [i, setI] = useState(0);
  useBack(onCancel);

  const s = settingsStore.get();
  const gpu = gpuInfo();
  const mods = modsStore.get().list.filter((m) => m.enabled);
  const custom = driverStore.get().installed.find((p) => p.id === driverStore.get().customId);
  const driver = s.vulkanDriver === "custom" ? custom?.name ?? "system" : s.vulkanDriver;

  const steps = ["Applying options", `Driver · ${driver}`, "Loading shader cache", mods.length ? `${mods.length} mod${mods.length > 1 ? "s" : ""} active` : "No mods", "Starting engine"];

  useEffect(() => {
    const t = new Date().toISOString();
    appendLog([
      `[${t}] session start`,
      `[host] ${s.preset} · ${s.renderHeight || "native"}p · cap ${s.fpsLimit || "off"} · aniso ${s.anisotropy}`,
      `[host] driver ${s.vulkanDriver} → ${driver} · ${gpu.gpu}`,
      ...mods.map((m) => `[mods] ${m.name}`),
    ]);
    // Hand off to the native ARM64 host when running inside the Android WebView.
    launchEngine({ settings: s, mods: mods.map((m) => m.id), driver: custom?.id ?? s.vulkanDriver, gamePath: dataStore.get().path });
    sfx.launch();
  }, []);

  useEffect(() => {
    if (i >= steps.length) {
      appendLog(["[engine] in game"]);
      const t = setTimeout(onDone, 400);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => {
      appendLog([`[boot] ${steps[i]}`]);
      sfx.tick();
      setI(i + 1);
    }, 320 + Math.random() * 220);
    return () => clearTimeout(t);
  }, [i]);

  return (
    <div data-screen className="relative h-full w-full overflow-hidden bg-ink" onClick={() => setI(steps.length)}>
      <Backdrop img={ART.launch} dim={0.35} tendrils={0.8} fade="none" position="center 40%" />
      <div className="relative z-10 flex h-full flex-col items-center justify-center gap-[4vh] px-8">
        <Logo size="clamp(32px,10.5vh,76px)" className="anim-flicker" />
        <div className="w-full max-w-md space-y-2">
          <Progress value={(i / steps.length) * 100} stripes />
          <div className="flex justify-between font-ui text-[10px] uppercase tracking-[0.16em] text-ash">
            <span>{steps[Math.min(i, steps.length - 1)]}</span>
            <span>{Math.round((i / steps.length) * 100)}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
