import { useState } from "react";
import { TouchControls } from "../components/TouchControls";
import { CONTROLS, DEFAULT_LAYOUT, layoutStore, toast } from "../lib/data";
import { settingsStore } from "../lib/settings";
import { useBack } from "../lib/nav";
import { sfx } from "../lib/sfx";
import { ART } from "../lib/art";
import { cn } from "../utils/cn";

function Stepper({ value, onDec, onInc }: { value: string; onDec: () => void; onInc: () => void }) {
  const b = "btn grid h-7 w-7 place-items-center border border-white/15 text-white active:bg-blood";
  return (
    <div className="flex items-center gap-1">
      <button data-nav className={b} onClick={() => (sfx.tick(), onDec())} aria-label="Smaller">
        −
      </button>
      <span className="w-9 text-center font-mono text-[11px] text-white">{value}</span>
      <button data-nav className={b} onClick={() => (sfx.tick(), onInc())} aria-label="Larger">
        +
      </button>
    </div>
  );
}

export default function Layout({ onBack }: { onBack: () => void }) {
  const layout = layoutStore.use();
  const s = settingsStore.use();
  const [sel, setSel] = useState<string | null>("jump");
  const [armReset, setArmReset] = useState(false);
  useBack(onBack);

  const cur = sel ? layout[sel] : null;
  const label = CONTROLS.find((c) => c.id === sel)?.label || "Select";
  const resize = (d: number) => sel && cur && layoutStore.set({ [sel]: { ...cur, s: Math.min(2, Math.max(0.5, Math.round((cur.s + d) * 100) / 100)) } });

  return (
    <div data-screen className="relative h-full w-full overflow-hidden bg-ink">
      <img src={ART.layout} alt="" className="absolute inset-0 h-full w-full object-cover opacity-80" draggable={false} />
      <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-transparent to-black/45" />
      <div
        className="pointer-events-none absolute inset-0 opacity-25"
        style={{ backgroundImage: "linear-gradient(rgba(255,255,255,.07) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.07) 1px,transparent 1px)", backgroundSize: "5% 10%" }}
      />

      <TouchControls layout={layout} edit mirror={s.leftHanded} selected={sel} onSelect={(id) => (setSel(id), sfx.tick())} onMove={(id, p) => layoutStore.set({ [id]: p })} />

      <div className="frame anim-fade absolute left-1/2 top-2 z-10 flex max-w-[calc(100vw-16px)] -translate-x-1/2 items-center gap-1.5 overflow-x-auto p-1">
        <button data-nav onClick={() => (sfx.select(), onBack())} className="btn h-7 bg-blood px-3 font-ui text-[11px] uppercase tracking-[0.18em] text-white hover:bg-blood-hi">
          Done
        </button>
        <span className="w-14 truncate text-center font-ui text-[11px] uppercase tracking-[0.14em] text-blood-hi">{label}</span>
        <Stepper value={cur ? `${Math.round(cur.s * 100)}%` : "—"} onDec={() => resize(-0.05)} onInc={() => resize(0.05)} />
        <button
          data-nav
          aria-label="Left-handed layout"
          onClick={() => {
            settingsStore.set({ leftHanded: !s.leftHanded });
            toast(s.leftHanded ? "Right-handed layout" : "Left-handed layout");
            sfx.toggle(!s.leftHanded);
          }}
          className={cn("btn flex h-7 items-center gap-1.5 border px-2 font-ui text-[10px] uppercase tracking-[0.12em]", s.leftHanded ? "border-blood-hi bg-blood/25 text-white" : "border-white/15 text-ash")}
        >
          Mirror
          <span className={cn("h-3 w-1.5", s.leftHanded ? "bg-blood-hi" : "bg-white/20")} />
        </button>
        <button
          data-nav
          onClick={() => {
            if (!armReset) {
              setArmReset(true);
              sfx.error();
              setTimeout(() => setArmReset(false), 2500);
              return;
            }
            layoutStore.set(DEFAULT_LAYOUT);
            setArmReset(false);
            sfx.impact();
            toast("Layout reset");
          }}
          className={cn("btn h-7 border px-2 font-ui text-[10px] uppercase tracking-[0.12em]", armReset ? "border-blood-hi bg-blood text-white" : "border-white/15 text-ash")}
        >
          {armReset ? "Sure?" : "Reset"}
        </button>
      </div>

      <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 font-ui text-[10px] uppercase tracking-[0.2em] text-white/55">Drag to move · select to resize</div>
    </div>
  );
}
