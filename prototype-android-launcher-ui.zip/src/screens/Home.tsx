import { useEffect, useRef, useState } from "react";
import { AppIcon, Backdrop, Btn, HintBar, Logo, Modal, Panel, Progress, Tag } from "../components/ui";
import { cn } from "../utils/cn";
import { dataStore, isReady, toast, appendLog } from "../lib/data";
import { settingsStore } from "../lib/settings";
import { sfx } from "../lib/sfx";
import { focusables, useBack } from "../lib/nav";
import { ART } from "../lib/art";
import { exitApp } from "../lib/bridge";
import type { Screen } from "../App";

const MENU: { id: Screen; label: string }[] = [
  { id: "launch", label: "Play" },
  { id: "settings", label: "Settings" },
  { id: "drivers", label: "Drivers" },
  { id: "mods", label: "Mods" },
  { id: "layout", label: "Layout" },
  { id: "logs", label: "Logs" },
  { id: "about", label: "About" },
];

const PHASES = [
  "Test level", "Movement", "Camera", "Jump", "Sprint", "Wall run", "Glide", "Targeting", "Combat", "Grab", "Quick powers", "Power wheel",
  "Disguise wheel", "Disguises", "Shadows", "Effects", "Streaming", "Audio", "Bink", "Touch", "Recovery", "Shutdown",
];

export default function Home({ go }: { go: (s: Screen) => void }) {
  const d = dataStore.use();
  const s = settingsStore.use();
  const ready = isReady(d);
  const [armed, setArmed] = useState(false);
  const [tour, setTour] = useState<null | { i: number; done: boolean }>(null);
  const [now, setNow] = useState(new Date());
  const [online, setOnline] = useState(navigator.onLine);
  const [shake, setShake] = useState(false);
  const taps = useRef<number[]>([]);

  // B / Escape exits the launcher when there is nowhere to go back to.
  useBack(() => {
    exitApp();
    if (window.history.length > 1) window.history.back();
  });

  useEffect(() => {
    const t = setTimeout(() => focusables()[0]?.focus({ preventScroll: true }), 550);
    const c = setInterval(() => setNow(new Date()), 15000);
    const on = () => setOnline(navigator.onLine);
    window.addEventListener("online", on);
    window.addEventListener("offline", on);
    return () => {
      clearTimeout(t);
      clearInterval(c);
      window.removeEventListener("online", on);
      window.removeEventListener("offline", on);
    };
  }, []);

  const toggleArm = () => {
    setArmed((a) => {
      const n = !a;
      toast(n ? "Diagnostic tour armed" : "Tour disarmed", n ? "warn" : "ok");
      n ? sfx.impact() : sfx.back();
      return n;
    });
  };

  // Hidden shortcut: type MERCER or tap the logo seven times.
  useEffect(() => {
    let buf = "";
    const k = (e: KeyboardEvent) => {
      if (e.key.length !== 1) return;
      buf = (buf + e.key.toUpperCase()).slice(-6);
      if (buf === "MERCER") {
        buf = "";
        toggleArm();
      }
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);

  const logoTap = () => {
    const t = performance.now();
    taps.current = [...taps.current.filter((x) => t - x < 2500), t];
    sfx.tick();
    if (taps.current.length >= 7) {
      taps.current = [];
      toggleArm();
    }
  };

  const pick = (id: Screen) => {
    if (id === "launch" && !ready) {
      sfx.error();
      setShake(true);
      setTimeout(() => setShake(false), 300);
      toast("Add your game files first", "warn");
      return;
    }
    sfx.select();
    go(id);
  };

  const startTour = () => {
    setTour({ i: 0, done: false });
    appendLog([`[tour] ${new Date().toISOString()} tour started`]);
    let i = 0;
    const id = setInterval(() => {
      i++;
      if (i % 2) sfx.tick();
      if (i >= PHASES.length) {
        clearInterval(id);
        setTour({ i, done: true });
        sfx.impact();
        appendLog(["[tour] 20 tested · 2 skipped · process exited"]);
      } else setTour({ i, done: false });
    }, 260);
  };

  const fps = s.fpsLimit === 0 ? "Unlimited" : `${s.fpsLimit} FPS`;
  const res = s.renderHeight === 0 ? "Native" : `${s.renderHeight}p`;

  return (
    <div data-screen className="relative flex h-full w-full flex-col">
      <Backdrop img={ART.home} position="60% center" dim={0.25} tendrils={0.8} />

      <div className="relative z-10 flex min-w-0 items-center gap-2 px-[max(14px,env(safe-area-inset-left))] pt-2.5 pr-[max(14px,env(safe-area-inset-right))]">
        <button
          data-nav
          onClick={logoTap}
          className="btn flex items-center gap-2 font-ui text-[11px] uppercase tracking-[0.22em] text-bone/80 hover:text-white"
          aria-label="ProtoDroid"
        >
          <AppIcon size={26} className="rounded-md" />
          ProtoDroid
        </button>
        <div className="ml-auto flex shrink-0 items-center gap-2">
          {!online && <Tag tone="red">Offline</Tag>}
          {armed && <Tag tone="red">Tour</Tag>}
          <span className="font-mono text-[10px] tracking-widest text-bone/70">{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
        </div>
      </div>

      <main className="relative z-10 flex min-h-0 flex-1 items-stretch px-[max(20px,calc(env(safe-area-inset-left)+14px))] pr-[max(14px,env(safe-area-inset-right))]">
        <div className="scroll-y flex min-h-0 flex-col overflow-y-auto">
         <div className="my-auto">
          <div className="anim-fade mb-[2vh] w-fit select-none" onClick={logoTap}>
            <Logo size="clamp(30px,10.5vh,66px)" className="anim-flicker" />
            <div className="mt-1.5 pl-2 font-ui text-[clamp(8px,2.1vh,11px)] uppercase tracking-[0.5em] text-ash">Native Android Port</div>
          </div>
          <nav className={cn("flex flex-col", shake && "anim-shake")}>
            {MENU.map((m, i) => (
              <button
                key={m.id}
                data-nav
                onClick={() => pick(m.id)}
                className="menu-item anim-rise h-[clamp(27px,7.8vh,48px)] pr-12"
                style={{ animationDelay: `${100 + i * 45}ms` }}
              >
                <span className="tick w-3 font-ui text-blood-hi group-hover:text-white group-focus-visible:text-white">▸</span>
                <span
                  className={cn(
                    "font-ui font-medium uppercase leading-none tracking-[0.16em]",
                    i === 0 ? "text-[clamp(17px,5.6vh,32px)] text-white" : "text-[clamp(13px,4.1vh,22px)] text-bone/85"
                  )}
                >
                  {m.label}
                </span>
              </button>
            ))}
          </nav>
         </div>
        </div>

        <div className="ml-auto flex flex-col justify-end pb-2.5">
          <Panel className="anim-fade w-[clamp(195px,27vw,290px)] shrink-0 p-2.5">
            <div className="flex items-center gap-2">
              <span className={cn("h-1.5 w-1.5 rounded-full", ready ? "bg-white" : "bg-blood-hi anim-blink")} />
              <span className="font-ui text-[11px] uppercase tracking-[0.24em] text-bone/80">Game data</span>
              <span className={cn("ml-auto font-ui text-[11px] uppercase tracking-[0.16em]", ready ? "text-white" : "text-blood-hi")}>{ready ? "Ready" : "Missing"}</span>
            </div>
            <div className="mt-2 flex items-center gap-3 font-mono text-[10px] uppercase tracking-wider text-ash">
              <span className="text-white/90">{s.vulkanDriver}</span>
              <i className="h-2 w-px bg-white/20" />
              <span>{res}</span>
              <i className="h-2 w-px bg-white/20" />
              <span>{fps}</span>
            </div>
            <div className="mt-2 flex gap-1.5">
              <Btn small className="min-w-0 flex-1" onClick={() => go("setup")}>
                {ready ? "Game data" : "File access"}
              </Btn>
              <Btn small variant="ghost" onClick={() => go("settings")} title="Settings" className="w-8 px-0">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="3" />
                  <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 7 19.4a1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a1.7 1.7 0 0 0-1.6-1H1a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 3 9a1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 9 3a1.7 1.7 0 0 0 1-1.6V1a2 2 0 1 1 4 0v.1A1.7 1.7 0 0 0 15 3a1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 9v.1a1.7 1.7 0 0 0 1.6 1H23a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" />
                </svg>
              </Btn>
            </div>
          </Panel>
        </div>
      </main>

      <HintBar
        text={ready ? "Ready to play" : "Add your own game files"}
        back={!ready}
        backLabel="Exit"
        onBack={() => {
          if (window.history.length > 1) window.history.back();
          exitApp();
        }}
      />

      {armed && !tour && (
        <Modal
          title="Diagnostic tour"
          onClose={() => setArmed(false)}
          actions={
            <>
              <Btn variant="plain" onClick={() => setArmed(false)}>
                Cancel
              </Btn>
              <Btn variant="primary" onClick={startTour} disabled={!ready}>
                Start
              </Btn>
            </>
          }
        >
          <p className="leading-relaxed">22 automated phases with isolated saves, logs and shader cache. The game closes when the tour finishes.</p>
        </Modal>
      )}
      {tour && (
        <Modal
          title={tour.done ? "Tour complete" : "Tour running"}
          onClose={() => tour.done && (setTour(null), setArmed(false))}
          actions={tour.done && <Btn variant="primary" onClick={() => (setTour(null), setArmed(false))}>Done</Btn>}
        >
          <Progress value={(tour.i / PHASES.length) * 100} stripes={!tour.done} label={tour.done ? "Result written" : `${tour.i + 1}/22 · ${PHASES[tour.i]}`} />
          <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-0.5 font-mono text-[10px] sm:grid-cols-3">
            {PHASES.map((p, i) => (
              <div key={p} className={cn("flex gap-1.5", i < tour.i ? "text-bone" : i === tour.i ? "text-blood-hi" : "text-ash/40")}>
                <span>{i < tour.i ? "✓" : i === tour.i ? "▸" : "·"}</span>
                {p}
              </div>
            ))}
          </div>
        </Modal>
      )}
    </div>
  );
}
