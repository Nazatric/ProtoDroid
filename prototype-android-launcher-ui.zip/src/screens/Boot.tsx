import { useEffect, useState } from "react";
import { AppIcon, Backdrop, Logo } from "../components/ui";
import { sfx } from "../lib/sfx";
import { dataStore, isReady } from "../lib/data";
import { ART } from "../lib/art";

export default function Boot({ onDone }: { onDone: () => void }) {
  const ready = isReady(dataStore.get());
  const [n, setN] = useState(0);
  const [ready2, setReady2] = useState(false);
  const lines = ["protodroid · arm64", "renderer · DXVK", ready ? "game data · found" : "game data · missing"];

  useEffect(() => {
    if (n < lines.length) {
      const t = setTimeout(() => {
        setN(n + 1);
        sfx.type();
      }, n === 0 ? 300 : 240);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => {
      setReady2(true);
      sfx.impact();
    }, 400);
    return () => clearTimeout(t);
  }, [n, lines.length]);

  const start = () => {
    sfx.unlock();
    if (!ready2) {
      setN(lines.length);
      setReady2(true);
      return;
    }
    sfx.select();
    onDone();
  };

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (["Enter", " ", "a", "A"].includes(e.key)) start();
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  return (
    <div data-screen className="relative h-full w-full cursor-pointer overflow-hidden bg-ink" onClick={start}>
      <Backdrop img={ART.boot} dim={0.12} fade="none" tendrils={0.7} />

      <div className="absolute left-[max(18px,env(safe-area-inset-left))] top-4 space-y-0.5 font-mono text-[clamp(9px,2.4vh,12px)] text-ash">
        {lines.slice(0, n).map((l, i) => (
          <div key={i} className={i === 0 ? "text-blood-hi" : l.includes("missing") ? "text-amber-400" : ""}>
            {l}
          </div>
        ))}
      </div>

      <div className="absolute right-[max(18px,env(safe-area-inset-right))] top-4 flex items-center gap-2 opacity-80">
        <AppIcon size={24} className="rounded-md" />
        <span className="font-ui text-[10px] uppercase tracking-[0.24em] text-bone/70">ProtoDroid</span>
      </div>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <Logo size="clamp(40px,14vh,104px)" className="anim-logo-in" />
        <div className="anim-fade mt-3 font-ui text-[clamp(9px,2.3vh,12px)] uppercase tracking-[0.55em] text-ash" style={{ animationDelay: "400ms" }}>
          Native Android Port
        </div>
        {ready2 && (
          <div className="anim-fade mt-[7vh] flex items-center gap-3 font-ui text-[clamp(11px,3.2vh,15px)] uppercase tracking-[0.45em] text-bone">
            <span className="h-px w-8 bg-blood-hi" />
            <span className="anim-blink">Tap to start</span>
            <span className="h-px w-8 bg-blood-hi" />
          </div>
        )}
      </div>
    </div>
  );
}
