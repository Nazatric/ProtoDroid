import { useEffect, useRef, useState } from "react";
import { Backdrop, Btn, Header, HintBar, Modal, Panel, Progress, Tag } from "../components/ui";
import { cn } from "../utils/cn";
import { CATALOG, driverStore, sha256, toast, type InstalledPkg, type Pkg } from "../lib/data";
import { setSetting, settingsStore } from "../lib/settings";
import { gpuInfo } from "../lib/device";
import { sfx } from "../lib/sfx";
import { ART } from "../lib/art";

const MODES = [
  { id: "auto", name: "Auto", desc: "Picks a driver for this GPU." },
  { id: "system", name: "System", desc: "Use the phone's driver." },
  { id: "turnip", name: "Turnip", desc: "Mesa Turnip. Adreno only." },
  { id: "custom", name: "Custom", desc: "Use an installed package." },
];

export default function Drivers({ onBack }: { onBack: () => void }) {
  const s = settingsStore.use();
  const dr = driverStore.use();
  const gpu = gpuInfo();
  const [tab, setTab] = useState<"installed" | "downloads">(dr.installed.length ? "installed" : "downloads");
  const [showAll, setShowAll] = useState(false);
  const [dl, setDl] = useState<{ id: string; p: number; stage: string } | null>(null);
  const [details, setDetails] = useState<InstalledPkg | null>(null);
  const [armedRemove, setArmedRemove] = useState<string | null>(null);
  const [online, setOnline] = useState(navigator.onLine);
  const file = useRef<HTMLInputElement>(null);
  const timer = useRef<number | undefined>(undefined);

  useEffect(() => {
    const on = () => setOnline(navigator.onLine);
    window.addEventListener("online", on);
    window.addEventListener("offline", on);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", on);
      clearInterval(timer.current);
    };
  }, []);

  const custom = dr.installed.find((p) => p.id === dr.customId);
  const effective =
    s.vulkanDriver === "custom"
      ? custom?.name ?? "System"
      : s.vulkanDriver === "turnip"
        ? gpu.family === "Mali" ? "System (Mali)" : "Turnip"
        : s.vulkanDriver === "system" ? "System" : gpu.family === "Adreno" ? "Auto · Turnip" : "Auto · System";

  const pickMode = (id: string) => {
    if (id === "custom" && !custom) {
      sfx.error();
      toast("Install a package first", "warn");
      setTab(dr.installed.length ? "installed" : "downloads");
      return;
    }
    sfx.select();
    setSetting("vulkanDriver", id);
  };

  const install = (p: Pkg) => {
    if (!online) return toast("Offline · import a local package", "warn");
    let v = 0;
    setDl({ id: p.id, p: 0, stage: "Downloading" });
    timer.current = window.setInterval(() => {
      v += 4 + Math.random() * 8;
      if (v < 100) setDl({ id: p.id, p: v, stage: "Downloading" });
      else if (v < 126) setDl({ id: p.id, p: 100, stage: "Checking SHA-256" });
      else {
        clearInterval(timer.current);
        driverStore.set((d) => ({ installed: [...d.installed.filter((x) => x.id !== p.id), { ...p, installedAt: Date.now() }] }));
        setDl(null);
        sfx.impact();
        toast(`${p.name} installed`);
      }
    }, 90);
  };

  const importPkg = async (f: File | undefined) => {
    if (!f) return;
    if (!/\.(zip|adpkg|so)$/i.test(f.name)) {
      sfx.error();
      return toast("Use .zip, .adpkg or .so", "warn");
    }
    setDl({ id: "import", p: 40, stage: "Hashing" });
    const sha = await sha256(f);
    const pkg: InstalledPkg = {
      id: "imp-" + sha.slice(0, 10),
      name: f.name.replace(/\.(zip|adpkg|so)$/i, ""),
      version: "imported",
      family: "Any",
      sizeMB: Math.round((f.size / 1048576) * 10) / 10,
      sha,
      note: "Imported package. Validated as Android ARM64 and probed on the next launch.",
      installedAt: Date.now(),
      imported: true,
    };
    driverStore.set((d) => ({ installed: [...d.installed.filter((x) => x.id !== pkg.id), pkg] }));
    setDl(null);
    setTab("installed");
    sfx.impact();
    toast("Package imported");
  };

  const use = (p: InstalledPkg) => {
    driverStore.set({ customId: p.id });
    setSetting("vulkanDriver", "custom");
    toast(`Using ${p.name}`);
  };

  const remove = (p: InstalledPkg) => {
    if (armedRemove !== p.id) {
      setArmedRemove(p.id);
      sfx.error();
      setTimeout(() => setArmedRemove((x) => (x === p.id ? null : x)), 3000);
      return;
    }
    driverStore.set((d) => ({ installed: d.installed.filter((x) => x.id !== p.id), customId: d.customId === p.id ? null : d.customId }));
    if (dr.customId === p.id && s.vulkanDriver === "custom") setSetting("vulkanDriver", "auto");
    setArmedRemove(null);
    toast("Removed");
  };

  const catalog = CATALOG.filter((p) => showAll || gpu.family === "Other" || p.family === gpu.family);

  return (
    <div data-screen className="relative flex h-full w-full flex-col">
      <Backdrop img={ART.drivers} dim={0.45} />
      <Header title="DRIVERS" onBack={onBack} icon right={<Tag>{gpu.family === "Other" ? "GPU" : gpu.family}</Tag>} />

      <main className="scroll-y relative z-10 min-h-0 flex-1 px-[max(14px,env(safe-area-inset-left))] py-2.5 pr-[max(14px,env(safe-area-inset-right))]">
        <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {MODES.map((m, i) => {
            const on = s.vulkanDriver === m.id;
            return (
              <button
                key={m.id}
                data-nav
                onClick={() => pickMode(m.id)}
                style={{ animationDelay: `${i * 45}ms` }}
                className={cn("btn frame anim-rise flex flex-col items-start gap-1 p-2.5 text-left", on ? "border-blood bg-blood/20" : "hover:border-white/25", m.id === "custom" && !custom && "opacity-55")}
              >
                <div className="flex w-full items-center justify-between">
                  <span className="font-ui text-[clamp(14px,4.2vh,18px)] font-medium uppercase tracking-[0.14em]">{m.name}</span>
                  <span className={cn("grid h-4 w-4 place-items-center border text-[10px]", on ? "border-blood-hi bg-blood-hi text-white" : "border-white/30")}>{on ? "✓" : ""}</span>
                </div>
                <span className="line-clamp-2 safe-wrap text-[11px] leading-tight text-ash">{m.id === "custom" && custom ? custom.name : m.desc}</span>
              </button>
            );
          })}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <span className="mr-1 font-ui text-[11px] uppercase tracking-[0.24em] text-bone/80">
            {s.vulkanDriver} <span className="text-ash">→</span> <span className="text-white">{effective}</span>
          </span>
          <div className="ml-auto flex gap-1.5">
            {(["installed", "downloads"] as const).map((t) => (
              <button
                key={t}
                data-nav
                onClick={() => (sfx.tick(), setTab(t))}
                className={cn("btn h-7 px-2.5 font-ui text-[11px] uppercase tracking-[0.16em]", tab === t ? "bg-white text-black" : "border border-white/15 text-ash hover:text-white")}
              >
                {t === "installed" ? `Installed ${dr.installed.length}` : "Downloads"}
              </button>
            ))}
            {tab === "downloads" && gpu.family !== "Other" && (
              <Btn small variant="plain" onClick={() => setShowAll((v) => !v)}>
                {showAll ? gpu.family : "All"}
              </Btn>
            )}
            <Btn small onClick={() => file.current?.click()}>
              Import
            </Btn>
            <input ref={file} type="file" accept=".zip,.adpkg,.so" className="hidden" onChange={(e) => (importPkg(e.target.files?.[0]), (e.target.value = ""))} />
          </div>
        </div>

        {dl && (
          <Panel className="anim-fade mt-2 p-2.5">
            <Progress value={dl.p} stripes label={dl.stage} />
          </Panel>
        )}

        <div className="mt-2 space-y-1.5 pb-2">
          {tab === "downloads" &&
            (!online ? (
              <div className="frame p-3 text-sm text-ash">Offline. Use Import for a local driver package.</div>
            ) : (
              catalog.map((p, i) => {
                const have = dr.installed.some((x) => x.id === p.id);
                return (
                  <div key={p.id} className="frame anim-rise flex items-center gap-3 px-3 py-1.5" style={{ animationDelay: `${i * 35}ms` }}>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate font-ui text-sm uppercase tracking-[0.1em] text-white">{p.name}</span>
                        <Tag>{p.family}</Tag>
                        {p.experimental && <Tag tone="red">Experimental</Tag>}
                      </div>
                      <div className="safe-wrap font-mono text-[10px] leading-tight text-ash">
                        {p.version} · {p.sizeMB} MB
                      </div>
                    </div>
                    <Btn small variant={have ? "plain" : "primary"} disabled={have || !!dl} onClick={() => install(p)}>
                      {have ? "Installed" : "Download"}
                    </Btn>
                  </div>
                );
              })
            ))}

          {tab === "installed" &&
            (dr.installed.length === 0 ? (
              <div className="frame p-3 text-sm text-ash">No packages installed. Auto and System need none.</div>
            ) : (
              dr.installed.map((p, i) => {
                const active = dr.customId === p.id && s.vulkanDriver === "custom";
                return (
                  <div key={p.id} className={cn("frame anim-rise flex items-center gap-2 px-3 py-1.5", active && "border-blood")} style={{ animationDelay: `${i * 35}ms` }}>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate font-ui text-sm uppercase tracking-[0.1em] text-white">{p.name}</span>
                        {active && <Tag tone="ok">In use</Tag>}
                      </div>
                      <div className="truncate font-mono text-[10px] text-ash">
                        {p.version} · {p.sizeMB} MB
                      </div>
                    </div>
                    <Btn small variant={active ? "plain" : "primary"} disabled={active} onClick={() => use(p)}>
                      {active ? "Active" : "Use"}
                    </Btn>
                    <Btn small onClick={() => setDetails(p)}>
                      Info
                    </Btn>
                    <Btn small variant="danger" silent onClick={() => remove(p)}>
                      {armedRemove === p.id ? "Sure?" : "Remove"}
                    </Btn>
                  </div>
                );
              })
            ))}
        </div>
      </main>

      <HintBar text="Failed probes fall back to System" />

      {details && (
        <Modal title={details.name} onClose={() => setDetails(null)} actions={<Btn onClick={() => setDetails(null)}>Close</Btn>}>
          <dl className="grid grid-cols-[88px_1fr] gap-y-1.5 font-mono text-[11px]">
            {[
              ["Version", details.version],
              ["Family", details.family],
              ["Size", `${details.sizeMB} MB`],
              ["SHA-256", details.sha],
              ["ABI", "arm64-v8a"],
              ["Added", new Date(details.installedAt).toLocaleDateString()],
            ].map(([k, v]) => (
              <div key={k} className="contents">
                <dt className="uppercase text-ash">{k}</dt>
                <dd className="break-all text-white">{v}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-3 text-xs text-ash">{details.note}</p>
        </Modal>
      )}
    </div>
  );
}
