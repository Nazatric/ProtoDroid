import { useMemo, useState } from "react";
import { Backdrop, Btn, Header, HintBar } from "../components/ui";
import { cn } from "../utils/cn";
import { dataStore, logStore, toast } from "../lib/data";
import { settingsStore } from "../lib/settings";
import { deviceInfo } from "../lib/device";
import { saveText } from "../lib/bridge";
import { sfx } from "../lib/sfx";
import { ART } from "../lib/art";

const FILES = [
  { id: "native", name: "proto-native.log" },
  { id: "prev", name: "proto-native.prev.log" },
  { id: "dxvk", name: "d3d9.log" },
  { id: "cache", name: "dxvk-cache" },
];

export default function Logs({ onBack }: { onBack: () => void }) {
  const { runs } = logStore.use();
  const s = settingsStore.use();
  const d = dataStore.use();
  const [file, setFile] = useState("native");
  const dev = useMemo(deviceInfo, []);

  const content = useMemo(() => {
    const head = [`device ${dev.model} · ${dev.os}`, `gpu ${dev.gpu}`, `game ${d.path || "not set"}`];
    if (file === "native") return [...head, "", ...(runs.length ? runs.slice(-120) : ["no runs yet"])];
    if (file === "prev") {
      const starts = runs.map((r, i) => (r.includes("session start") ? i : -1)).filter((i) => i >= 0);
      return starts.length >= 2 ? [...head, "", ...runs.slice(starts[starts.length - 2], starts[starts.length - 1])] : ["no previous run"];
    }
    if (file === "dxvk")
      return [
        "DXVK 2.5.3 · Vulkan",
        `driver ${s.vulkanDriver}`,
        `presenter FIFO${s.fpsLimit ? ` · cap ${s.fpsLimit}` : ""}`,
        `anisotropy ${s.anisotropy}`,
        `render height ${s.renderHeight || "native"}`,
        "Prototype DF workaround · applied",
        "state cache · loaded",
      ];
    return ["DXVK pipeline state cache", "", "Clear it to rebuild from scratch."];
  }, [file, runs, s, d, dev]);

  const name = FILES.find((f) => f.id === file)!.name;
  const text = content.join("\n");

  return (
    <div data-screen className="relative flex h-full w-full flex-col">
      <Backdrop img={ART.logs} dim={0.8} />
      <Header
        title="LOGS"
        onBack={onBack}
        icon
        right={
          <>
            <Btn small onClick={() => navigator.clipboard?.writeText(text).then(() => toast("Copied"), () => toast("Clipboard unavailable", "warn"))}>
              Copy
            </Btn>
            <Btn small onClick={() => (saveText(name, text), toast(`${name} saved`))}>
              Save
            </Btn>
            <Btn
              small
              variant="danger"
              onClick={() => {
                logStore.reset();
                toast(file === "cache" ? "Cache cleared" : "Logs cleared");
              }}
            >
              Clear
            </Btn>
          </>
        }
      />
      <main className="relative z-10 flex min-h-0 flex-1">
        <nav className="w-[clamp(130px,24vw,210px)] shrink-0 border-r border-white/8 bg-black/50 py-1 pl-[env(safe-area-inset-left)]">
          {FILES.map((f) => (
            <button
              key={f.id}
              data-nav
              onFocus={() => setFile(f.id)}
              onClick={() => (sfx.tick(), setFile(f.id))}
              className={cn("nav-row block w-full px-3 py-2.5 text-left font-mono text-[11px]", file === f.id ? "bg-blood/20 text-white" : "text-bone/65")}
            >
              {f.name}
            </button>
          ))}
        </nav>
        <pre key={file} className="scroll-y anim-fade min-w-0 flex-1 select-text whitespace-pre-wrap break-all bg-black/55 px-4 py-3 pr-[max(14px,env(safe-area-inset-right))] font-mono text-[11px] leading-[1.6] text-bone/80">
          {content.map((l, i) => (
            <div key={i} className={cn(/error|fail|missing/i.test(l) ? "text-blood-hi" : /warn/i.test(l) ? "text-amber-300" : "")}>
              {l || "\u00a0"}
            </div>
          ))}
        </pre>
      </main>
      <HintBar text="Logs stay on this device." />
    </div>
  );
}
