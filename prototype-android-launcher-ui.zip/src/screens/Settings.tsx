import { useEffect, useRef, useState } from "react";
import { Backdrop, Btn, Header, HintBar, Modal } from "../components/ui";
import { ActionRow, ChoiceRow, SectionHeader, SliderRow, ToggleRow } from "../components/Rows";
import { cn } from "../utils/cn";
import { DEFAULTS, resetTab, setSetting, settingsStore, TABS, toIni, type Field, type Key, type Settings as S } from "../lib/settings";
import { toast } from "../lib/data";
import { hasHost, writeIni } from "../lib/bridge";
import { sfx } from "../lib/sfx";
import { ART } from "../lib/art";
import type { Screen } from "../App";

export default function Settings({ go, onBack }: { go: (s: Screen) => void; onBack: () => void }) {
  const s = settingsStore.use();
  const [tab, setTab] = useState(0);
  const [hint, setHint] = useState("Changes save automatically.");
  const [modal, setModal] = useState<null | "ini" | "reset" | { guard: string; k: Key }>(null);
  const [saved, setSaved] = useState(0);
  const rows = useRef<HTMLDivElement>(null);
  const first = useRef(true);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    setSaved(Date.now());
  }, [s]);

  useEffect(() => {
    rows.current?.scrollTo({ top: 0 });
  }, [tab]);

  const run = (id: string) => {
    if (id === "drivers" || id === "layout" || id === "logs") go(id as Screen);
    if (id === "ini") setModal("ini");
    if (id === "resetAll") setModal("reset");
  };

  const render = (f: Field, i: number) => {
    const delay = i * 24;
    if (f.t === "header") return <SectionHeader key={f.label} label={f.label} />;
    if (f.t === "action") return <ActionRow key={f.id} label={f.label} hint={f.hint} cta={f.cta} danger={f.danger} onHint={setHint} onRun={() => run(f.id)} delay={delay} />;
    if (f.when && !f.when(s)) return null;
    const common = { label: f.label, hint: f.hint, restart: f.restart, onHint: setHint, delay };
    if (f.t === "choice") return <ChoiceRow key={f.k} {...common} value={s[f.k] as string | number} opts={f.opts} onChange={(v) => setSetting(f.k, v as never)} />;
    if (f.t === "toggle")
      return (
        <ToggleRow
          key={f.k}
          {...common}
          value={s[f.k] as boolean}
          onChange={(v) => (v && f.guard ? setModal({ guard: f.guard, k: f.k }) : setSetting(f.k, v as never))}
        />
      );
    return <SliderRow key={f.k} {...common} value={s[f.k] as number} min={f.min} max={f.max} step={f.step} fmt={f.fmt} onChange={(v) => setSetting(f.k, v as never)} />;
  };

  const current = TABS[tab];
  const changed = current.fields.some((f) => "k" in f && s[f.k] !== DEFAULTS[f.k]);

  return (
    <div data-screen className="relative flex h-full w-full flex-col">
      <Backdrop img={ART.settings} dim={0.5} position="60% 40%" />
      <Header
        title="SETTINGS"
        onBack={onBack}
        icon
        right={
          <span key={saved} className={cn("hidden font-ui text-[10px] uppercase tracking-[0.2em] sm:block", saved ? "anim-fade text-bone/70" : "text-ash/50")}>
            {saved ? "Saved" : ""}
          </span>
        }
      />

      <main className="relative z-10 flex min-h-0 flex-1">
        <nav className="scroll-y flex w-[clamp(112px,20vw,168px)] shrink-0 flex-col border-r border-white/8 bg-black/45 py-1.5 pl-[env(safe-area-inset-left)]">
          {TABS.map((t, i) => (
            <button
              key={t.id}
              data-nav
              onClick={() => {
                if (i !== tab) sfx.tick();
                setTab(i);
              }}
              onFocus={() => setTab(i)}
              onKeyDown={(e) => {
                if (e.key === "ArrowRight") {
                  e.preventDefault();
                  rows.current?.querySelector<HTMLElement>("[data-nav]")?.focus();
                }
              }}
              className={cn(
                "btn relative flex h-[max(34px,8.8vh)] max-h-11 shrink-0 items-center px-3.5 text-left font-ui text-[clamp(11px,3.2vh,13px)] uppercase tracking-[0.16em] transition-colors",
                i === tab ? "text-white" : "text-ash hover:text-bone"
              )}
            >
              {i === tab && <span className="absolute inset-y-1 left-0 right-2 bg-gradient-to-r from-blood to-blood/0" style={{ clipPath: "polygon(0 0,100% 0,96% 100%,0 100%)" }} />}
              <span className="relative truncate">{t.label}</span>
            </button>
          ))}
        </nav>

        <div ref={rows} key={current.id} className="scroll-y min-w-0 flex-1 pb-5 pr-[env(safe-area-inset-right)]">
          <div className="flex h-8 items-center justify-between pl-4 pr-2">
            <span className="font-ui text-[11px] uppercase tracking-[0.24em] text-ash">{current.label}</span>
            <Btn small variant="plain" disabled={!changed} onClick={() => (resetTab(current), toast(`${current.label} reset`))}>
              Reset
            </Btn>
          </div>
          {current.fields.map(render)}
          {current.fields.some((f) => "restart" in f && f.restart) && (
            <p className="px-4 pt-2.5 font-ui text-[10px] text-ash">
              <span className="text-blood-hi">*</span> applies after restart
            </p>
          )}
        </div>
      </main>

      <HintBar text={hint} />

      {modal === "ini" && <IniModal s={s} onClose={() => setModal(null)} />}
      {modal === "reset" && (
        <Modal
          title="Reset all settings"
          onClose={() => setModal(null)}
          actions={
            <>
              <Btn variant="plain" onClick={() => setModal(null)}>
                Cancel
              </Btn>
              <Btn variant="danger" onClick={() => (settingsStore.reset(), setModal(null), toast("Settings reset"))}>
                Reset
              </Btn>
            </>
          }
        >
          Restore every launcher and engine option. Layout, mods and drivers stay as they are.
        </Modal>
      )}
      {modal && typeof modal === "object" && (
        <Modal
          title="Guarded option"
          onClose={() => setModal(null)}
          actions={
            <>
              <Btn variant="plain" onClick={() => setModal(null)}>
                Cancel
              </Btn>
              <Btn variant="danger" onClick={() => (setSetting(modal.k, true as never), setModal(null))}>
                Enable
              </Btn>
            </>
          }
        >
          {modal.guard}
        </Modal>
      )}
    </div>
  );
}

function IniModal({ s, onClose }: { s: S; onClose: () => void }) {
  const text = toIni(s);
  return (
    <Modal
      wide
      title="protodroid.ini"
      onClose={onClose}
      actions={
        <>
          <Btn onClick={() => navigator.clipboard?.writeText(text).then(() => toast("Copied"), () => toast("Clipboard unavailable", "warn"))}>Copy</Btn>
          <Btn
            variant="primary"
            onClick={() => {
              writeIni(text);
              toast(hasHost() ? "INI written to game folder" : "protodroid.ini saved");
            }}
          >
            Save
          </Btn>
        </>
      }
    >
      <pre className="select-text whitespace-pre-wrap font-mono text-[11px] leading-relaxed text-bone/85">{text}</pre>
    </Modal>
  );
}
