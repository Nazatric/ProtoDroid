import { useMemo, useState } from "react";
import { AppIcon, Backdrop, Btn, Header, HintBar, Panel, Tag } from "../components/ui";
import { deviceInfo } from "../lib/device";
import { dataStore } from "../lib/data";
import { hasHost } from "../lib/bridge";
import { sfx } from "../lib/sfx";
import { ART } from "../lib/art";

export default function About({ onBack }: { onBack: () => void }) {
  const dev = useMemo(deviceInfo, []);
  const d = dataStore.use();
  const [upd, setUpd] = useState<"idle" | "checking" | "ok" | "offline">("idle");

  const check = () => {
    if (!navigator.onLine) {
      setUpd("offline");
      sfx.error();
      return;
    }
    setUpd("checking");
    setTimeout(() => {
      setUpd("ok");
      sfx.toggle(true);
    }, 1100);
  };

  const rows: [string, string][] = [
    ["Device", dev.model],
    ["System", dev.os],
    ["GPU", dev.gpu],
    ["Display", dev.screen],
    ["Game", d.path ? `${d.sizeMB.toLocaleString()} MB` : "not set"],
    ["Host", hasHost() ? "Native" : "Standalone"],
  ];

  return (
    <div data-screen className="relative flex h-full w-full flex-col">
      <Backdrop img={ART.about} dim={0.4} position="center 45%" />
      <Header title="ABOUT" onBack={onBack} />
      <main className="scroll-y relative z-10 grid min-h-0 flex-1 grid-cols-1 gap-2.5 px-[max(14px,env(safe-area-inset-left))] py-3 pr-[max(14px,env(safe-area-inset-right))] sm:grid-cols-2">
        <div className="space-y-2.5">
          <Panel className="anim-fade flex items-center gap-3 p-3">
            <AppIcon size={62} className="rounded-xl" />
            <div className="min-w-0">
              <div className="font-ui text-lg uppercase tracking-[0.14em] text-white">ProtoDroid</div>
              <div className="font-mono text-[10px] text-ash">Launcher 0.9.2 · ARM64</div>
              <div className="mt-1 flex gap-1">
                <Tag tone="red">Native port</Tag>
                <Tag>Offline</Tag>
              </div>
            </div>
          </Panel>
          <Panel className="anim-fade p-3">
            <p className="text-xs leading-relaxed text-bone/75">
              A native Android host for Prototype (2009). D3D9 runs on Vulkan through DXVK, Bink through FFmpeg, XAudio2 through FAudio.
            </p>
            <p className="mt-2 font-mono text-[10px] text-ash">Bring your own game files. No DRM bypass included.</p>
          </Panel>
        </div>
        <div className="space-y-2.5">
          <Panel className="anim-fade p-3">
            <div className="flex items-center justify-between">
              <span className="font-ui text-[11px] uppercase tracking-[0.24em] text-ash">Device</span>
              {upd === "ok" && <Tag tone="ok">Up to date</Tag>}
              {upd === "offline" && <Tag tone="red">Offline</Tag>}
            </div>
            <dl className="mt-1.5 grid grid-cols-[64px_1fr] gap-y-0.5 font-mono text-[11px]">
              {rows.map(([k, v]) => (
                <div key={k} className="contents">
                  <dt className="uppercase text-ash">{k}</dt>
              <dd className="safe-wrap min-w-0 text-white">{v}</dd>
                </div>
              ))}
            </dl>
          </Panel>
          <div className="flex items-center gap-2">
            <Btn small onClick={check} disabled={upd === "checking"}>
              {upd === "checking" ? "Checking" : "Check updates"}
            </Btn>
            <span className="safe-wrap min-w-0 text-[10px] leading-tight text-ash">Community port · not affiliated with Activision or Radical</span>
          </div>
        </div>
      </main>
      <HintBar text="github.com/Nazatric/ProtoDroid" />
    </div>
  );
}
