import { createStore } from "./store";

/* ---------------- Game data detection ---------------- */
export const REQUIRED = [
  { id: "dll", label: "prototypeenginef.dll", required: true },
  { id: "uv", label: "proto_uv.dat", required: true },
  { id: "rcf", label: "*.rcf archives", required: true },
  { id: "p3d", label: "*.p3d archives", required: true },
  { id: "art", label: "art/", required: true },
  { id: "audio", label: "audio/", required: true },
  { id: "scripts", label: "scripts/", required: true },
] as const;

export type GameData = {
  setupDone: boolean;
  access: boolean;
  path: string;
  source: "none" | "app";
  files: Record<string, boolean>;
  sizeMB: number;
  checkedAt: number;
};

export const dataStore = createStore<GameData>("pd.data.v1", {
  setupDone: false,
  access: false,
  path: "",
  source: "none",
  files: {},
  sizeMB: 0,
  checkedAt: 0,
});

// Clear legacy browser/demo detections; only the Android host may confirm game files.
if (!["none", "app"].includes((dataStore.get() as unknown as { source: string }).source)) {
  dataStore.set({ setupDone: false, access: false, path: "", source: "none", files: {}, sizeMB: 0, checkedAt: 0 });
}

export const isReady = (d: GameData) => REQUIRED.every((r) => d.files[r.id]);

/* ---------------- Touch layout ---------------- */
export type Ctrl = { id: string; label: string; kind: "stick" | "btn" | "wheel"; extra?: boolean };
export const CONTROLS: Ctrl[] = [
  { id: "stick", label: "MOVE", kind: "stick" },
  { id: "jump", label: "JUMP", kind: "btn" },
  { id: "attack", label: "ATK", kind: "btn" },
  { id: "power", label: "PWR", kind: "btn" },
  { id: "grab", label: "GRAB", kind: "btn" },
  { id: "sprint", label: "RUN", kind: "btn" },
  { id: "target", label: "LOCK", kind: "btn" },
  { id: "block", label: "BLOCK", kind: "btn" },
  { id: "powers", label: "POWERS", kind: "wheel" },
  { id: "forms", label: "FORMS", kind: "wheel" },
  { id: "consume", label: "EAT", kind: "btn", extra: true },
  { id: "recenter", label: "CAM", kind: "btn", extra: true },
  { id: "quick", label: "QUICK", kind: "btn", extra: true },
];
export type Pos = { x: number; y: number; s: number };
export const DEFAULT_LAYOUT: Record<string, Pos> = {
  stick: { x: 13, y: 70, s: 1 },
  jump: { x: 91, y: 78, s: 1.1 },
  attack: { x: 81, y: 86, s: 1 },
  power: { x: 81, y: 66, s: 1 },
  grab: { x: 91, y: 57, s: 1 },
  sprint: { x: 70, y: 86, s: 0.9 },
  target: { x: 6, y: 30, s: 0.85 },
  block: { x: 93, y: 34, s: 0.85 },
  powers: { x: 36, y: 15, s: 0.85 },
  forms: { x: 64, y: 15, s: 0.85 },
  menu: { x: 95, y: 9, s: 0.7 },
  consume: { x: 70, y: 66, s: 0.85 },
  recenter: { x: 16, y: 30, s: 0.75 },
  quick: { x: 83, y: 34, s: 0.85 },
};
export const layoutStore = createStore<Record<string, Pos>>("pd.layout.v1", DEFAULT_LAYOUT);

/* ---------------- Mods ---------------- */
export type Mod = {
  id: string;
  name: string;
  kind: "Texture pack" | "Loose files" | "Native plugin";
  file: string;
  sizeKB: number;
  sha: string;
  enabled: boolean;
  error?: string;
  desc: string;
  added: number;
};
export const modsStore = createStore<{ list: Mod[] }>("pd.mods.v1", {
  list: [
    {
      id: "m-hoodie",
      name: "Blacklight Hoodie HD",
      kind: "Texture pack",
      file: "blacklight_hoodie_hd.zip",
      sizeKB: 18432,
      sha: "9f2c41ab77e0d3c5b1e8a96d2f04c3aa5e71b08c9d3f62e4a1b7c05d8e9f1a2b",
      enabled: false,
      desc: "Same-size, same-format DDS replacements for Alex's hoodie and jacket, mapped through textures.ini.",
      added: 0,
    },
    {
      id: "m-hud",
      name: "Clean HUD",
      kind: "Loose files",
      file: "clean_hud.zip",
      sizeKB: 742,
      sha: "1ad4e7f09c2b5e83d6f1a04b97c3e2d58f60a1b2c3d4e5f60718293a4b5c6d7e",
      enabled: false,
      desc: "Loose-file overlay that trims HUD chrome. Never patches original game files.",
      added: 0,
    },
  ],
});

/* ---------------- Drivers ---------------- */
export type Pkg = {
  id: string;
  name: string;
  version: string;
  family: "Adreno" | "Mali" | "Any";
  sizeMB: number;
  sha: string;
  note: string;
  experimental?: boolean;
};
export const CATALOG: Pkg[] = [
  { id: "turnip-stable", name: "Turnip", version: "25.1.0 · stable", family: "Adreno", sizeMB: 9.8, sha: "4c1e…b7a2", note: "Mesa Turnip for Adreno 6xx / 7xx. The standard choice." },
  { id: "turnip-oneui", name: "Turnip One UI", version: "25.1.0 · samsung", family: "Adreno", sizeMB: 9.9, sha: "8d03…11fe", note: "Built for Samsung One UI kernels on Snapdragon Galaxy devices." },
  { id: "turnip-gen8", name: "Turnip Gen8", version: "25.2.0-dev · a8xx", family: "Adreno", sizeMB: 10.4, sha: "e2a9…5c70", note: "Dedicated Gen8 build for Adreno 825 (SM8735) and newer 8xx." },
  { id: "panvk-kbase", name: "PanVK kbase", version: "25.1.0 · experimental", family: "Mali", sizeMB: 11.2, sha: "37bb…d0c4", note: "Specific Mali generations on the retail mali_kbase interface only.", experimental: true },
];
export type InstalledPkg = Pkg & { installedAt: number; imported?: boolean };
export const driverStore = createStore<{ installed: InstalledPkg[]; customId: string | null }>("pd.drivers.v1", {
  installed: [],
  customId: null,
});

/* ---------------- Session log ---------------- */
export const logStore = createStore<{ runs: string[] }>("pd.logs.v1", { runs: [] });
export function appendLog(lines: string[]) {
  logStore.set((s) => ({ runs: [...s.runs, ...lines].slice(-400) }));
}

/* ---------------- Toasts (non-persistent) ---------------- */
export const toastStore = createStore<{ msg: string; id: number; tone: "ok" | "warn" }>(null, { msg: "", id: 0, tone: "ok" });
let tt: number | undefined;
export function toast(msg: string, tone: "ok" | "warn" = "ok") {
  toastStore.set({ msg, id: Date.now(), tone });
  clearTimeout(tt);
  tt = window.setTimeout(() => toastStore.set({ msg: "" }), 2200);
}

/* ---------------- Helpers ---------------- */
export async function sha256(file: Blob) {
  try {
    const buf = await file.arrayBuffer();
    const h = await crypto.subtle.digest("SHA-256", buf);
    return Array.from(new Uint8Array(h))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  } catch {
    // Non-secure context fallback: FNV-style digest so the UI still works offline.
    const buf = new Uint8Array(await file.slice(0, 4 << 20).arrayBuffer());
    let h1 = 0x811c9dc5,
      h2 = 0x1000193;
    for (let i = 0; i < buf.length; i++) {
      h1 = Math.imul(h1 ^ buf[i], 16777619);
      h2 = Math.imul(h2 + buf[i], 2654435761);
    }
    return ((h1 >>> 0).toString(16) + (h2 >>> 0).toString(16)).padEnd(64, "0");
  }
}

export function download(name: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
