import { createStore } from "./store";

export const DEFAULTS = {
  // Graphics
  preset: "medium",
  renderHeight: 720,
  textures: 0,
  anisotropy: 4,
  fpsLimit: 60,
  batterySaver: false,
  unlockMenuFps: true,
  vulkanDriver: "auto",
  // Game video
  antiAlias: "default",
  shadowDetail: "default",
  graphicQuality: "default",
  // Controls
  buttonSize: 100,
  vibration: true,
  vibrationStrength: 60,
  leftHanded: false,
  stickEdgeSprint: true,
  cameraSpeed: 50,
  invertY: false,
  extraButtons: false,
  // Interface
  opacity: 70,
  showFps: false,
  launcherSfx: false,
  sfxVolume: 45,
  launcherHaptics: true,
  animations: "full",
  skipIntro: false,
  // Audio
  audioDriver: "aaudio",
  audioMasterReuse: true,
  // Engine fixes
  fovOffset: 0,
  shadowMapLimit: 0,
  tickPolicy: "default",
  looseFiles: false,
  devMenu: false,
  vramReport: 0,
  dumpTextures: false,
  // Diagnostics
  detailedDiagnostics: false,
  diagInterval: 5,
  pipelineTiming: "follow",
  presentStats: false,
  audioStats: 0,
  watchdog: false,
  importProfile: false,
};

export type Settings = typeof DEFAULTS;
export type Key = keyof Settings;
export type Val = string | number | boolean;

export const settingsStore = createStore<Settings>("pd.settings.v1", DEFAULTS);

type Base = { k: Key; label: string; hint: string; restart?: boolean; preset?: boolean; when?: (s: Settings) => boolean };
export type Field =
  | (Base & { t: "choice"; opts: [Val, string][] })
  | (Base & { t: "toggle"; guard?: string })
  | (Base & { t: "slider"; min: number; max: number; step: number; fmt?: (v: number) => string })
  | { t: "action"; id: string; label: string; hint: string; cta: string; danger?: boolean }
  | { t: "header"; label: string };

export type Tab = { id: string; label: string; fields: Field[] };

const def = "Game default";

export const PRESETS: Record<string, Partial<Settings>> = {
  low: { renderHeight: 540, textures: 1, anisotropy: 1, antiAlias: "off", shadowDetail: "low", graphicQuality: "low" },
  medium: { renderHeight: 720, textures: 0, anisotropy: 4, antiAlias: "default", shadowDetail: "default", graphicQuality: "default" },
  high: { renderHeight: 1080, textures: 0, anisotropy: 16, antiAlias: "4x", shadowDetail: "high", graphicQuality: "high" },
};

export const TABS: Tab[] = [
  {
    id: "graphics",
    label: "Graphics",
    fields: [
      {
        t: "choice", k: "preset", label: "Preset",
        hint: "Graphics and video only.",
        opts: [["low", "Low"], ["medium", "Medium"], ["high", "High"], ["custom", "Custom"]],
      },
      {
        t: "choice", k: "renderHeight", label: "Resolution", restart: true, preset: true,
        hint: "Internal render height.",
        opts: [[480, "480p"], [540, "540p"], [600, "600p"], [720, "720p"], [900, "900p"], [1080, "1080p"], [0, "Native"]],
      },
      {
        t: "choice", k: "textures", label: "Textures", restart: true, preset: true,
        hint: "Texture detail.",
        opts: [[0, "Full"], [1, "Half"], [2, "Quarter"]],
      },
      {
        t: "choice", k: "anisotropy", label: "Anisotropy", restart: true, preset: true,
        hint: "Texture filtering.",
        opts: [[1, "Off"], [2, "2x"], [4, "4x"], [8, "8x"], [16, "16x"]],
      },
      {
        t: "choice", k: "fpsLimit", label: "FPS limit",
        hint: "Frame cap. Applies immediately.",
        opts: [[0, "Unlimited"], [30, "30"], [40, "40"], [45, "45"], [60, "60"], [90, "90"], [120, "120"], [144, "144"], [1000, "1000"]],
      },
      { t: "toggle", k: "batterySaver", label: "Battery saver", hint: "Lower heat, lower peak FPS." },
      { t: "toggle", k: "unlockMenuFps", label: "Unlock menu FPS", hint: "Keeps menu movies responsive." },
      {
        t: "choice", k: "vulkanDriver", label: "GPU driver",
        hint: "Turnip is Adreno only.",
        opts: [["auto", "Auto"], ["system", "System"], ["turnip", "Turnip"], ["custom", "Custom"]],
      },
      { t: "action", id: "drivers", label: "Driver library", cta: "Drivers", hint: "Installed packages and downloads." },
    ],
  },
  {
    id: "video",
    label: "Game Video",
    fields: [
      {
        t: "choice", k: "antiAlias", label: "Anti-alias level", restart: true, preset: true,
        hint: "Leave on Game default unless needed.",
        opts: [["default", def], ["off", "Off"], ["2x", "2x MSAA"], ["4x", "4x MSAA"]],
      },
      {
        t: "choice", k: "shadowDetail", label: "Shadow detail", restart: true, preset: true,
        hint: "Engine shadow quality.",
        opts: [["default", def], ["off", "Off"], ["low", "Low"], ["medium", "Medium"], ["high", "High"]],
      },
      {
        t: "choice", k: "graphicQuality", label: "Graphic quality", restart: true, preset: true,
        hint: "LOD and effects.",
        opts: [["default", def], ["low", "Low"], ["medium", "Medium"], ["high", "High"]],
      },
    ],
  },
  {
    id: "controls",
    label: "Controls",
    fields: [
      { t: "slider", k: "buttonSize", label: "Button size", min: 50, max: 200, step: 5, fmt: (v) => `${v}%`, hint: "Scale of every touch control." },
      { t: "toggle", k: "vibration", label: "Vibration", hint: "Haptic feedback." },
      { t: "slider", k: "vibrationStrength", label: "Vibration strength", min: 10, max: 100, step: 5, fmt: (v) => `${v}%`, hint: "Haptic pulse length.", when: (s) => s.vibration },
      { t: "toggle", k: "leftHanded", label: "Left-handed", hint: "Mirror the stick and buttons." },
      { t: "toggle", k: "stickEdgeSprint", label: "Stick edge sprint", hint: "Stick edge sprints." },
      { t: "slider", k: "cameraSpeed", label: "Camera speed", min: 1, max: 100, step: 1, hint: "Touch camera sensitivity." },
      { t: "toggle", k: "invertY", label: "Invert Y", hint: "Invert the vertical camera." },
      { t: "toggle", k: "extraButtons", label: "Extra buttons", hint: "Adds three extra touch buttons." },
      { t: "action", id: "layout", label: "Touch layout", cta: "Layout", hint: "Move, resize and reset the overlay." },
    ],
  },
  {
    id: "interface",
    label: "Display",
    fields: [
      { t: "slider", k: "opacity", label: "Opacity", min: 10, max: 100, step: 5, fmt: (v) => `${v}%`, hint: "Touch controls opacity." },
      { t: "toggle", k: "showFps", label: "Show FPS", hint: "Frame stats overlay." },
      { t: "header", label: "Launcher" },
      { t: "toggle", k: "launcherSfx", label: "Launcher sounds", hint: "Subtle clicks, made in code. Off by default." },
      { t: "slider", k: "sfxVolume", label: "Sound volume", min: 0, max: 100, step: 5, fmt: (v) => `${v}%`, hint: "UI sound volume.", when: (s) => s.launcherSfx },
      { t: "toggle", k: "launcherHaptics", label: "Launcher haptics", hint: "Vibrate on navigation." },
      { t: "choice", k: "animations", label: "Animations", opts: [["full", "Full"], ["reduced", "Reduced"], ["off", "Off"]], hint: "Full, reduced or off." },
      { t: "toggle", k: "skipIntro", label: "Skip intro", hint: "Skip the intro." },
    ],
  },
  {
    id: "audio",
    label: "Audio",
    fields: [
      { t: "choice", k: "audioDriver", label: "Audio driver", restart: true, opts: [["aaudio", "AAudio"], ["opensles", "OpenSL ES"]], hint: "AAudio is lower latency." },
      { t: "toggle", k: "audioMasterReuse", label: "Master reuse", restart: true, hint: "Reuse the mastering output." },
    ],
  },
  {
    id: "engine",
    label: "Engine Fixes",
    fields: [
      { t: "slider", k: "fovOffset", label: "FOV offset", min: -10, max: 30, step: 0.5, restart: true, fmt: (v) => (v > 0 ? `+${v}` : `${v}`) + "°", hint: "Field-of-view offset." },
      { t: "choice", k: "shadowMapLimit", label: "Shadow-map limit", restart: true, opts: [[0, "Default"], [512, "512"], [1024, "1024"], [2048, "2048"], [4096, "4096"], [8192, "8192"]], hint: "Higher values cost memory." },
      { t: "choice", k: "tickPolicy", label: "Tick / QTE policy", restart: true, opts: [["default", "Default"], ["fixed", "Fixed 30Hz"], ["scaled", "Frame-scaled"]], hint: "QTE timing at high FPS." },
      { t: "toggle", k: "looseFiles", label: "Loose files", restart: true, hint: "Prefer loose files." },
      { t: "toggle", k: "devMenu", label: "Developer menu", restart: true, guard: "The developer menu is unsupported and can corrupt saves. Enable anyway?", hint: "Guarded debug menu." },
      { t: "choice", k: "vramReport", label: "VRAM report", restart: true, opts: [[0, "Device"], [1024, "1 GB"], [2048, "2 GB"], [4096, "4 GB"], [8192, "8 GB"]], hint: "VRAM reported to DXVK." },
      { t: "toggle", k: "dumpTextures", label: "Dump original textures", restart: true, hint: "Write DDS files for texture packs." },
    ],
  },
  {
    id: "diag",
    label: "Diagnostics",
    fields: [
      { t: "toggle", k: "detailedDiagnostics", label: "Detailed diagnostics", hint: "Native timing reports." },
      { t: "slider", k: "diagInterval", label: "Report interval", min: 1, max: 60, step: 1, fmt: (v) => `${v}s`, hint: "Report interval.", when: (s) => s.detailedDiagnostics },
      { t: "choice", k: "pipelineTiming", label: "Pipeline timing", opts: [["follow", "Follow"], ["on", "On"], ["off", "Off"]], hint: "DXVK pipeline timing." },
      { t: "toggle", k: "presentStats", label: "Present stats", hint: "Presentation diagnostics." },
      { t: "choice", k: "audioStats", label: "Audio stats", opts: [[0, "Off"], [1, "Underruns"], [2, "Every window"]], hint: "Underruns or every window." },
      { t: "toggle", k: "watchdog", label: "Watchdog", hint: "Hang diagnostics." },
      { t: "toggle", k: "importProfile", label: "Import profile", hint: "Per-thread wall time." },
      { t: "action", id: "logs", label: "Log files", cta: "Logs", hint: "Native and DXVK logs." },
      { t: "action", id: "ini", label: "Export INI", cta: "Export", hint: "Write every current value to an INI." },
      { t: "action", id: "resetAll", label: "Reset all settings", cta: "Reset", danger: true, hint: "Restore every option." },
    ],
  },
];

export function setSetting<K extends Key>(k: K, v: Settings[K]) {
  const fieldIsPreset = TABS.some((t) => t.fields.some((f) => "k" in f && f.k === k && "preset" in f && f.preset));
  if (k === "preset" && typeof v === "string" && PRESETS[v]) {
    settingsStore.set({ preset: v, ...PRESETS[v] } as Partial<Settings>);
    return;
  }
  settingsStore.set({ [k]: v, ...(fieldIsPreset ? { preset: "custom" } : {}) } as Partial<Settings>);
}

export function resetTab(tab: Tab) {
  const patch: Partial<Settings> = {};
  tab.fields.forEach((f) => {
    if ("k" in f) (patch as Record<string, Val>)[f.k] = DEFAULTS[f.k];
  });
  settingsStore.set(patch);
}

const INI: Partial<Record<Key, string>> = {
  renderHeight: "render_height",
  textures: "texture_skip_mips",
  anisotropy: "max_anisotropy",
  fpsLimit: "fps_limit",
  batterySaver: "battery_saver",
  unlockMenuFps: "unlock_menu_fps",
  vulkanDriver: "vulkan_driver",
  antiAlias: "anti_alias",
  shadowDetail: "shadow_detail",
  graphicQuality: "graphic_quality",
  audioDriver: "audio_driver",
  audioMasterReuse: "audio_master_reuse",
  fovOffset: "fov_offset",
  shadowMapLimit: "shadow_map_limit",
  tickPolicy: "tick_policy",
  looseFiles: "loose_files",
  devMenu: "developer_menu",
  vramReport: "vram_report_mb",
  dumpTextures: "dump_textures",
  detailedDiagnostics: "detailed_diagnostics",
  diagInterval: "detailed_diagnostics_interval",
  pipelineTiming: "pipeline_timing",
  presentStats: "present_stats",
  audioStats: "audio_stats",
  watchdog: "watchdog",
  importProfile: "import_profile",
};

export function toIni(s: Settings) {
  const lines = [
    "; protodroid.ini · generated by the ProtoDroid launcher",
    "; Place in /storage/emulated/0/Prototype/",
    "",
  ];
  (Object.keys(INI) as Key[]).forEach((k) => {
    let v = s[k];
    if (typeof v === "boolean") v = v ? 1 : 0;
    if (k === "pipelineTiming" && v === "follow") return;
    if (k === "renderHeight" && v === 0) v = "native";
    lines.push(`${INI[k]} = ${v}`);
  });
  return lines.join("\n");
}
