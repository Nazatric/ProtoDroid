/**
 * Optional native host bridge.
 *
 * The same UI runs standalone in a browser and inside the ProtoDroid Android WebView.
 * The native app injects `window.ProtoDroidHost` before the page loads:
 *
 *   interface ProtoDroidHost {
 *     launch(configJson: string): void;       // hand validated settings to the ARM64 host
 *     exit(): void;                           // leave the launcher / close the activity
 *     requestFileAccess?(): void;             // ask Android for the app's configured file access
 *     checkGameData?(): void;                 // validate the configured local game directory
 *     saveFile?(name: string, text: string): void;
 *     writeIni?(text: string): void;
 *   }
 *
 * When no host is present, the launcher stays entirely local (localStorage + file downloads).
 */
export type ProtoDroidHost = {
  launch?: (configJson: string) => void;
  exit?: () => void;
  requestFileAccess?: () => void;
  checkGameData?: () => void;
  saveFile?: (name: string, text: string) => void;
  writeIni?: (text: string) => void;
};

/** Messages the native host can send into the launcher: */
export type HostMessage =
  | { type: "gameData"; path: string; files: Record<string, boolean>; sizeMB?: number }
  | { type: "fileAccess"; granted: boolean }
  | { type: "open"; screen: "home" | "settings" | "drivers" | "mods" | "layout" | "logs" | "about" | "setup" }
  | { type: "toast"; message: string }
  | { type: "settings"; values: Record<string, unknown> };

declare global {
  interface Window {
    ProtoDroidHost?: ProtoDroidHost;
    ProtoDroidRecv?: (msg: HostMessage) => void;
  }
}

export function installHostBridge(on: {
  gameData?: (m: Extract<HostMessage, { type: "gameData" }>) => void;
  fileAccess?: (granted: boolean) => void;
  open?: (s: Extract<HostMessage, { type: "open" }>["screen"]) => void;
  toast?: (s: string) => void;
  settings?: (v: Record<string, unknown>) => void;
}) {
  window.ProtoDroidRecv = (msg) => {
    if (msg.type === "gameData") on.gameData?.(msg);
    if (msg.type === "fileAccess") on.fileAccess?.(msg.granted);
    if (msg.type === "open") on.open?.(msg.screen);
    if (msg.type === "toast") on.toast?.(msg.message);
    if (msg.type === "settings") on.settings?.(msg.values);
  };
  return () => {
    delete window.ProtoDroidRecv;
  };
}

const host = () => (typeof window === "undefined" ? undefined : window.ProtoDroidHost);
export const hasHost = () => !!host();
export const hostName = () => (hasHost() ? "Native host" : "Standalone");

export function launchEngine(config: Record<string, unknown>) {
  const h = host();
  if (!h?.launch) return false;
  h.launch(JSON.stringify(config));
  return true;
}

export function exitApp() {
  host()?.exit?.();
}

export function requestFileAccess() {
  const h = host();
  if (!h?.requestFileAccess) return false;
  h.requestFileAccess();
  return true;
}

export function refreshGameData() {
  const h = host();
  if (!h?.checkGameData) return false;
  h.checkGameData();
  return true;
}

export function saveText(name: string, text: string) {
  const h = host();
  if (h?.saveFile) {
    h.saveFile(name, text);
    return;
  }
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function writeIni(text: string) {
  const h = host();
  if (h?.writeIni) {
    h.writeIni(text);
    return true;
  }
  saveText("protodroid.ini", text);
  return false;
}
