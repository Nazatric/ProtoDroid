let cached: { gpu: string; family: "Adreno" | "Mali" | "Other" } | null = null;

/** Local GPU detection via WebGL (no network). */
export function gpuInfo() {
  if (cached) return cached;
  let gpu = "Unknown GPU";
  try {
    const c = document.createElement("canvas");
    const gl = (c.getContext("webgl") || c.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (gl) {
      const ext = gl.getExtension("WEBGL_debug_renderer_info");
      gpu = String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    }
  } catch {
    /* ignore */
  }
  const family = /mali/i.test(gpu) ? "Mali" : /adreno/i.test(gpu) ? "Adreno" : "Other";
  cached = { gpu, family };
  return cached;
}

export function deviceInfo() {
  const ua = navigator.userAgent;
  const android = /Android\s([\d.]+)/.exec(ua)?.[1];
  const model = /Android[^;]*;\s*([^;)]+)/.exec(ua)?.[1]?.trim();
  return {
    os: android ? `Android ${android}` : /Windows/.test(ua) ? "Windows" : /Mac/.test(ua) ? "macOS" : /Linux/.test(ua) ? "Linux" : "Unknown",
    model: model && model !== "K" ? model : "Generic device",
    cores: navigator.hardwareConcurrency || 0,
    memory: (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 0,
    screen: `${Math.round(screen.width * devicePixelRatio)}×${Math.round(screen.height * devicePixelRatio)}`,
    ...gpuInfo(),
  };
}
