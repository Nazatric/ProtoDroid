import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import Boot from "./screens/Boot";
import Setup from "./screens/Setup";
import Home from "./screens/Home";
import Settings from "./screens/Settings";
import Drivers from "./screens/Drivers";
import Mods from "./screens/Mods";
import Layout from "./screens/Layout";
import Logs from "./screens/Logs";
import About from "./screens/About";
import Launch from "./screens/Launch";
import Game from "./screens/Game";
import { Btn, Toast } from "./components/ui";
import { settingsStore } from "./lib/settings";
import { dataStore } from "./lib/data";
import { installNav } from "./lib/nav";
import { installHostBridge } from "./lib/bridge";
import { toast } from "./lib/data";
import { settingsStore as settings } from "./lib/settings";

export type Screen = "boot" | "setup" | "home" | "settings" | "drivers" | "mods" | "layout" | "logs" | "about" | "launch" | "game";

function initial(): Screen {
  if (!settingsStore.get().skipIntro) return "boot";
  return dataStore.get().setupDone ? "home" : "setup";
}

export default function App() {
  const s = settingsStore.use();
  const [stack, setStack] = useState<Screen[]>(() => [initial()]);
  const [wipe, setWipe] = useState(0);
  const [portrait, setPortrait] = useState(false);
  const [ignorePortrait, setIgnorePortrait] = useState(false);
  const busy = useRef(false);
  const screen = stack[stack.length - 1];

  useEffect(() => installNav(), []);

  useEffect(() => {
    document.documentElement.dataset.motion = s.animations;
  }, [s.animations]);

  useEffect(() => {
    const mq = window.matchMedia("(orientation: portrait) and (max-width: 820px)");
    const f = () => setPortrait(mq.matches);
    f();
    mq.addEventListener("change", f);
    return () => mq.removeEventListener("change", f);
  }, []);

  /** Transition with the red slash wipe; swaps the screen at the wipe's midpoint. */
  const transition = useCallback(
    (fn: (st: Screen[]) => Screen[]) => {
      if (busy.current) return;
      if (settingsStore.get().animations === "off") return setStack(fn);
      busy.current = true;
      setWipe(Date.now());
      setTimeout(() => setStack(fn), 310);
      setTimeout(() => {
        setWipe(0);
        busy.current = false;
      }, 760);
    },
    []
  );

  const go = useCallback((to: Screen) => transition((st) => [...st, to]), [transition]);
  const replace = useCallback((to: Screen) => transition((st) => [...st.slice(0, -1), to]), [transition]);
  const back = useCallback(() => transition((st) => (st.length > 1 ? st.slice(0, -1) : ["home"])), [transition]);
  const home = useCallback(() => transition(() => ["home"]), [transition]);

  // Native host hooks: the Android side can push game data, settings and navigation.
  useEffect(
    () =>
      installHostBridge({
        fileAccess: (granted) => {
          dataStore.set({ access: granted, setupDone: granted });
          toast(granted ? "File access allowed" : "File access denied");
        },
        gameData: (m) => {
          dataStore.set({ path: m.path, files: m.files, sizeMB: m.sizeMB ?? 0, source: "app", access: true, checkedAt: Date.now(), setupDone: true });
          toast("Game data updated");
        },
        open: (to) => transition(() => [to]),
        toast: (message) => toast(message),
        settings: (values) => settings.set(values as never),
      }),
    [transition]
  );

  let view: ReactNode;
  switch (screen) {
    case "boot":
      view = <Boot onDone={() => replace(dataStore.get().setupDone ? "home" : "setup")} />;
      break;
    case "setup":
      view = <Setup onDone={home} onBack={home} />;
      break;
    case "home":
      view = <Home go={go} />;
      break;
    case "settings":
      view = <Settings go={go} onBack={back} />;
      break;
    case "drivers":
      view = <Drivers onBack={back} />;
      break;
    case "mods":
      view = <Mods onBack={back} />;
      break;
    case "layout":
      view = <Layout onBack={back} />;
      break;
    case "logs":
      view = <Logs onBack={back} />;
      break;
    case "about":
      view = <About onBack={back} />;
      break;
    case "launch":
      view = <Launch onDone={() => replace("game")} onCancel={back} />;
      break;
    case "game":
      view = <Game onQuit={home} onSettings={() => go("settings")} />;
      break;
  }

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink">
      <div key={screen} className="h-full w-full">
        {view}
      </div>

      <div className="grain" aria-hidden />
      <div className="scanlines" aria-hidden />

      {wipe > 0 && (
        <div key={wipe} className="wipe" aria-hidden>
          <i />
          <i />
        </div>
      )}

      <Toast />

      {portrait && !ignorePortrait && (
        <div className="fixed inset-0 z-[90] flex flex-col items-center justify-center gap-6 bg-ink p-8 text-center">
          <div className="anim-rotate relative h-24 w-14 rounded-lg border-2 border-bone/80">
            <div className="absolute inset-x-4 bottom-1.5 h-0.5 rounded bg-blood-hi" />
          </div>
          <div>
            <div className="font-dirt text-3xl text-bone">ROTATE DEVICE</div>
            <div className="mt-2 font-ui text-[11px] uppercase tracking-[0.28em] text-ash">Landscape only</div>
          </div>
          <Btn variant="plain" small onClick={() => setIgnorePortrait(true)}>
            Continue
          </Btn>
        </div>
      )}
    </div>
  );
}
