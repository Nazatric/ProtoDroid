# Native ProtoDroid Launcher

`composeApp/` is the Kotlin Compose Multiplatform implementation. Its shared UI targets Android and Kotlin/Wasm; neither target embeds or calls the React/Vite preview. The Android app owns file access, settings persistence, game launch, logs and driver/mod operations through `LauncherHost`.

## Build

Requirements: JDK 17+, Android SDK 35, and network access for the first Gradle dependency resolution.

```sh
./gradlew :composeApp:assembleDebug
./gradlew :composeApp:wasmJsBrowserDistribution
```

The Android APK is written to `composeApp/build/outputs/apk/debug/`. The Wasm browser distribution is written under `composeApp/build/dist/wasmJs/`.

## Integrate Into ProtoDroid

Add `composeApp` to the existing Gradle settings or copy the module's `commonMain` sources and resources into the app's shared Compose module. In the existing landscape Activity, supply an adapter for the native ProtoDroid services:

```kotlin
setContent {
    LauncherApp(host = protoDroidLauncherHost)
}
```

Implement `LauncherHost` in the Android app. Map its methods to the existing native managers rather than adding another storage picker or engine:

- `requestFileAccess()` uses ProtoDroid's existing permission/access flow. The launcher intentionally has no choose-folder UI.
- `gameData` publishes access and validation status from the existing configured game path.
- `launchGame(settings)` hands native settings to the ARM64 engine and starts the game surface.
- `saveSettings(settings)` persists the shared preference model.
- `writeIni(settings)` writes the generated values beside the app's configured game data.
- `mods`, `setModEnabled`, `refreshMods`, `logLines`, and `clearLogs` bind to the existing native libraries.

The included Android `MainActivity` is a standalone shell. For the real app, the Application implements `ProtoDroidLauncherOwner` and returns its production `LauncherHost`; no WebView, JavaScript bridge, browser fullscreen control, or browser file chooser is needed.

## Offline Assets

`composeApp/launcher-assets.json` is the complete text-embedded asset source used by Gradle. The Android and Wasm builds materialize it into Compose resources before resource generation, so no image/font URL is fetched at runtime. It contains 14 key-art wallpaper scenes, 6 still frames sampled from the pre-rendered Prototype intro cinematic (not gameplay captures), the ProtoDroid repo icon, and local fonts.

Editable source files are organized under `src/assets/` when materialized. To restore them from the text bundle, replace an asset, and rebuild both bundles:

```sh
node tools/materialize-assets.mjs
# Replace the relevant file under src/assets/cinematic/ or src/assets/fonts/.
node tools/embed-assets.mjs
node tools/export-compose-assets.mjs
./gradlew :composeApp:assembleDebug :composeApp:wasmJsBrowserDistribution
```

The React/Vite `src/App.tsx` is retained only as the required browser preview for this workspace. The native Android app entry is `composeApp/src/commonMain/kotlin/com/protodroid/launcher/LauncherApp.kt`.