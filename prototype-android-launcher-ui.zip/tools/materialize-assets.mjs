import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const registry = await readFile(resolve(root, "src/lib/localAssets.ts"), "utf8");
const match = registry.match(/export const LOCAL_ASSETS = (\{[\s\S]*\}) as const;/);
if (!match) throw new Error("Could not parse the checked-in embedded asset catalogue");

const assets = JSON.parse(match[1]);
for (const [key, dataUrl] of Object.entries(assets)) {
  const [, mime, encoded] = dataUrl.match(/^data:([^;]+);base64,([\s\S]+)$/) ?? [];
  if (!mime || !encoded) continue;
  let path;
  if (key === "icon") path = "src/assets/icon.png";
  else if (key.startsWith("font-")) path = `src/assets/fonts/${key.slice(5)}.woff2`;
  else if (key.startsWith("compose-font-")) path = `src/assets/fonts/${key.slice(13)}.ttf`;
  else if (key.startsWith("wall-")) path = `src/assets/cinematic/wallpapers/${key.slice(5)}.webp`;
  else if (key.startsWith("intro-")) path = `src/assets/cinematic/intro/intro-${key.slice(6)}.webp`;
  else continue;

  const output = resolve(root, path);
  await mkdir(dirname(output), { recursive: true });
  await writeFile(output, Buffer.from(encoded, "base64"));
}
console.log(`Materialized ${Object.keys(assets).length} bundled assets under src/assets.`);