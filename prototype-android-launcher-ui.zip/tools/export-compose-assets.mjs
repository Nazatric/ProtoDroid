import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const source = await readFile(resolve(root, "src/lib/localAssets.ts"), "utf8");
const match = source.match(/export const LOCAL_ASSETS = (\{[\s\S]*\}) as const;/);
if (!match) throw new Error("Could not read generated local asset registry");

const all = JSON.parse(match[1]);
const selected = Object.fromEntries(
  Object.entries(all).filter(([key]) =>
    key === "icon" || key.startsWith("wall-") || key.startsWith("intro-") || key.startsWith("bink-") || key.startsWith("compose-font-")
  )
);

await writeFile(resolve(root, "composeApp/launcher-assets.json"), JSON.stringify(selected));
console.log(`Wrote ${Object.keys(selected).length} Compose-ready embedded assets.`);